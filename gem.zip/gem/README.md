# Audiocular Control (Vite + React)

Quick scaffold for the Audiocular HID control UI built with Vite, React and Tailwind.

Getting started:

1. Open a terminal in the project root: `c:\Users\conce\WEB-APP\gem`
2. Install dependencies:

```powershell
npm install
```

3. Start dev server:

```powershell
npm run dev
```

Notes:
- The HID-related commands are simulated; real HID access requires additional native/browser APIs or a native companion.
- The UI uses Tailwind classes; Tailwind is wired via PostCSS.
