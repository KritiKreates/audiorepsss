module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        indigo: {
          50: '#fff8f1',
          100: '#feecdc',
          200: '#fcd9b8',
          300: '#f9b685',
          400: '#f69352',
          500: '#f38d32',
          600: '#ed7d23',
          700: '#cc5f14',
          800: '#a34610',
          900: '#82370f',
        },
      },
    },
  },
  plugins: [],
}
