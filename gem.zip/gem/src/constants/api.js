export const BASE_URL = 'https://audiocular-api.myaudiocular.com';
