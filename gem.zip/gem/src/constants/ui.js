export const DAC_FILTER_OPTIONS = [
    { value: 1, label: "FAST-LL (Steep Roll-off, Low Latency)" },
    { value: 2, label: "FAST-PC (Steep Roll-off, Phase Compensation)" },
    { value: 3, label: "SLOW-LL (Slow Roll-off, Low Latency)" },
    { value: 4, label: "SLOW-PC (Slow Roll-off, Phase Compensation)" },
    { value: 5, label: "NON OS (Non Over-Sampling)" },
];

export const DAC_GAIN_LEVELS = [
    { value: 0, label: "Low Gain" },
    { value: 1, label: "Mid Gain" },
    { value: 2, label: "High Gain" },
];
