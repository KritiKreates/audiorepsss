export const DEFAULT_BAND_SETTINGS = { q: 0.75, gain: 0.0, type: 2, enabled: true };

export const DEVICE_PROFILES = {
    '0x3302:0x12C1': { // KT CB5100 DAC
        bandCount: 10,
        defaultFrequencies: [31, 100, 125, 250, 500, 1000, 2000, 4000, 6300, 10000],
        initialGains: [0.0, 4.0, 0.0, 0.0, -3.0, 0.0, 0.0, 0.0, 0.0, 3.5]
    },
    '0x3302:0x12C2': { // KT CB1300 Dongle
        bandCount: 5,
        defaultFrequencies: [100, 300, 1000, 3000, 8000],
        initialGains: [2.0, 0.0, 0.0, 0.0, 1.5]
    },
    '0xABCD:0xEF01': { // Generic Audio Device (Simulated 8-band)
        bandCount: 8,
        defaultFrequencies: [60, 150, 400, 1000, 2400, 4000, 8000, 16000],
        initialGains: [0, 0, 0, 0, 0, 0, 0, 0]
    }
};

export const MOCK_DEVICES = [
    { id: 1, name: "KT CB5100 DAC (10-Band)", vid: "0x3302", pid: "0x12C1" },
    { id: 2, name: "KT CB1300 Dongle (5-Band)", vid: "0x3302", pid: "0x12C2" },
    { id: 3, name: "Generic Audio Device (8-Band)", vid: "0xABCD", pid: "0xEF01" },
];

export const INITIAL_EQ_BANDS = [];
