import { MAX_PACKET_LENGTH, REPORT_ID, REQUEST_TYPE_WRITE, CMD } from '../constants/hid';

/**
 * Converts a number to a 2-byte Little-Endian Hex Array.
 * @param {number} value
 * @returns {number[]}
 */
export const to2ByteLE = (value) => {
    const arr = new Uint8Array(2);
    arr[0] = value & 0xFF;
    arr[1] = (value >> 8) & 0xFF;
    return Array.from(arr);
};

/**
 * Converts a floating point value to a signed/unsigned 8.8 fixed-point integer (2 bytes).
 * @param {number} floatValue - The decimal value (e.g., 0.75 or 4.0)
 * @param {boolean} isSigned - True for Gain (signed), False for Q (unsigned)
 * @returns {number[]} - 2-byte Little-Endian array (Uint16)
 */
export const floatToFixed8_8 = (floatValue, isSigned) => {
    // 8.8 fixed point has 256 steps per integer unit (2^8)
    const multiplier = 256;
    let fixedValue = Math.round(floatValue * multiplier);

    // Handle signed values (16-bit range: -32768 to 32767)
    if (isSigned) {
        if (fixedValue > 32767) fixedValue = 32767;
        if (fixedValue < -32768) fixedValue = -32768;
        fixedValue = (fixedValue < 0) ? (0xFFFF + fixedValue + 1) : fixedValue;
    } else {
        // Handle unsigned values (0 to 65535)
        if (fixedValue < 0) fixedValue = 0;
        if (fixedValue > 65535) fixedValue = 65535;
    }

    return to2ByteLE(fixedValue);
};

/**
 * Creates a full 64-byte HID packet for a write command.
 * @param {number} bCode - Command code
 * @param {number[]} payload - Array of payload bytes
 * @returns {number[]} - 64-byte HID packet
 */
export const createHIDPacket = (bCode, payload = [], requestType = REQUEST_TYPE_WRITE) => {
    const bLength = payload.length > 60 ? 60 : payload.length;
    
    // Calculate exact size needed: 3 bytes header + payload
    const packet = new Array(3 + bLength).fill(0);

    // CMD Segment (3 Bytes)
    packet[0] = requestType;      // bRequestType
    packet[1] = bCode;            // bCODE
    packet[2] = bLength;          // bLength

    // PAYLOAD Segment
    for (let i = 0; i < bLength; i++) {
        packet[3 + i] = payload[i];
    }
    return packet;
};

/**
 * [SIMULATED] Creates a HID command to set a DAC/ADC Volume/Offset
 * @param {number} cmd - CMD.SET_DAC_VOLUME, CMD.SET_ADC_VOLUME, etc.
 * @param {number} valueDB - Volume/Offset in dB (-127.9961 to 127.9961)
 * @returns {string} - Hex string of the 64-byte packet
 */
export const createVolumeOffsetPacket = (cmd, valueDB) => {
    // Range is 127.9961dB (0x7FFF) ~ -127.9961dB (0x8001)
    // For simplicity, we use 0x8000 for -128 dB and 0x7FFF for 127.9961 dB.
    const maxVal = 127.9961;
    let scaledValue = Math.round((valueDB / maxVal) * 32767);

    // Clamp and convert to two's complement for 16-bit signed integer
    if (scaledValue > 32767) scaledValue = 32767;
    if (scaledValue < -32768) scaledValue = -32768;

    const buffer = new DataView(new ArrayBuffer(2));
    buffer.setInt16(0, scaledValue, true); // true for Little-Endian

    const payload = Array.from(new Uint8Array(buffer.buffer));
    const packet = createHIDPacket(cmd, payload);
    return packet.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
};

/**
 * Creates the HID command for a single EQ band (0x09)
 * @param {object} band - The EQ band object
 * @param {number} index - The index of the band (0-7)
 * @returns {string} - Hex string of the 64-byte packet
 */
export const createEQBandPacket = (band, index) => {
    // 1. Placeholder for 20-byte IIR Filter Coefficients (float32, Little-Endian)
    // NOTE: In a real app, this must be calculated using the Biquad DSP formulas.
    const mockCoeffs = Array(20).fill(0xAA); // Placeholder: 20 bytes (5 x 32-bit coeff)

    // 2. Filter Center Frequency (2 Bytes, Little-Endian, 1Hz step)
    const freqLE = to2ByteLE(band.freq);

    // 3. Filter Q Value (2 Bytes, 8.8 Unsigned Fixed-Point)
    const qFixed = floatToFixed8_8(band.q, false);

    // 4. Filter Gain (2 Bytes, 8.8 Signed Fixed-Point)
    const gainFixed = floatToFixed8_8(band.gain, true);

    // 5. Filter Type (1 Byte) - 2: peak, 1: Lowshelf, 3: Highshelf, etc.
    const filterType = band.type;

    // 6. Filter Gain Offset (1 Byte, Signed, -128dB ~ 127dB) - Assuming 0
    const gainOffset = 0x00;

    // 7. EQ Number Index (1 Byte)
    const eqNumber = index + 1;

    // PAYLOAD construction
    const payload = [
        ...to2ByteLE(index), 0x00, 0x00, // EQ_IIR_Filter_Index (4 Bytes: [EQ_index (0), Filter_index (1)]) - Little-Endian
        ...mockCoeffs,                   // Filter_coeff (20 Bytes)
        ...freqLE,                       // Filter_fc (2 Bytes)
        ...qFixed,                       // Filter_Q (2 Bytes)
        ...gainFixed,                    // Filter_Gain (2 Bytes)
        filterType,                      // Filter_Type (1 Byte)
        gainOffset,                      // Filter_Gian_Offset (1 Byte)
        eqNumber                         // EQ_Number (1 Byte)
    ];

    // Payload length is 4 (index) + 20 (coeffs) + 2*3 (fc/Q/Gain) + 3 (type/offset/number) = 33 bytes.
    // The example documentation uses 0x18 (24 bytes) for length, which suggests the latter fields might be optional or handled differently in the tool's length calculation. We will use the calculated length.
    const packet = createHIDPacket(CMD.UPDATE_EQ_ARRAY, payload);
    return packet.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
};
