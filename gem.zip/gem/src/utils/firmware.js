
// Firmware Upgrade Utilities
// Reconstructed from provided minified code

const j_e = new Uint32Array([0, 1996959894, 3993919788, 2567524794, 124634137, 1886057615, 3915621685, 2657392035, 249268274, 2044508324, 3772115230, 2547177864, 162941995, 2125561021, 3887607047, 2428444049, 498536548, 1789927666, 4089016648, 2227061214, 450548861, 1843258603, 4107580753, 2211677639, 325883990, 1684777152, 4251122042, 2321926636, 335633487, 1661365465, 4195302755, 2366115317, 997073096, 1281953886, 3579855332, 2724688242, 1006888145, 1258607687, 3524101629, 2768942443, 901097722, 1119000684, 3686517206, 2898065728, 853044451, 1172266101, 3705015759, 2882616665, 651767980, 1373503546, 3369554304, 3218104598, 565507253, 1454621731, 3485111705, 3099436303, 671266974, 1594198024, 3322730930, 2970347812, 795835527, 1483230225, 3244367275, 3060149565, 1994146192, 31158534, 2563907772, 4023717930, 1907459465, 112637215, 2680153253, 3904427059, 2013776290, 251722036, 2517215374, 3775830040, 2137656763, 141376813, 2439277719, 3865271297, 1802195444, 476864866, 2238001368, 4066508878, 1812370925, 453092731, 2181625025, 4111451223, 1706088902, 314042704, 2344532202, 4240017532, 1658658271, 366619977, 2362670323, 4224994405, 1303535960, 984961486, 2747007092, 3569037538, 1256170817, 1037604311, 2765210733, 3554079995, 1131014506, 879679996, 2909243462, 3663771856, 1141124467, 855842277, 2852801631, 3708648649, 1342533948, 654459306, 3188396048, 3373015174, 1466479909, 544179635, 3110523913, 3462522015, 1591671054, 702138776, 2966460450, 3352799412, 1504918807, 783551873, 3082640443, 3233442989, 3988292384, 2596254646, 62317068, 1957810842, 3939845945, 2647816111, 81470997, 1943803523, 3814918930, 2489596804, 225274430, 2053790376, 3826175755, 2466906013, 167816743, 2097651377, 4027552580, 2265490386, 503444072, 1762050814, 4150417245, 2154129355, 426522225, 1852507879, 4275313526, 2312317920, 282753626, 1742555852, 4189708143, 2394877945, 397917763, 1622183637, 3604390888, 2714866558, 953729732, 1340076626, 3518719985, 2797360999, 1068828381, 1219638859, 3624741850, 2936675148, 906185462, 1090812512, 3747672003, 2825379669, 829329135, 1181335161, 3412177804, 3160834842, 628085408, 1382605366, 3423369109, 3138078467, 570562233, 1426400815, 3317316542, 2998733608, 733239954, 1555261956, 3268935591, 3050360625, 752459403, 1541320221, 2607071920, 3965973030, 1969922972, 40735498, 2617837225, 3943577151, 1913087877, 83908371, 2512341634, 3803740692, 2075208622, 213261112, 2463272603, 3855990285, 2094854071, 198958881, 2262029012, 4057260610, 1759359992, 534414190, 2176718541, 4139329115, 1873836001, 414664567, 2282248934, 4279200368, 1711684554, 285281116, 2405801727, 4167216745, 1634467795, 376229701, 2685067896, 3608007406, 1308918612, 956543938, 2808555105, 3495958263, 1231636301, 1047427035, 2932959818, 3654703836, 1088359270, 936918e3, 2847714899, 3736837829, 1202900863, 817233897, 3183342108, 3401237130, 1404277552, 615818150, 3134207493, 3453421203, 1423857449, 601450431, 3009837614, 3294710456, 1567103746, 711928724, 3020668471, 3272380065, 1510334235, 755167117]);

const Jt = {
    ACK: 120,
    NACK: 135,
    DataPacket: 105,
    PktDone: 165,
    PackSize: 1024,
    BootErase: { Sector: 0, Block32: 1, Block64: 2, Chip: 3, Valid: 4, None: 7 },
    BootSize: [4, 32, 64]
};

function rh(e, t) {
    let n = 0;
    for (let a = 0; a < t; a++) {
        const o = (n ^ e[a]) & 255;
        n = n >>> 8 & 16777215 ^ j_e[o];
    }
    return n;
}

class _i {
    static packBINData(t, n, a, o) {
        if (a.length < 1024 || o.length < 1034) return -1;
        let r, s;
        if (n === 0) {
            r = 1008;
            for (let d = 0; d < r; d++) o[6 + d] = a[16 + d];
            s = 16;
        } else {
            r = a.length - Jt.PackSize * n;
            r > Jt.PackSize && (r = Jt.PackSize);
            for (let d = 0; d < r; d++) o[6 + d] = a[n * Jt.PackSize + d];
            s = n * Jt.PackSize;
        }
        let l;
        n % Jt.BootSize[t] === 0 ? l = t : l = Jt.BootErase.None;
        o[0] = Jt.DataPacket;
        o[1] = r & 255;
        o[2] = r >> 8 & 255 | l << 5 & 255;
        o[3] = s & 255;
        o[4] = s >> 8 & 255;
        o[5] = s >> 16 & 255;
        const i = rh(o, r + 6);
        let u = "";
        for (let d = 0; d < 4; d++) {
            const f = r + 6 + d;
            // console.log("index:", f);
            o[f] = i >> d * 8 & 255;
            u += o[f].toString(16).padStart(2, "0").toUpperCase() + " ";
        }
        // return u && console.log(u.trim()), r + 10;
        return r + 10;
    }

    static PackBINData2(t, n, a, o, r) {
        if (o.length < 1024 || r.length < 1034) return -1;
        let s, l;
        if (n === 0) {
            s = 1008;
            for (let d = 0; d < s; d++) r[6 + d] = o[16 + d];
            l = 16 + a;
        } else {
            s = o.length - Jt.PackSize * n;
            s > Jt.PackSize && (s = Jt.PackSize);
            for (let d = 0; d < s; d++) r[6 + d] = o[n * Jt.PackSize + d];
            l = n * Jt.PackSize + a;
        }
        let i;
        n % Jt.BootSize[t] === 0 ? i = t : i = Jt.BootErase.None;
        r[0] = Jt.DataPacket;
        r[1] = s & 255;
        r[2] = s >> 8 & 255 | i << 5 & 255;
        r[3] = l & 255;
        r[4] = l >> 8 & 255;
        r[5] = l >> 16 & 255;
        const u = rh(r, s + 6);
        for (let d = 0; d < 4; d++) r[s + 6 + d] = u >> d * 8 & 255;
        return s + 10;
    }

    static packBINFirstData(t, n, a) {
        const r = t, s = Jt.BootErase.None;
        for (let i = 0; i < 16; i++) a[6 + i] = n[i];
        a[0] = Jt.DataPacket;
        a[1] = 16;
        a[2] = 0 | s << 5 & 255;
        a[3] = r & 255;
        a[4] = r >> 8 & 255;
        a[5] = r >> 16 & 255;
        const l = rh(a, 22);
        for (let i = 0; i < 4; i++) a[22 + i] = l >> i * 8 & 255;
        return 26;
    }
}

export class BaseDevice {
    constructor(t, n) {
        this.device = t;
        this.productInfo = n;
        this.eventMap = new Map();
        this.Constants = Jt;
    }
    addEventLister(t, n) {
        this.eventMap.set(t, n);
    }
    init() { }
    upgrade(t) { }
    finish() { }
    log(t) { console.log(t); }
    handleError(t) { console.error(t); }
}

BaseDevice.eventKeys = {
    CONNECTED_CDC: "CONNECTED_CDC",
    CONNECT_CDC_CANCEL: "CONNECT_CDC_CANCEL",
    INIT_FINISH: "INIT_FINISH",
    INIT_FAIL: "INIT_FAIL",
    UPGRADE_SUCCESS: "UPGRADE_SUCCESS",
    UPGRADE_FAIL: "UPGRADE_FAIL",
    UPGRADE_PROGRESS: "UPGRADE_PROGRESS"
};

class xS extends BaseDevice {
    constructor(t, n) { super(t, n); }
}

// Device Type G (General?)
export class DeviceG extends xS {
    constructor(t, n) {
        super(t, n);
        this.devicePort = null;
    }
    async init() {
        var t, n, a, o, r, s, l, i, u;
        try {
            if (await this.device.sendReport(75, new Uint8Array([1, 255])), this.devicePort = await navigator.serial.requestPort({ filters: [{ usbVendorId: 12722, usbProductId: 65528 }, { usbVendorId: 34952, usbProductId: 52672 }] }), this.devicePort) (t = this.eventMap.get(BaseDevice.eventKeys.CONNECTED_CDC)) == null || t();
            else { (n = this.eventMap.get(BaseDevice.eventKeys.CONNECT_CDC_CANCEL)) == null || n(); return; }
            if (await new Promise(_ => setTimeout(_, 3e3)), this.log(this.devicePort), await this.devicePort.open({ baudRate: 115200 }), this.log("Serial Port Opened"), this.log(this.devicePort), await this.writeToPort(this.devicePort, new Uint8Array([30, 75, 84, 77])), (await this.readRawData(this.devicePort))[0] !== 120) {
                this.log("Invalid Response"); (a = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || a(); return;
            }
            await this.writeToPort(this.devicePort, new Uint8Array([210, 67, 72, 80]));
            const f = await this.readRawData(this.devicePort);
            if (f && f.length < 13) {
                this.log("Failed to get info"); (o = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || o(); return;
            }
            if (await this.writeToPort(this.devicePort, new Uint8Array([45, 41, 0, 16, 14, 21, 0, 96, 0, 188])), (await this.readRawData(this.devicePort))[0] !== 120) {
                this.log("Failed to set params"); (r = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || r(); return;
            }
            await this.writeToPort(this.devicePort, new Uint8Array([60, 80, 87, 79]));
            const h = await this.readRawData(this.devicePort), m = await this.readRawData(this.devicePort);
            if (h[0] === 120 && m[0] === 120) this.log("Clock switch success");
            else { this.log("Clock switch failed"); (s = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || s(); return; }
            if (await this.writeToPort(this.devicePort, new Uint8Array([75, 83, 84, 65])), (await this.readRawData(this.devicePort))[0] === 120) this.log("Start burn success");
            else { this.log("Start burn failed"); (l = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || l(); return; }
            this.log("Burn status ready"); (i = this.eventMap.get(BaseDevice.eventKeys.INIT_FINISH)) == null || i();
        } catch (d) {
            this.log(`CDC Init Failed: ${d.message}`); this.handleError(d); (u = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || u();
        }
    }
    async upgrade(t) {
        var r, s, l, i;
        if (!t) { this.log("Please select firmware file"); return; }
        let n = 0;
        const a = Math.ceil((t.length - 16) / 1024) + 1, o = new Uint8Array(1034);
        this.log(`Start burning firmware, total ${a} packets`);
        try {
            for (; n < a;) {
                let f = null;
                n === a - 1 ? f = _i.packBINFirstData(32768, t, o) : f = _i.PackBINData2(Jt.BootErase.Block32, n, 32768, t, o);
                const p = o.slice(0, f);
                // this.log("outputBuffer.length:", p.length);
                let h = "";
                for (let v = 0; v < p.length; v++) h += p[v].toString(16).padStart(2, "0").toUpperCase() + " ";
                // h && console.log(h.trim());
                await this.writeToPort(this.devicePort, p);
                try {
                    const v = await this.readRawData(this.devicePort), _ = await this.readRawData(this.devicePort);
                    v[0] === this.Constants.ACK && _[0] === 165 ? this.log(`Packet ${n + 1}/${a} success`) : v[0] === this.Constants.NACK ? this.log(`Packet ${n + 1}/${a} failed, NACK received`) : this.log(`Packet ${n + 1}/${a} unknown response: ${Array.from(v).map(g => g.toString(16).padStart(2, "0")).join(" ")}`);
                } catch { this.log(`Packet ${n + 1}/${a} timeout`); }
                const m = (n + 1) / a * 100; (r = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_PROGRESS)) == null || r(m); n++;
            }
            await new Promise(f => setTimeout(f, 100));
            const u = new Uint8Array([150, 83, 84, 80]);
            await this.writeToPort(this.devicePort, u);
            try {
                if ((await this.readRawData(this.devicePort))[0] == Jt.ACK) this.log("Send STOP command success");
                else { this.log("Send STOP command failed"); return; }
            } catch { this.log("Send STOP command timeout"); }
            const d = new Uint8Array([90, 82, 83, 84]);
            await this.writeToPort(this.devicePort, d);
            try {
                if ((await this.readRawData(this.devicePort))[0] === Jt.ACK) this.log("Send RESET command success");
                else { this.log("Send RESET command failed"); return; }
            } catch { this.log("Send RESET command timeout"); (s = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || s(); }
            this.log("Burn success, device restarting"); this.log("Firmware burn complete"); (l = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_SUCCESS)) == null || l();
        } catch (u) {
            this.log(`Error during burn: ${u.message}`); this.handleError(u); (i = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || i();
        }
    }
    finish() { }
    async writeToPort(t, n) { const a = t.writable.getWriter(); await a.write(n); a.releaseLock(); }
    async readRawData(t, n = 2e3) {
        const a = t.readable.getReader(), o = [];
        let r = Date.now();
        try {
            for (; Date.now() - r < n;) {
                const { value: s, done: l } = await a.read();
                if (l) break;
                if (o.push(s), o.length > 0) return this.mergeUint8Arrays(o);
            }
            throw new Error(`Read timeout (${n}ms no data)`);
        } finally { a.releaseLock(); }
    }
    mergeUint8Arrays(t) {
        const n = t.reduce((r, s) => r + s.length, 0), a = new Uint8Array(n);
        let o = 0;
        return t.forEach(r => { a.set(r, o); o += r.length; }), a;
    }
}

class Fm extends BaseDevice {
    constructor(t, n) { super(t, n); }
}

// Device Type Y
export class DeviceY extends Fm {
    constructor(t, n) {
        super(t, n);
        this.devicePort = null;
    }
    async init() {
        var t, n, a, o, r, s, l, i, u;
        try {
            if (await this.device.sendReport(84, new Uint8Array([49, 50, 51, 52, 53, 54, 55, 56, 0, 0])), this.devicePort = await navigator.serial.requestPort({ filters: [{ usbVendorId: 12722, usbProductId: 65528 }, { usbVendorId: 34952, usbProductId: 52672 }] }), await new Promise(_ => setTimeout(_, 3e3)), this.devicePort) (t = this.eventMap.get(BaseDevice.eventKeys.CONNECTED_CDC)) == null || t();
            else { (n = this.eventMap.get(BaseDevice.eventKeys.CONNECT_CDC_CANCEL)) == null || n(); return; }
            this.log(this.devicePort); await this.devicePort.open({ baudRate: 115200 }); this.log("Serial Port Opened"); this.log(this.devicePort); await this.writeToPort(this.devicePort, new Uint8Array([30, 75, 84, 77]));
            const d = await this.readRawData(this.devicePort);
            if (!d || d[0] !== 120) { this.log("Invalid Response"); (a = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || a(); return; }
            await this.writeToPort(this.devicePort, new Uint8Array([210, 67, 72, 80]));
            const f = await this.readRawData(this.devicePort);
            if (!f || f.length < 13) { this.log("Failed to get info"); (o = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || o(); return; }
            await this.writeToPort(this.devicePort, new Uint8Array([45, 41, 0, 16, 14, 21, 0, 96, 0, 188]));
            const p = await this.readRawData(this.devicePort);
            if (!p || p[0] !== 120) { this.log("Failed to set params"); (r = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || r(); return; }
            await this.writeToPort(this.devicePort, new Uint8Array([60, 80, 87, 79]));
            const h = await this.readRawData(this.devicePort), m = await this.readRawData(this.devicePort);
            if (h[0] === 120 && m[0] === 120) this.log("Clock switch success");
            else { this.log("Clock switch failed"); (s = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || s(); return; }
            if (await this.writeToPort(this.devicePort, new Uint8Array([75, 83, 84, 65])), (await this.readRawData(this.devicePort))[0] === 120) this.log("Start burn success");
            else { this.log("Start burn failed"); (l = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || l(); return; }
            this.log("Burn status ready"); (i = this.eventMap.get(BaseDevice.eventKeys.INIT_FINISH)) == null || i();
        } catch (d) {
            this.log(`CDC Init Failed: ${d.message}`); this.handleError(d); (u = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || u();
        }
    }
    async upgrade(t) {
        var r, s, l, i;
        if (!t) { this.log("Please select firmware file"); return; }
        let n = 0;
        const a = Math.ceil((t.length - 16) / 1024) + 1, o = new Uint8Array(1034);
        this.log(`Start burning firmware, total ${a} packets`);
        try {
            for (; n < a;) {
                let f = null;
                n === a - 1 ? f = _i.packBINFirstData(t[15] == 1 ? Jt.PackSize * 32 : 0, t, o) : f = _i.PackBINData2(Jt.BootErase.Block32, n, t[15] == 1 ? Jt.PackSize * 32 : 0, t, o);
                const p = o.slice(0, f);
                // this.log("outputBuffer.length:", p.length);
                let h = "";
                for (let v = 0; v < p.length; v++) h += p[v].toString(16).padStart(2, "0").toUpperCase() + " ";
                // h && console.log(h.trim());
                await this.writeToPort(this.devicePort, p);
                try {
                    const v = await this.readRawData(this.devicePort), _ = await this.readRawData(this.devicePort);
                    v[0] === this.Constants.ACK && _[0] === 165 ? this.log(`Packet ${n + 1}/${a} success`) : v[0] === this.Constants.NACK || _[0] === this.Constants.NACK ? this.log(`Packet ${n + 1}/${a} failed, NACK received`) : this.log(`Packet ${n + 1}/${a} unknown response: ${Array.from(v).map(g => g.toString(16).padStart(2, "0")).join(" ")}`);
                } catch { this.log(`Packet ${n + 1}/${a} timeout`); }
                const m = (n + 1) / a * 100; (r = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_PROGRESS)) == null || r(m); n++;
            }
            await new Promise(f => setTimeout(f, 100));
            const u = new Uint8Array([150, 83, 84, 80]);
            await this.writeToPort(this.devicePort, u);
            try {
                if ((await this.readRawData(this.devicePort))[0] == Jt.ACK) this.log("Send STOP command success");
                else { this.log("Send STOP command failed"); return; }
            } catch { this.log("Send STOP command timeout"); }
            const d = new Uint8Array([90, 82, 83, 84]);
            await this.writeToPort(this.devicePort, d);
            try {
                if ((await this.readRawData(this.devicePort))[0] === Jt.ACK) this.log("Send RESET command success");
                else { this.log("Send RESET command failed"); return; }
            } catch { this.log("Send RESET command timeout"); (s = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || s(); }
            this.log("Burn success, device restarting"); this.log("Firmware burn complete"); (l = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_SUCCESS)) == null || l();
        } catch (u) {
            this.log(`Error during burn: ${u.message}`); this.handleError(u); (i = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || i();
        }
    }
    finish() { }
    async writeToPort(t, n) { const a = t.writable.getWriter(); await a.write(n); a.releaseLock(); }
    async readRawData(t, n = 2e3) {
        const a = t.readable.getReader(), o = [];
        let r = Date.now();
        try {
            for (; Date.now() - r < n;) {
                const { value: s, done: l } = await a.read();
                if (l) break;
                if (o.push(s), o.length > 0) return this.mergeUint8Arrays(o);
            }
            throw new Error(`Read timeout (${n}ms no data)`);
        } finally { a.releaseLock(); }
    }
    mergeUint8Arrays(t) {
        const n = t.reduce((r, s) => r + s.length, 0), a = new Uint8Array(n);
        let o = 0;
        return t.forEach(r => { a.set(r, o); o += r.length; }), a;
    }
}

// Device Type Q
export class DeviceQ extends Fm {
    constructor(t, n) {
        super(t, n);
        this.devicePort = null;
    }
    async init() {
        var t, n, a, o, r, s, l, i, u;
        try {
            if (await this.device.sendReport(84, new Uint8Array([49, 50, 51, 52, 53, 54, 55, 56, 0, 0])), this.devicePort = await navigator.serial.requestPort({ filters: [{ usbVendorId: 12722, usbProductId: 65528 }, { usbVendorId: 34952, usbProductId: 52672 }] }), this.devicePort) (t = this.eventMap.get(BaseDevice.eventKeys.CONNECTED_CDC)) == null || t();
            else { (n = this.eventMap.get(BaseDevice.eventKeys.CONNECT_CDC_CANCEL)) == null || n(); return; }
            if (await new Promise(_ => setTimeout(_, 3e3)), this.log(this.devicePort), await this.devicePort.open({ baudRate: 115200 }), this.log("Serial Port Opened"), this.log(this.devicePort), await this.writeToPort(this.devicePort, new Uint8Array([30, 75, 84, 77])), (await this.readRawData(this.devicePort))[0] !== 120) {
                this.log("Invalid Response"); (a = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || a(); return;
            }
            await this.writeToPort(this.devicePort, new Uint8Array([210, 67, 72, 80]));
            await new Promise(_ => setTimeout(_, 1e3));
            const f = await this.readRawData(this.devicePort);
            if (console.log("Get Info:", f), f && f.length < 13) {
                this.log("Failed to get info"); (o = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || o(); return;
            }
            if (await this.writeToPort(this.devicePort, new Uint8Array([45, 41, 0, 16, 14, 21, 0, 96, 0, 188])), (await this.readRawData(this.devicePort))[0] !== 120) {
                this.log("Failed to set params"); (r = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || r(); return;
            }
            await this.writeToPort(this.devicePort, new Uint8Array([60, 80, 87, 79]));
            const h = await this.readRawData(this.devicePort), m = await this.readRawData(this.devicePort);
            if (h[0] === 120 && m[0] === 120) this.log("Clock switch success");
            else { this.log("Clock switch failed"); (s = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || s(); return; }
            if (await this.writeToPort(this.devicePort, new Uint8Array([75, 83, 84, 65])), (await this.readRawData(this.devicePort))[0] === 120) this.log("Start burn success");
            else { this.log("Start burn failed"); (l = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || l(); return; }
            this.log("Burn status ready"); (i = this.eventMap.get(BaseDevice.eventKeys.INIT_FINISH)) == null || i();
        } catch (d) {
            this.log(`CDC Init Failed: ${d.message}`); this.handleError(d); (u = this.eventMap.get(BaseDevice.eventKeys.INIT_FAIL)) == null || u();
        }
    }
    async upgrade(t) {
        var r, s, l, i;
        if (!t) { this.log("Please select firmware file"); return; }
        let n = 0;
        const a = Math.ceil((t.length - 16) / 1024) + 1, o = new Uint8Array(1034);
        this.log(`Start burning firmware, total ${a} packets`);
        try {
            for (; n < a;) {
                let f = null;
                n === a - 1 ? f = _i.packBINFirstData(32768, t, o) : f = _i.PackBINData2(Jt.BootErase.Block32, n, 32768, t, o);
                const p = o.slice(0, f);
                // this.log("outputBuffer.length:", p.length);
                let h = "";
                for (let v = 0; v < p.length; v++) h += p[v].toString(16).padStart(2, "0").toUpperCase() + " ";
                // h && console.log(h.trim());
                await this.writeToPort(this.devicePort, p);
                try {
                    const v = await this.readRawData(this.devicePort), _ = await this.readRawData(this.devicePort);
                    v[0] === this.Constants.ACK && _[0] === 165 ? this.log(`Packet ${n + 1}/${a} success`) : v[0] === this.Constants.NACK ? this.log(`Packet ${n + 1}/${a} failed, NACK received`) : this.log(`Packet ${n + 1}/${a} unknown response: ${Array.from(v).map(g => g.toString(16).padStart(2, "0")).join(" ")}`);
                } catch { this.log(`Packet ${n + 1}/${a} timeout`); }
                const m = (n + 1) / a * 100; (r = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_PROGRESS)) == null || r(m); n++;
            }
            await new Promise(f => setTimeout(f, 100));
            const u = new Uint8Array([150, 83, 84, 80]);
            await this.writeToPort(this.devicePort, u);
            try {
                if ((await this.readRawData(this.devicePort))[0] == Jt.ACK) this.log("Send STOP command success");
                else { this.log("Send STOP command failed"); return; }
            } catch { this.log("Send STOP command timeout"); }
            const d = new Uint8Array([90, 82, 83, 84]);
            await this.writeToPort(this.devicePort, d);
            try {
                if ((await this.readRawData(this.devicePort))[0] === Jt.ACK) this.log("Send RESET command success");
                else { this.log("Send RESET command failed"); return; }
            } catch { this.log("Send RESET command timeout"); (s = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || s(); }
            this.log("Burn success, device restarting"); this.log("Firmware burn complete"); (l = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_SUCCESS)) == null || l();
        } catch (u) {
            this.log(`Error during burn: ${u.message}`); this.handleError(u); (i = this.eventMap.get(BaseDevice.eventKeys.UPGRADE_FAIL)) == null || i();
        }
    }
    finish() { }
    async writeToPort(t, n) { const a = t.writable.getWriter(); await a.write(n); a.releaseLock(); }
    async readRawData(t, n = 2e3) {
        const a = t.readable.getReader(), o = [];
        let r = Date.now();
        try {
            for (; Date.now() - r < n;) {
                const { value: s, done: l } = await a.read();
                if (l) break;
                if (o.push(s), o.length > 0) return this.mergeUint8Arrays(o);
            }
            throw new Error(`Read timeout (${n}ms no data)`);
        } finally { a.releaseLock(); }
    }
    mergeUint8Arrays(t) {
        const n = t.reduce((r, s) => r + s.length, 0), a = new Uint8Array(n);
        let o = 0;
        return t.forEach(r => { a.set(r, o); o += r.length; }), a;
    }
}
