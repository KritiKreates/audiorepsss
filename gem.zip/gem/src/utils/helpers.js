import { DEFAULT_BAND_SETTINGS } from '../constants/device';

/**
 * Creates the band array dynamically based on the device profile.
 * @param {object} profile - The device profile containing bandCount and defaultFrequencies.
 * @returns {object[]} - Array of EQ band objects.
 */
export const createInitialBands = (profile) => {
    if (!profile) return [];
    return profile.defaultFrequencies.map((freq, index) => ({
        ...DEFAULT_BAND_SETTINGS,
        freq: freq,
        gain: profile.initialGains[index] !== undefined ? profile.initialGains[index] : DEFAULT_BAND_SETTINGS.gain,
    }));
};

/**
 * Generates a set of default frequencies based on the specific device scheme.
 * @param {number} count - Number of bands.
 * @returns {number[]} - Array of frequencies.
 */
export const generateDefaultFrequencies = (count) => {
    if (!count || count <= 0) return [];
    
    // Specific defaults from driver logic
    if (count === 5) return [200, 500, 2500, 5000, 10000];
    if (count === 6) return [200, 500, 1000, 2500, 5000, 10000];
    if (count === 8) return [50, 200, 500, 1000, 2500, 5000, 10000, 15000];
    if (count === 10) return [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

    // Fallback: Logarithmic distribution
    const minFreq = 31;
    const maxFreq = 16000;
    const freqs = [];
    const step = Math.pow(maxFreq / minFreq, 1 / (count - 1));
    for (let i = 0; i < count; i++) {
        freqs.push(Math.round(minFreq * Math.pow(step, i)));
    }
    return freqs;
};

/**
 * Determines the number of bands based on the Scheme Number.
 * @param {string|number} schemeNo - The scheme number from product info.
 * @returns {number} - The number of bands (default 8).
 */
export const getBandCountFromScheme = (schemeNo) => {
    const s = String(schemeNo);
    switch (s) {
        case "17": return 5;
        case "19": return 6;
        case "16":
        case "18":
        case "20": return 10;
        default: return 8;
    }
};
