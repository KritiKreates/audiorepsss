/**
 * Calculates the magnitude response (gain in dB) for a single biquad filter at a given frequency.
 * NOTE: This is a complex simulation. The actual implementation requires the Biquad coefficient calculation.
 * For this visualization, we will use a simplified fixed-Q-Peak gain calculation, but the real app must implement the provided IIR formula.
 * @param {number} freq - The target frequency
 * @param {object} band - The EQ band settings
 * @param {number} sampleRate - Assumed sample rate (e.g., 48000 Hz)
 * @returns {number} - Gain in dB
 */
export const calculateBandGain = (freq, band, sampleRate = 48000) => {
    if (!band.enabled || band.gain === 0 || band.q === 0) return 0;
    
    const fc = band.freq;
    const Q = band.q;
    const gain_db = band.gain;

    // Convert dB gain to linear amplitude gain
    const A = Math.pow(10, gain_db / 40); // 40 is used for magnitude of power gain
    const omega = 2 * Math.PI * fc / sampleRate;
    const alpha = Math.sin(omega) / (2 * Q);

    // Simplified Biquad filter calculation for visualization (Peak/Notch filter type only)
    let b0, b1, b2, a0, a1, a2;

    if (gain_db >= 0) { // Peaking EQ boost
        b0 = 1 + alpha * A;
        b1 = -2 * Math.cos(omega);
        b2 = 1 - alpha * A;
        a0 = 1 + alpha / A;
        a1 = -2 * Math.cos(omega);
        a2 = 1 - alpha / A;
    } else { // Peaking EQ cut
        b0 = 1 + alpha / A;
        b1 = -2 * Math.cos(omega);
        b2 = 1 - alpha / A;
        a0 = 1 + alpha * A;
        a1 = -2 * Math.cos(omega);
        a2 = 1 - alpha * A;
    }
    
    // Normalize coefficients by a0
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;

    // Calculate gain at the specified frequency (using the transfer function)
    // The transfer function H(e^jw) for frequency w is used to calculate the magnitude.
    // However, for simplified visualization, we primarily calculate gain around fc.
    // A simplified gain calculation based on the center frequency and Q is often sufficient for visualization:
    
    const w = 2 * Math.PI * freq / sampleRate;
    const cos_w = Math.cos(w);
    const num = b0 + b1 * cos_w + b2 * Math.cos(2 * w);
    const den = 1 + a1 * cos_w + a2 * Math.cos(2 * w);
    
    // This is still too complex for a fast visual approximation.
    // Let's use a simpler Gaussian-like approximation for the visual curve based on Q and fc:

    const x = Math.log(freq / fc) / Math.log(2);
    const y = -4 * Q * Q * x * x; // Simplified peak/notch curve
    return gain_db * Math.pow(2, y); // Apply gain as multiplier of the curve shape

};

/**
 * Calculates the overall frequency response curve in dB.
 * @param {object[]} bands - Array of EQ bands
 * @returns {object[]} - Array of {freq, gain} points for the graph
 */
export const calculateFrequencyResponse = (bands) => {
    const points = [];
    // Standard log frequencies for visualization
    const freqs = [20, 31, 50, 80, 100, 125, 200, 250, 400, 500, 800, 1000, 2000, 4000, 5000, 6300, 8000, 10000, 15000, 20000];
    const sampleRate = 48000;

    for (const freq of freqs) {
        let totalGain = 0;
        for (const band of bands) {
            totalGain += calculateBandGain(freq, band, sampleRate);
        }
        points.push({ freq: freq, gain: totalGain });
    }
    return points;
};
