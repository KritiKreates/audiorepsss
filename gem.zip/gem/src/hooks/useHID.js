import { useState, useEffect, useCallback } from 'react';

export const useHID = () => {
    const [device, setDevice] = useState(null);
    const [isConnected, setIsConnected] = useState(false);
    const [error, setError] = useState(null);

    const filters = [
        { vendorId: 0x3302 }, // KT/CB Devices
        // Add other filters if needed
    ];

    const requestDevice = async () => {
        try {
            if (!navigator.hid) {
                throw new Error('WebHID API is not supported in this browser.');
            }

            const devices = await navigator.hid.requestDevice({ filters });
            
            if (devices.length === 0) {
                return null;
            }

            const selectedDevice = devices[0];
            await openDevice(selectedDevice);
            return selectedDevice;
        } catch (err) {
            console.error('HID Connection Error:', err);
            setError(err.message);
            return null;
        }
    };

    const openDevice = async (selectedDevice) => {
        try {
            if (!selectedDevice.opened) {
                await selectedDevice.open();
            }
            setDevice(selectedDevice);
            setIsConnected(true);
            setError(null);

            selectedDevice.addEventListener('inputreport', handleInputReport);
            
            // Handle device disconnection
            navigator.hid.addEventListener('disconnect', (event) => {
                if (event.device === selectedDevice) {
                    handleDisconnect();
                }
            });

        } catch (err) {
            console.error('Failed to open device:', err);
            setError(err.message);
        }
    };

    const handleDisconnect = useCallback(() => {
        if (device) {
            device.removeEventListener('inputreport', handleInputReport);
            if (device.opened) {
                device.close().catch(console.error);
            }
        }
        setDevice(null);
        setIsConnected(false);
    }, [device]);

    const handleInputReport = (event) => {
        const { data, reportId, device } = event;
        // Dispatch a custom event or use a callback if provided
        // For now, we can just log it or expose it via a state if needed
        // But usually, we want to pass this data up to the component
        const hexData = new Uint8Array(data.buffer).reduce((str, byte) => str + byte.toString(16).padStart(2, '0') + ' ', '');
        // console.log(`[HID Input] Report ID: ${reportId}, Data: ${hexData}`);
    };

    const sendReport = async (reportId, data) => {
        if (!device || !device.opened) {
            throw new Error('Device not connected');
        }
        try {
            await device.sendReport(reportId, data);
        } catch (err) {
            console.error('Failed to send report:', err);
            throw err;
        }
    };

    const getPairedDevices = async () => {
        if (!navigator.hid) return [];
        const devices = await navigator.hid.getDevices();
        return devices.filter(d => filters.some(f => f.vendorId === d.vendorId));
    };

    const connectToDevice = async (deviceToConnect) => {
        await openDevice(deviceToConnect);
    };

    // Auto-connect to previously paired devices
    useEffect(() => {
        const checkPairedDevices = async () => {
            if (!navigator.hid) return;
            
            const devices = await navigator.hid.getDevices();
            const supportedDevice = devices.find(d => filters.some(f => f.vendorId === d.vendorId));
            
            if (supportedDevice) {
                console.log('Found previously paired device:', supportedDevice.productName);
                // We don't auto-connect here to avoid state side-effects during mount, 
                // but we could expose this list to the UI.
            }
        };
        
        checkPairedDevices();
    }, []);

    return {
        device,
        isConnected,
        error,
        requestDevice,
        disconnectDevice: handleDisconnect,
        sendReport,
        getPairedDevices,
        connectToDevice
    };
};
