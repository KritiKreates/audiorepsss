import { useState, useCallback } from 'react';
import { BASE_URL } from '../constants/api';

export const useAuth = () => {
  const [token, setToken] = useState(null);
  const [status, setStatus] = useState('Logged Out');
  const [user, setUser] = useState(null);

  const callApi = useCallback(async (path, method = 'GET', data = null, needsAuth = true) => {
    setStatus('Connecting to API...');
    
    const headers = {};
    // Check if data is FormData or URLSearchParams, otherwise default to JSON
    if (data instanceof URLSearchParams) {
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else if (!(data instanceof FormData)) {
        headers['Content-Type'] = 'application/json';
    }
    
    if (needsAuth && token) headers['Authorization'] = token;

    console.log(`[API Request] ${method} ${path}`, data instanceof URLSearchParams ? data.toString() : data);

    try {
      const res = await fetch(`${BASE_URL}${path}`, {
        method,
        headers,
        body: data ? ((data instanceof FormData || data instanceof URLSearchParams) ? data : JSON.stringify(data)) : null,
      });
      const result = await res.json();
      console.log(`[API Response] ${method} ${path}`, result);

      if (res.ok && (result.code == 200 || result.code == 0)) {
        setStatus('API Success');
        return result;
      } else {
        const msg = result.message || result.msg || res.statusText;
        // If message is "success" but code indicates failure, show the code
        const displayMsg = (msg && msg.toLowerCase() === 'success') 
            ? `Request failed (Code: ${result.code})` 
            : msg;
            
        setStatus(`API Error: ${displayMsg}`);
        throw new Error(displayMsg || 'API call failed');
      }
    } catch (err) {
      console.error(err);
      setStatus(`API Failed: ${err.message}`);
      throw err;
    }
  }, [token]);

  const login = async (username, password) => {
    try {
      const params = new URLSearchParams();
      params.append('Username', username);
      params.append('Password', password);
      params.append('LoginType', 'EM');

      const result = await callApi('/api/user/sign-in', 'POST', params, false);
      
      // Try to find token in common locations
      const token = result?.data?.token || result?.data?.LoginAccessToken || result?.token;

      if (token) {
        setToken(token);
        setUser({ username });
        setStatus('Logged In');
        return true;
      }
    } catch (e) {
      return false;
    }
  };

  const register = async (username, password, verificationCode) => {
    try {
      const params = new URLSearchParams();
      params.append('Username', username);
      params.append('Password', password);
      params.append('Password2', password); // Added per API doc
      params.append('ValidCode', verificationCode);
      params.append('LoginType', 'EM');

      await callApi('/api/user/sign-up', 'POST', params, false);
      setStatus('Registered successfully. Please login.');
      return true;
    } catch (e) {
      return false;
    }
  };

  const sendCode = async (username, type = 'register') => {
    // type: 'register' (1), 'reset' (2), 'bind' (4), 'login' (3)
    let codeType = '1';
    let needsAuth = false;

    if (type === 'reset') codeType = '2';
    if (type === 'login') codeType = '3';
    if (type === 'bind') {
        codeType = '4';
        needsAuth = true; // Requires Authorization header
    }
      
    try {
      const params = new URLSearchParams();
      params.append('Email', username); 
      params.append('Lang', 'en');
      params.append('Type', codeType);

      await callApi('/api/email/create', 'POST', params, needsAuth);
      setStatus(`Verification code sent.`);
      return true;
    } catch (e) {
      return false;
    }
  };

  const resetPassword = async (username, newPassword, verificationCode) => {
    try {
      const params = new URLSearchParams();
      params.append('Email', username);
      params.append('Password', newPassword);
      params.append('ValidCode', verificationCode);

      await callApi('/api/user/reset-passwd', 'POST', params, false);
      setStatus('Password reset successfully. Please login.');
      return true;
    } catch (e) {
      return false;
    }
  };

  const uploadAvatar = async (file) => {
    try {
        const formData = new FormData();
        formData.append('file', file);
        // Updated to v2 based on Postman
        await callApi('/api/v2/user/uploadAppUserAvatar', 'POST', formData, true);
        setStatus('Avatar uploaded successfully.');
        return true;
    } catch (e) {
        return false;
    }
  };

  const saveUserDetail = async (details) => {
    try {
        // Updated to v2 based on Postman
        await callApi('/api/v2/user/saveUserDetail', 'POST', details, true);
        setStatus('User details saved.');
        setUser(prev => ({ ...prev, ...details }));
        return true;
    } catch (e) {
        return false;
    }
  };

  const getUserDetail = async () => {
    try {
        // Updated to v2 based on Postman
        const result = await callApi('/api/v2/user/getUserDetail', 'GET', null, true);
        if (result && result.data) {
            setUser(prev => ({ ...prev, ...result.data }));
            return result.data;
        }
        return null;
    } catch (e) {
        return null;
    }
  };

  const changeEmail = async (data) => {
    try {
        return await callApi('/api/v2/user/changeEmail', 'POST', data, true);
    } catch (e) {
        return null;
    }
  };

  const changePhoneNo = async (data) => {
    try {
        return await callApi('/api/v2/user/changePhoneNo', 'POST', data, true);
    } catch (e) {
        return null;
    }
  };

  const deleteAccount = async () => {
    if (!window.confirm('Are you sure you want to delete your account? This cannot be undone.')) return;
    try {
      await callApi('/api/user/delete-account', 'POST', new URLSearchParams(), true);
      setToken(null);
      setUser(null);
      setStatus('Account deleted.');
      return true;
    } catch (e) {
      return false;
    }
  };

  const logout = async () => {
    try {
        if (token) {
            await callApi('/api/user/sign-out', 'POST', {}, true);
        }
    } catch (e) {
        console.warn("Logout API call failed", e);
    } finally {
        setToken(null);
        setUser(null);
        setStatus('Logged Out');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    }
  };

  const checkToken = async () => {
      try {
          await callApi('/api/user/is-sign-in', 'GET', null, true);
          return true;
      } catch (e) {
          // If check fails, likely token is invalid
          logout();
          return false;
      }
  };

  const saveUserEQ = async (eqData) => {
    try {
        // Updated to v2 based on API doc: /api/v2/eq/saveUserCustomEQ
        return await callApi('/api/v2/eq/saveUserCustomEQ', 'POST', eqData, true);
    } catch (e) {
        return null;
    }
  };

  const updateUserEQ = async (eqData) => {
    try {
        // Updated to v2 based on API doc: /api/v2/eq/updateUserCustomEQ
        return await callApi('/api/v2/eq/updateUserCustomEQ', 'POST', eqData, true);
    } catch (e) {
        return null;
    }
  };

  const deleteUserEQ = async (id) => {
    try {
        // Updated to v2 based on API doc: /api/v2/eq/deleteUserCustomEQById
        return await callApi('/api/v2/eq/deleteUserCustomEQById', 'POST', { id }, true);
    } catch (e) {
        return null;
    }
  };

  const getUserEQList = async (queryData) => {
    try {
        // Updated to v2 based on API doc: /api/v2/eq/queryUserEQList
        return await callApi('/api/v2/eq/queryUserEQList', 'POST', queryData, true);
    } catch (e) {
        return null;
    }
  };

  const queryEQListByPidAndVid = async (data) => {
    try {
        // Try to use a guest/public token if not logged in
        // This token is from the Postman collection for "Enterprise User" requests
        const guestToken = "1234123421341234"; 
        
        const headers = {
            'Content-Type': 'application/json'
        };
        
        // If we have a user token, use it. Otherwise use guest token.
        if (token) {
            headers['Authorization'] = token;
        } else {
            headers['Authorization'] = guestToken;
        }

        console.log(`[API Request] POST /api/v2/eq/queryEQListByPidAndVid`, data);
        const res = await fetch(`${BASE_URL}/api/v2/eq/queryEQListByPidAndVid`, {
            method: 'POST',
            headers,
            body: JSON.stringify(data)
        });
        const result = await res.json();
        console.log(`[API Response] POST /api/v2/eq/queryEQListByPidAndVid`, result);
        return result;
    } catch (e) {
        console.error(e);
        return null;
    }
  };

  const likeEQ = async (data) => {
        try {
            return await callApi('/api/v2/eq/eqLike', 'POST', data, true);
        } catch (e) { return null; }
    };

    const cancelLikeEQ = async (data) => {
        try {
            return await callApi('/api/v2/eq/eqCancelLike', 'POST', data, true);
        } catch (e) { return null; }
    };

    const collectEQ = async (data) => {
        try {
            return await callApi('/api/v2/eq/eqCollect', 'POST', data, true);
        } catch (e) { return null; }
    };

    const cancelCollectEQ = async (data) => {
        try {
            return await callApi('/api/v2/eq/eqCancelCollect', 'POST', data, true);
        } catch (e) { return null; }
    };

    const getReportType = async () => {
        try {
            return await callApi('/api/v2/eq/getReportType', 'POST', null, true);
        } catch (e) { return null; }
    };

    const addShareEqReport = async (data) => {
        try {
            return await callApi('/api/v2/eq/addShareEqReport', 'POST', data, true);
        } catch (e) { return null; }
    };

    const uploadEqShareGraph = async (file) => {
        try {
            const formData = new FormData();
            formData.append('file', file);
            return await callApi('/api/v2/eq/upload/eqShareGraph', 'POST', formData, true);
        } catch (e) { return null; }
    };

    const createEQShareInfo = async (data) => {
        try {
            return await callApi('/api/v2/eq/createEQShareInfo', 'POST', data, true);
        } catch (e) { return null; }
    };

    const deleteEQShareInfo = async (data) => {
        try {
            return await callApi('/api/v2/eq/deleteEQShareInfo', 'POST', data, true);
        } catch (e) { return null; }
    };

    const queryAllEQShareInfoList = async (data) => {
        try {
            return await callApi('/api/v2/eq/queryAllEQShareInfoList', 'POST', data, true);
        } catch (e) { return null; }
    };

    const queryUserEQShareInfoList = async (data) => {
        try {
            return await callApi('/api/v2/eq/queryUserEQShareInfoList', 'POST', data, true);
        } catch (e) { return null; }
    };

    const queryEqLikeMsgInfo = async (data) => {
        try {
            return await callApi('/api/v2/eq/queryEqLikeMsgInfo', 'POST', data, true);
        } catch (e) { return null; }
    };

    const queryUserEQShareInfoGroupList = async (data) => {
        try {
            return await callApi('/api/v2/eq/queryUserEQShareInfoGroupList', 'POST', data, true);
        } catch (e) { return null; }
    };

    const queryUserEqCollectGroupList = async (data) => {
        try {
            return await callApi('/api/v2/eq/queryUserEqCollectGroupList', 'POST', data, true);
        } catch (e) { return null; }
    };

    const submitEqView = async (id) => {
        try {
            return await callApi('/api/v2/eq/watching', 'POST', { id }, true);
        } catch (e) { return null; }
    };

    const loginWithCode = async (username, vcode) => {
        // Updated to v2 based on Postman
        const data = { userName: username, vcode, lang: 'en' };
        const result = await callApi('/api/v2/user/loginByVCode', 'POST', data, false);
        if (result && result.code === 0) {
            setToken(result.data.LoginAccessToken);
            setUser(result.data);
            setStatus('Logged In');
            localStorage.setItem('token', result.data.LoginAccessToken);
            localStorage.setItem('user', JSON.stringify(result.data));
            return { success: true };
        } else {
            setStatus(`Login Failed: ${result?.msg || 'Unknown error'}`);
            return { success: false, message: result?.msg };
        }
    };

    const checkFirmwareVersion = async (pid, vid, version) => {
        try {
            const headers = {
                'Content-Type': 'application/json'
            };
            
            const data = { pid, vid, version };
            // console.log(`[API Request] POST /api/v2/product/checkVersion`, data);
            
            // Try v2 endpoint as v1 returned 404
            const res = await fetch(`${BASE_URL}/api/v2/product/checkVersion`, {
                method: 'POST',
                headers,
                body: JSON.stringify(data)
            });
            
            const text = await res.text();
            // console.log(`[API Response Text]`, text);

            try {
                const result = JSON.parse(text);
                if (!res.ok) {
                    // Handle 404 or other HTTP errors gracefully
                    return { code: res.status, msg: result.error || result.message || "Request failed", data: null };
                }
                return result;
            } catch (e) {
                // If response is not JSON (e.g. 404 HTML), return it as msg
                return { code: res.status, msg: `Invalid JSON (${res.status}): ${text.substring(0, 100)}` };
            }
        } catch (e) {
            console.error("Check firmware failed", e);
            return { code: -1, msg: e.message };
        }
    };

    const downloadFirmware = async (url) => {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Download failed');
            const blob = await response.blob();
            return blob;
        } catch (error) {
            console.error("Firmware download error:", error);
            return null;
        }
    };

    const fetchPreSettingsAndCustomEqs = async (pid, vid, type = "2") => {
        try {
            // Type 1: Custom EQs (Requires Login)
            // Type 2: PreSettings (Public?)
            const data = { 
                type: type, 
                pid, 
                vid 
            };
            
            // Use Guest Token for Type 2 (PreSettings) if not logged in
            if (type === "2" && !token) {
                 const guestToken = "1234123421341234";
                 const headers = {
                    'Content-Type': 'application/json',
                    'Authorization': guestToken
                };
                console.log(`[API Request] POST /api/v2/eq/queryEqInfoList (Guest)`, data);
                const res = await fetch(`${BASE_URL}/api/v2/eq/queryEqInfoList`, {
                    method: 'POST',
                    headers,
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                console.log(`[API Response] POST /api/v2/eq/queryEqInfoList`, result);
                return result;
            }

            // Otherwise use standard callApi which handles user token
            return await callApi('/api/v2/eq/queryEqInfoList', 'POST', data, true);
        } catch (e) {
            console.error("Failed to fetch PreSettings and Custom EQs", e);
            return { code: -1, msg: e.message };
        }
    };

  return { 
    token, 
    status, 
    user,
    login, 
    logout, 
    register,
    sendCode,
    resetPassword,
    deleteAccount,
    uploadAvatar,
    saveUserDetail,
    getUserDetail,
    saveUserEQ,
    updateUserEQ,
    deleteUserEQ,
    getUserEQList,
    queryEQListByPidAndVid,
    likeEQ,
    cancelLikeEQ,
    collectEQ,
    cancelCollectEQ,
    getReportType,
    addShareEqReport,
    uploadEqShareGraph,
    createEQShareInfo,
    deleteEQShareInfo,
    queryAllEQShareInfoList,
    queryUserEQShareInfoList,
    queryEqLikeMsgInfo,
    queryUserEQShareInfoGroupList,
    queryUserEqCollectGroupList,
    submitEqView,
    changeEmail,
    changePhoneNo,
    callApi,
    loginWithCode,
    checkFirmwareVersion,
    downloadFirmware,
    fetchPreSettingsAndCustomEqs,
    checkToken
  };
};

export default useAuth;
