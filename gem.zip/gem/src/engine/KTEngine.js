import { PeakFilter, LowPassFilter, LowShelfFilter, HighShelfFilter, HighPassFilter } from './AudioMath';

// KTEngine: manages WebHID communication and packet building for KT/CB devices.
// Supports multiple protocols based on "Scheme Number".

export default class KTEngine {
  constructor(opts = {}) {
    this.device = null;
    this.schemeNo = '11'; // Default to CB protocol
    this.onLog = opts.onLog || (()=>{});
    this.onFeatureReport = opts.onFeatureReport || (()=>{}); // Callback for read data
    this.onEQData = opts.onEQData || (()=>{}); // Callback for EQ sync
    
    // Instantiate filters for CB protocol
    this.eqFilterPeak = new PeakFilter();
    this.eqFilterLowPass = new LowPassFilter();
    this.eqFilterLowShelf = new LowShelfFilter();
    this.eqFilterHighPass = new HighPassFilter();
    this.eqFilterHighShelf = new HighShelfFilter();

    this.globalGain = 0; // Store global gain (DAC Volume)
    this.currentBands = []; // Store current EQ bands
  }

  log(...args){
    try{ this.onLog(...args) }catch(e){ console.log(...args) }
  }

  setScheme(schemeNo) {
      this.schemeNo = String(schemeNo);
      this.log(`Engine protocol set to Scheme: ${this.schemeNo}`);
  }

  async attach(device) {
    this.device = device
    if (!device.opened) await device.open()

    // Log supported reports for diagnostics
    try {
      const inputReportIds = (device.collections || []).flatMap(c => (c.inputReports || []).map(r=>r.reportId))
      const outputReportIds = (device.collections || []).flatMap(c => (c.outputReports || []).map(r=>r.reportId))
      this.log('Device report summary: inputReportIds=', inputReportIds, 'outputReportIds=', outputReportIds)
    } catch(e) {
      this.log('Could not enumerate report IDs', e)
    }

    if (this.device.addEventListener) {
      this.device.addEventListener('inputreport', (ev)=>{
        this.handleInputReport(ev);
      })
    }
    this.log('Attached device', device.productName, device.vendorId, device.productId)
  }

  handleInputReport(ev) {
      const d = new Uint8Array(ev.data.buffer);
      const hex = Array.from(d).map(b=>b.toString(16).padStart(2,'0')).join(' ');
      this.log('IN', hex);
      
      // Emit raw for debugging
      this.onFeatureReport('__RAW__', hex);
      
      // KT Protocol Response Check (Scheme 17/19)
      // KT responses usually have 'R' (0x52) or 'W' (0x57) at index 4
      // Example: 04 00 00 00 52 ...
      if (d.length >= 5 && (d[4] === 0x52 || d[4] === 0x57)) {
          const verBytes = Array.from(d);
          this.onFeatureReport('firmwareVersionRaw', verBytes);

          // Handle EQ Read Response (0x52)
          if (d[4] === 0x52 && this.isKT()) {
              this.handleKTReadResponse(d);
          }
      }

      // CB Read Response
      if (d[0] === 0x80 && d[1] === 0x09) {
          this.handleCBReadResponse(d);
      }

      // Parse based on CB protocol (s2e)
      // d[1] is command ID for CB usually
      if (this.isCB()) {
          if (d[1] === 25) { // Filter Output Gain Mode
              const val = d[3] + 1;
              this.onFeatureReport('outputGainMode', val);
          }
          if (d[1] === 29) { // DAC Work Mode
              const val = d[3];
              this.onFeatureReport('dacWorkMode', val);
          }
          if (d[1] === 17) { // Filter Index
              const val = d[3] - 1; // 1-based in packet?
              this.onFeatureReport('filterIndex', val);
          }
          if (d[1] === 27) { // ENC Switch
              const val = d[3] === 1;
              this.onFeatureReport('encSwitch', val);
          }
          if (d[1] === 2) { // Mic Offset
              let val = d[4]; // d[4] seems to be the value based on snippet
              if (val > 127) val = val - 256;
              this.onFeatureReport('micOffset', val);
          }
          if (d[1] === 22) { // DAC Balance
              // Logic from snippet: if d[5]!=0 -> p=256-d[5], if d[3]==0 -> [0, p] else [0, -p]
              // This seems complex, just passing raw for now or simplified
              const channel = d[3]; // 0 or 1?
              const val = d[5];
              this.onFeatureReport('dacBalanceRaw', { channel, val });
          }
          
          // Check for Version Response (0x0C) in first few bytes
          // It might be at d[1] (standard) or d[0] (if report ID stripped)
          if (d[1] === 12 || d[0] === 12) { 
              // Just passing the raw bytes for now to be parsed in App
              // Capture enough bytes
              const verBytes = Array.from(d).slice(0, 10);
              this.onFeatureReport('firmwareVersionRaw', verBytes);
          }
      }
  }

  isCB() {
      return ['11', '13', '15', '16', '18', '20'].includes(this.schemeNo);
  }

  isKT() {
      return ['17', '19'].includes(this.schemeNo);
  }

  // send raw report
  async sendReport(payload) {
    if (!this.device) throw new Error('No device attached')
    
    // Report ID for these devices is typically 0x4B (75)
    const REPORT_ID = 0x4B;
    
    let data = payload;
    if (payload instanceof Array) data = new Uint8Array(payload);

    try {
      await this.device.sendReport(REPORT_ID, data)
      this.log('OUT', `ID=0x${REPORT_ID.toString(16)} ` + Array.from(data).map(b=>b.toString(16).padStart(2,'0')).join(' '))
      return
    } catch (err) {
      this.log('sendReport failed:', err.message)
      throw err
    }
  }

  intToByte(val, index) {
      return (val >> (index * 8)) & 255;
  }
  
  toSignedByte(t) {
      return t > 127 ? t - 256 : t;
  }

  // --- Feature Controls ---

  async setMicVolume(val) {
      this.log(`Setting Mic Volume: ${val}`);
      if (this.isCB()) {
          // [1, 2, 2, 128, val]
          await this.sendReport(new Uint8Array([1, 2, 2, 128, val]));
          await this.refreshToFlash();
      } else if (this.schemeNo === '17') { // KT02H20
          // [58, 0, 0, 0, 87, 0, val, val>>8, val>>16, val>>24]
          const pkt = new Uint8Array([58, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt[6] = this.toSignedByte(val & 255);
          pkt[7] = this.toSignedByte((val >> 8) & 255);
          pkt[8] = this.toSignedByte((val >> 16) & 255);
          pkt[9] = this.toSignedByte((val >> 24) & 255);
          await this.sendReport(pkt);
          // await this.refreshToFlash(); // Disabled to prevent device reboot/disconnect on mic volume change
      } else if (this.schemeNo === '19') { // KT0231H
          // Packet 1: [58, ...]
          const pkt1 = new Uint8Array([58, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt1[6] = this.toSignedByte(val & 255);
          pkt1[7] = this.toSignedByte((val >> 8) & 255);
          pkt1[8] = this.toSignedByte((val >> 16) & 255);
          pkt1[9] = this.toSignedByte((val >> 24) & 255);
          await this.sendReport(pkt1);
          // Packet 2: [24, ...]
          const pkt2 = new Uint8Array([24, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          await this.sendReport(pkt2);
          // await this.refreshToFlash(); // Disabled to prevent device reboot/disconnect on mic volume change
      }
  }

  async setDenoise(enabled) {
      if (!this.isCB()) return; // Only CB supports this in snippet
      this.log(`Setting Denoise: ${enabled}`);
      const val = enabled ? 1 : 0;
      await this.sendReport(new Uint8Array([1, 27, 1, val]));
      await this.refreshToFlash();
  }

  async setFilter(filterName) {
      if (!this.isCB()) return;
      this.log(`Setting Filter: ${filterName}`);
      let n = 1;
      switch(filterName) {
          case "FAST-LL": n = 1; break;
          case "FAST-PC": n = 2; break;
          case "SLOW-LL": n = 3; break;
          case "SLOW-PC": n = 4; break;
          case "NON-OS": n = 5; break;
          default: n = 1;
      }
      await this.sendReport(new Uint8Array([1, 17, 1, n]));
  }

  async setDacWorkMode(mode) {
      if (!this.isCB()) return;
      this.log(`Setting DAC Work Mode: ${mode}`);
      // mode: "0" or "1"
      let n = 1;
      if (mode === "0" || mode === 0) n = 0;
      if (mode === "1" || mode === 1) n = 1;
      await this.sendReport(new Uint8Array([1, 29, 1, n]));
  }

  async setDacOutputGain(mode) {
      if (!this.isCB()) return;
      this.log(`Setting DAC Output Gain Mode: ${mode}`);
      // mode: 1, 2, 3
      if (!mode || mode < 1 || mode > 3) return;
      const n = mode - 1;
      await this.sendReport(new Uint8Array([1, 25, 1, n]));
  }

  async setDacVolume(db) {
      if (db === undefined || db === null) return;
      if (!this.device) throw new Error('No device attached');

      const numericDb = Number(db);
      if (Number.isNaN(numericDb)) throw new Error('Invalid DAC volume value');

      this.globalGain = numericDb;
      this.log(`Setting DAC Volume (Global Gain): ${numericDb}dB`);

      if (this.schemeNo === '17') {
          // KT02H20 Protocol: Address 0x3B (59) is DacAnaGain_ALL
          // Values 0-15. 
          // 0: Mute
          // 1: -18dB ... 13: 0dB ... 15: +3dB
          // Step size approx 1.5dB
          
          let val = Math.round(13 + (numericDb / 1.5));
          if (val > 15) val = 15;
          if (val < 0) val = 0; // 0 is Mute
          
          this.log(`KT02H20 Volume: ${numericDb}dB -> Val ${val}`);

          // [59, 0, 0, 0, 87, 0, val, 0, 0, 0]
          const pkt = new Uint8Array([59, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt[6] = val;
          
          await this.sendReport(pkt);
          // await this.refreshToFlash(); 

      } else if (this.schemeNo === '19') {
          // KT0231H: Address 59 is EQ Band 4. Volume address unknown.
          this.log('Volume control not implemented for Scheme 19 (KT0231H)');
      } else if (this.isCB()) {
          // CB Protocol: Update EQ Offset (CMD 0x09, Byte 34)
          // We need to re-apply EQ with the new offset.
          // If we have current bands, use them.
          if (this.currentBands && this.currentBands.length > 0) {
              await this.applyEQ_CB(this.currentBands);
          } else {
              // If no bands loaded, maybe just send a dummy update or read first?
              // For now, we assume bands are loaded or will be loaded.
              this.log('No current bands to apply volume to. Waiting for EQ sync.');
          }
      }
  }

  async setDacBalance(left, right) {
      if (!this.isCB()) return;
      this.log(`Setting DAC Balance: L=${left}, R=${right}`);
      // Logic from snippet:
      // if t>0 (Left attenuation?): [1, 22, 4, 1, 0, -t, 0] then [1, 22, 4, 0, 0, 0, 0]
      // if n>0 (Right attenuation?): [1, 22, 4, 1, 0, 0, 0] then [1, 22, 4, 0, 0, -n, 0]
      // if 0,0: [1, 22, 4, 0, 1, 0, 0] then [1, 22, 4, 0, 0, 0, 0]
      
      if (left > 0) {
          const val = -1 * left;
          await this.sendReport(new Uint8Array([1, 22, 4, 1, 0, val, 0]));
          await this.sendReport(new Uint8Array([1, 22, 4, 0, 0, 0, 0]));
      } else if (right > 0) {
          await this.sendReport(new Uint8Array([1, 22, 4, 1, 0, 0, 0]));
          const val = -1 * right;
          await this.sendReport(new Uint8Array([1, 22, 4, 0, 0, val, 0]));
      } else {
          await this.sendReport(new Uint8Array([1, 22, 4, 0, 1, 0, 0]));
          await this.sendReport(new Uint8Array([1, 22, 4, 0, 0, 0, 0]));
      }
  }

  async refreshToFlash() {
      if (this.isCB()) {
          await new Promise(r => setTimeout(r, 1000));
          await this.sendReport(new Uint8Array([1, 1, 0]));
      } else if (this.schemeNo === '17') {
          await new Promise(r => setTimeout(r, 500));
          await this.sendReport(new Uint8Array([0, 0, 0, 0, 83, 0, 0, 0, 0, 0]));
      } else if (this.schemeNo === '19') {
          await new Promise(r => setTimeout(r, 500));
          await this.sendReport(new Uint8Array([0, 0, 0, 0, 83, 0, 0, 0, 0, 0]));
      }
  }

  async applyEQ(bands) {
      if (!this.device) throw new Error('No device');
      
      this.currentBands = bands; // Store for volume updates

      if (this.schemeNo === '17') {
          await this.applyEQ_KT02H20(bands);
      } else if (this.schemeNo === '19') {
          await this.applyEQ_KT0231H(bands);
      } else {
          await this.applyEQ_CB(bands);
      }
  }

  // --- Protocol: CB (Scheme 11, 13, 15, 16, 18, 20) ---
  async applyEQ_CB(bands) {
    this.log(`Applying EQ (CB Protocol) with ${bands.length} bands... Global Gain: ${this.globalGain}dB`);

    // 1. Send EQ Packets for each band
    for (let i = 0; i < bands.length; i++) {
        const b = bands[i];
        const freq = b.freq || b.fc;
        const q = b.q;
        const gain = b.gain;
        const type = b.type || 2; 

        let coeffs = [];
        switch (type) {
            case 1: coeffs = this.eqFilterLowShelf.computeIIRFilter(freq, q, gain); break;
            case 2: coeffs = this.eqFilterPeak.computeIIRFilter(freq, q, gain); break;
            case 3: coeffs = this.eqFilterHighShelf.computeIIRFilter(freq, q, gain); break;
            case 4: coeffs = this.eqFilterLowPass.computeIIRFilter(freq, q, gain); break;
            case 5: coeffs = this.eqFilterHighPass.computeIIRFilter(freq, q, gain); break;
            default: coeffs = this.eqFilterPeak.computeIIRFilter(freq, q, gain); break;
        }

        const pkt = new Uint8Array(36);
        pkt[0] = 1; pkt[1] = 9; pkt[2] = 4 + coeffs.length; pkt[3] = 0;
        pkt[4] = i & 255; pkt[5] = 0; pkt[6] = 0;

        for (let j = 0; j < coeffs.length; j++) {
            pkt[7 + j] = coeffs[j];
        }

        const qInt = Math.round(q * 256);
        const gainInt = Math.round(gain * 256);

        pkt[27] = this.intToByte(freq, 0);
        pkt[28] = this.intToByte(freq, 1);
        pkt[29] = this.intToByte(qInt, 0);
        pkt[30] = this.intToByte(qInt, 1);
        pkt[31] = this.intToByte(gainInt, 0);
        pkt[32] = this.intToByte(gainInt, 1);
        pkt[33] = type;
        
        // Offset (Global Gain)
        // Assuming 1 byte signed integer (dB)
        // Clamp to -128 to 127
        let offset = Math.round(this.globalGain);
        if (offset > 127) offset = 127;
        if (offset < -128) offset = -128;
        if (offset < 0) offset = 256 + offset; // Two's complement for byte
        
        pkt[34] = offset; 
        pkt[35] = 0; // tag

        await this.sendReport(pkt);
        await new Promise(r => setTimeout(r, 20));
    }

    // 2. Refresh to Memory
    await this.sendReport(new Uint8Array([1, 10, 4, 0, 0, 255, 255]));
    this.log('Sent Refresh to Memory');

    // 3. Refresh to Flash (Disabled to prevent device reboot/disconnect)
    // await new Promise(r => setTimeout(r, 1000));
    // await this.sendReport(new Uint8Array([1, 1, 0]));
    // this.log('Sent Refresh to Flash');
  }

  // --- Protocol: KT02H20 (Scheme 17) ---
  async applyEQ_KT02H20(bands) {
      this.log(`Applying EQ (KT02H20 Protocol) with ${bands.length} bands...`);
      
      // Save Tag ID (Default 0)
      // [2, 0, 0, 0, 87, 0, tag, tag>>8, tag>>16, tag>>24]
      const tagPkt = new Uint8Array([2, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
      await this.sendReport(tagPkt);

      const BASE_ADDR = 38;

      for (let i = 0; i < bands.length; i++) {
          const b = bands[i];
          const freq = b.freq || b.fc;
          const q = b.q;
          const gain = b.gain;
          
          // Map Standard Type (1-5) to KT Type (0-4)
          // Standard: 1=LS, 2=PK, 3=HS, 4=LP, 5=HP
          // KT: 0=PK, 1=LP, 2=HP, 3=LS, 4=HS
          let type = 0; // Default PK
          const t = b.type || 2;
          if (t === 1) type = 3; // LS
          else if (t === 2) type = 0; // PK
          else if (t === 3) type = 4; // HS
          else if (t === 4) type = 1; // LP
          else if (t === 5) type = 2; // HP

          const freqVal = Math.round(freq / 2);
          const qVal = Math.round(q * 1000);
          const gainVal = Math.round(gain * 10);
          
          // Packet 1: Gain & Freq
          // r[0] = base + ((i+1)*2 - 2) = base + 2*i
          const pkt1 = new Uint8Array([0, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt1[0] = BASE_ADDR + (2 * i);
          pkt1[6] = gainVal & 255;
          pkt1[7] = (gainVal >> 8) & 255;
          pkt1[8] = freqVal & 255;
          pkt1[9] = (freqVal >> 8) & 255;
          await this.sendReport(pkt1);

          // Packet 2: Q & Type
          // r[0] = base + ((i+1)*2 - 1) = base + 2*i + 1
          const pkt2 = new Uint8Array([0, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt2[0] = BASE_ADDR + (2 * i) + 1;
          pkt2[6] = qVal & 255;
          pkt2[7] = (qVal >> 8) & 255;
          pkt2[8] = 8 + (7 & type);
          pkt2[9] = 0;
          await this.sendReport(pkt2);
          
          await new Promise(r => setTimeout(r, 10));
      }

      // Refresh to Memory: [36, 0, 0, 0, 87, 0, 1, 0, 0, 0]
      await this.sendReport(new Uint8Array([36, 0, 0, 0, 87, 0, 1, 0, 0, 0]));
      this.log('Sent Refresh to Memory');

      // Refresh to Flash (Disabled to prevent device reboot/disconnect)
      // await new Promise(r => setTimeout(r, 500));
      // await this.sendReport(new Uint8Array([0, 0, 0, 0, 83, 0, 0, 0, 0, 0]));
      // this.log('Sent Refresh to Flash');
  }

  // --- Protocol: KT0231H (Scheme 19) ---
  async applyEQ_KT0231H(bands) {
      this.log(`Applying EQ (KT0231H Protocol) with ${bands.length} bands...`);

      // Save Tag ID (Default 0)
      // [22, 0, 0, 0, 87, 0, tag...]
      const tagPkt = new Uint8Array([22, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
      await this.sendReport(tagPkt);

      const BASE_ADDR = 53;

      for (let i = 0; i < bands.length; i++) {
          const b = bands[i];
          const freq = b.freq || b.fc;
          const q = b.q;
          const gain = b.gain;
          
          // Map Standard Type (1-5) to KT Type (0-4)
          let type = 0; // Default PK
          const t = b.type || 2;
          if (t === 1) type = 3; // LS
          else if (t === 2) type = 0; // PK
          else if (t === 3) type = 4; // HS
          else if (t === 4) type = 1; // LP
          else if (t === 5) type = 2; // HP

          const freqVal = Math.round(freq / 2);
          const qVal = Math.round(q * 1000);
          const gainVal = Math.round(gain * 10);

          // Packet 1
          const pkt1 = new Uint8Array([0, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt1[0] = BASE_ADDR + (2 * i);
          pkt1[6] = gainVal & 255;
          pkt1[7] = (gainVal >> 8) & 255;
          pkt1[8] = freqVal & 255;
          pkt1[9] = (freqVal >> 8) & 255;
          await this.sendReport(pkt1);

          // Packet 2
          const pkt2 = new Uint8Array([0, 0, 0, 0, 87, 0, 0, 0, 0, 0]);
          pkt2[0] = BASE_ADDR + (2 * i) + 1;
          pkt2[6] = qVal & 255;
          pkt2[7] = (qVal >> 8) & 255;
          pkt2[8] = 8 + (7 & type);
          pkt2[9] = 0;
          await this.sendReport(pkt2);

          await new Promise(r => setTimeout(r, 10));
      }

      // Refresh to Memory: [36, 0, 0, 0, 87, 0, 1, 0, 0, 0]
      await this.sendReport(new Uint8Array([36, 0, 0, 0, 87, 0, 1, 0, 0, 0]));
      this.log('Sent Refresh to Memory');

      // Refresh to Flash (Disabled to prevent device reboot/disconnect)
      // await new Promise(r => setTimeout(r, 500));
      // await this.sendReport(new Uint8Array([0, 0, 0, 0, 83, 0, 0, 0, 0, 0]));
      // this.log('Sent Refresh to Flash');
  }

  // --- Read EQ from Device ---
  async readEQ() {
      this.log('Reading EQ from device...');
      
      if (this.isCB()) {
          // CB Protocol: Read 10 bands using CMD 0x09 with Read Flag 0x80
          this.eqReadBufferCB = [];
          this.log('Reading CB EQ (10 bands)...');
          
          for (let i = 0; i < 10; i++) {
              const pkt = new Uint8Array(36);
              pkt[0] = 0x80; // Read Request
              pkt[1] = 0x09; // EQ Command
              pkt[2] = 0;    // Length
              pkt[3] = 0;
              pkt[4] = i;    // Band Index
              
              await this.sendReport(pkt);
              await new Promise(r => setTimeout(r, 50));
          }
      } else if (this.isKT()) {
          // KT Protocol: Read 5 bands (2 registers each)
          this.eqReadBuffer = {}; // Reset buffer
          const BASE_ADDR = this.schemeNo === '19' ? 53 : 38;
          
          this.log(`Reading KT EQ Registers starting at ${BASE_ADDR}...`);
          
          // We need to read 10 registers (5 bands * 2)
          for (let i = 0; i < 5; i++) {
              const addr1 = BASE_ADDR + (2 * i);
              const addr2 = BASE_ADDR + (2 * i) + 1;
              
              // Send Read for Addr 1
              await this.sendReport(new Uint8Array([addr1, 0, 0, 0, 0x52, 0, 0, 0, 0, 0]));
              await new Promise(r => setTimeout(r, 50)); // Small delay to prevent flooding
              
              // Send Read for Addr 2
              await this.sendReport(new Uint8Array([addr2, 0, 0, 0, 0x52, 0, 0, 0, 0, 0]));
              await new Promise(r => setTimeout(r, 50));
          }
      }
  }

  handleCBReadResponse(d) {
      // Packet Structure (Hypothetical based on Write):
      // [80, 09, Len, 0, BandIdx, 0, 0, ...Coeffs..., FreqL, FreqH, QL, QH, GainL, GainH, Type, ...]
      // Freq at 27, Q at 29, Gain at 31, Type at 33
      
      const bandIdx = d[4];
      if (bandIdx < 0 || bandIdx > 9) return;

      // Extract Freq (27, 28)
      const freq = d[27] | (d[28] << 8);
      
      // Extract Q (29, 30) -> / 256
      const qRaw = d[29] | (d[30] << 8);
      const q = parseFloat((qRaw / 256.0).toFixed(2));
      
      // Extract Gain (31, 32) -> / 256
      let gainRaw = d[31] | (d[32] << 8);
      // Signed 16-bit check
      if (gainRaw > 32767) gainRaw -= 65536;
      const gain = parseFloat((gainRaw / 256.0).toFixed(1));
      
      // Extract Type (33)
      const type = d[33];
      
      const band = { freq, q, gain, type, enabled: true };
      // this.log(`[CB Read] Band ${bandIdx}:`, band);
      
      if (!this.eqReadBufferCB) this.eqReadBufferCB = [];
      this.eqReadBufferCB[bandIdx] = band;
      
      // Check if we have all 10 bands (or at least enough to display)
      // We count how many valid objects we have
      const count = this.eqReadBufferCB.filter(b => b).length;
      
      if (count === 10) {
          this.log('All CB EQ bands received. Syncing UI...');
          // Ensure array is dense
          const finalBands = [];
          for(let i=0; i<10; i++) {
              finalBands.push(this.eqReadBufferCB[i] || { freq: 0, gain: 0, q: 0, type: 2 });
          }
          this.onEQData(finalBands);
          this.eqReadBufferCB = null;
      }
  }

  handleKTReadResponse(d) {
      const addr = d[0];
      const data = d.slice(6, 10); // 4 bytes of data
      
      if (!this.eqReadBuffer) this.eqReadBuffer = {};
      this.eqReadBuffer[addr] = data;
      
      // Check if we have all needed registers
      const BASE_ADDR = this.schemeNo === '19' ? 53 : 38;
      let complete = true;
      for(let i=0; i<10; i++) {
          if (!this.eqReadBuffer[BASE_ADDR + i]) {
              complete = false;
              break;
          }
      }
      
      if (complete) {
          this.log('All KT EQ registers received. Parsing...');
          this.parseKT_EQ(this.eqReadBuffer);
          this.eqReadBuffer = null; // Clear
      }
  }

  parseKT_EQ(buffer) {
      const BASE_ADDR = this.schemeNo === '19' ? 53 : 38;
      const bands = [];
      
      for (let i = 0; i < 5; i++) {
          const r1 = buffer[BASE_ADDR + 2*i];
          const r2 = buffer[BASE_ADDR + 2*i + 1];
          
          // R1: Gain (0-1), Freq (2-3)
          const gainRaw = r1[0] | (r1[1] << 8);
          // Handle signed 16-bit
          const gain = (gainRaw > 32767 ? gainRaw - 65536 : gainRaw) / 10.0;
          
          const freqRaw = r1[2] | (r1[3] << 8);
          const freq = freqRaw * 2;
          
          // R2: Q (0-1), Type (2)
          const qRaw = r2[0] | (r2[1] << 8);
          const q = qRaw / 1000.0;
          
          const typeRaw = r2[2] & 0x07;
          // Map KT Type to Standard
          // KT: 0=PK, 1=LP, 2=HP, 3=LS, 4=HS
          // Std: 1=LS, 2=PK, 3=HS, 4=LP, 5=HP
          let type = 2;
          if (typeRaw === 0) type = 2;
          else if (typeRaw === 1) type = 4;
          else if (typeRaw === 2) type = 5;
          else if (typeRaw === 3) type = 1;
          else if (typeRaw === 4) type = 3;
          
          bands.push({ freq, q, gain, type, enabled: true });
      }
      
      this.log('Parsed EQ Bands:', bands);
      this.onEQData(bands);
  }

  async resetEQ() {
      this.log('Resetting EQ to Flat Defaults...');
      let bands = [];
      
      if (this.isCB()) {
          // Standard 10-Band ISO Frequencies
          const freqs = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
          bands = freqs.map((f, i) => ({
              id: i + 1,
              freq: f,
              q: 1.41, // Standard Q for 1-octave
              gain: 0,
              type: 2, // Peak
              enabled: true
          }));
      } else {
          // KT 5-Band Defaults (Based on device logs: 625, 1250, 2500, 5000, 10000)
          const freqs = [625, 1250, 2500, 5000, 10000];
          bands = freqs.map((f, i) => ({
              id: i + 1,
              freq: f,
              q: 1.0,
              gain: 0,
              type: 2, // Peak
              enabled: true
          }));
      }
      
      await this.applyEQ(bands);
      this.log('EQ Reset Complete. Reading back...');
      await new Promise(r => setTimeout(r, 500));
      await this.readEQ();
  }
}


