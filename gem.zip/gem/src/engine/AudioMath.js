
export class BaseFilter {
    computeIIRFilter(freq, q, gain) {
        throw new Error("computeIIRFilter method must be implemented in subclass");
    }
    quantizer(b, a) {
        throw new Error("quantizer method must be implemented in subclass");
    }
}

export class PeakFilter extends BaseFilter {
    computeIIRFilter(freq, q, gain) {
        const o = new Array(20).fill(0);
        const r = freq;
        const s = 96000; // Sample Rate
        const l = Math.sqrt(Math.pow(10, gain / 20));
        const i = 2 * Math.PI * r / s;
        const u = Math.sin(i) / (2 * q);
        const d = 1 + u * l;
        const f = -2 * Math.cos(i);
        const p = 1 - u * l;
        const h = 1 + u / l;
        const m = -2 * Math.cos(i);
        const v = 1 - u / l;
        const _ = [d / h, f / h, p / h];
        const g = [1, m / h, v / h];
        const x = this.quantizer(g, _);
        let y = 0;
        for (let b = 0; b < x.length; b++) {
            o[y++] = x[b] >> 0 & 255;
            o[y++] = x[b] >> 8 & 255;
            o[y++] = x[b] >> 16 & 255;
            o[y++] = x[b] >> 24 & 255;
        }
        return o;
    }
    quantizer(t, n) {
        const o = new Array(5).fill(0);
        const r = new Array(t.length).fill(0);
        const s = new Array(n.length).fill(0);
        for (let l = 0; l < t.length; l++) r[l] = Math.round(t[l] * (1 << 30));
        for (let l = 0; l < n.length; l++) s[l] = Math.round(n[l] * (1 << 30));
        o[0] = s[0];
        o[1] = s[1];
        o[2] = s[2];
        o[3] = -r[1];
        o[4] = -r[2];
        return o;
    }
}

export class LowPassFilter extends BaseFilter {
    computeIIRFilter(freq, q, gain) {
        const o = new Array(20).fill(0);
        const s = 2 * Math.PI * freq / 96000;
        const l = Math.sin(s) / (2 * q);
        const i = (1 - Math.cos(s)) / 2;
        const u = 1 - Math.cos(s);
        const d = (1 - Math.cos(s)) / 2;
        const f = 1 + l;
        const p = -2 * Math.cos(s);
        const h = 1 - l;
        const m = [i / f, u / f, d / f];
        const v = [1, p / f, h / f];
        const _ = this.quantizer(v, m);
        let g = 0;
        for (let x = 0; x < _.length; x++) {
            o[g++] = _[x] >> 0 & 255;
            o[g++] = _[x] >> 8 & 255;
            o[g++] = _[x] >> 16 & 255;
            o[g++] = _[x] >> 24 & 255;
        }
        return o;
    }
    quantizer(t, n) {
        const o = new Array(5).fill(0);
        const r = new Array(t.length).fill(0);
        const s = new Array(n.length).fill(0);
        for (let l = 0; l < t.length; l++) r[l] = Math.round(t[l] * (1 << 30));
        for (let l = 0; l < n.length; l++) s[l] = Math.round(n[l] * (1 << 30));
        o[0] = s[0];
        o[1] = s[1];
        o[2] = s[2];
        o[3] = -r[1];
        o[4] = -r[2];
        return o;
    }
}

export class LowShelfFilter extends BaseFilter {
    computeIIRFilter(freq, q, gain) {
        const o = new Array(20).fill(0);
        const r = 96000;
        const s = Math.pow(10, gain / 40);
        const l = 2 * Math.PI * freq / r;
        const i = Math.sin(l) / 2 * Math.sqrt((s + 1 / s) * (1 / 0.8 - 1) + 2); // Note: 1/.8 is hardcoded in source
        const u = s * (s + 1 - (s - 1) * Math.cos(l) + 2 * Math.sqrt(s) * i);
        const d = 2 * s * (s - 1 - (s + 1) * Math.cos(l));
        const f = s * (s + 1 - (s - 1) * Math.cos(l) - 2 * Math.sqrt(s) * i);
        const p = s + 1 + (s - 1) * Math.cos(l) + 2 * Math.sqrt(s) * i;
        const h = -2 * (s - 1 + (s + 1) * Math.cos(l));
        const m = s + 1 + (s - 1) * Math.cos(l) - 2 * Math.sqrt(s) * i;
        const v = [u / p, d / p, f / p];
        const _ = [1, h / p, m / p];
        const g = this.quantizer(_, v);
        let x = 0;
        for (let y = 0; y < g.length; y++) {
            o[x++] = g[y] >> 0 & 255;
            o[x++] = g[y] >> 8 & 255;
            o[x++] = g[y] >> 16 & 255;
            o[x++] = g[y] >> 24 & 255;
        }
        return o;
    }
    quantizer(t, n) {
        const o = new Array(5).fill(0);
        const r = new Array(t.length).fill(0);
        const s = new Array(n.length).fill(0);
        for (let l = 0; l < t.length; l++) r[l] = Math.round(t[l] * (1 << 30));
        for (let l = 0; l < n.length; l++) s[l] = Math.round(n[l] * (1 << 30));
        o[0] = s[0];
        o[1] = s[1];
        o[2] = s[2];
        o[3] = -r[1];
        o[4] = -r[2];
        return o;
    }
}

export class HighShelfFilter extends BaseFilter {
    constructor(config = {}) {
        super();
        this.config = {
            sampleRate: 96000,
            maxGain: 12,
            minQ: 0.5,
            maxQ: 5,
            scaleBits: 27,
            headroom: 0.85,
            ...config
        };
    }
    computeIIRFilter(freq, q, gain) {
        const o = this._validateParameters(freq, q, gain);
        const { b: r, a: s } = this._calculateCoefficients(o.freq, o.q, o.gain);
        // this._checkStability(r, s); // Skipping stability check for now to match minified flow
        const l = this.quantizer(s, r);
        return this._generateByteStream(l);
    }
    quantizer(t, n) {
        const { scaleBits: a } = this.config;
        const o = (1 << a) - 1;
        const r = new Int32Array(5);
        const s = l => {
            const i = Math.round(l * (1 << a));
            return Math.max(-o, Math.min(o, i));
        };
        r[0] = s(n[0]);
        r[1] = s(n[1]);
        r[2] = s(n[2]);
        r[3] = -s(t[1]);
        r[4] = -s(t[2]);
        return r;
    }
    _validateParameters(t, n, a) {
        const { minQ: o, maxQ: r, maxGain: s, sampleRate: l } = this.config;
        const i = l / 2;
        const u = Math.max(20, Math.min(t, i * 0.99));
        const d = Math.max(o, Math.min(r, n));
        const f = Math.max(-s, Math.min(s, a));
        const p = f * this.config.headroom;
        return { freq: u, q: d, gain: p };
    }
    _calculateCoefficients(t, n, a) {
        const { sampleRate: o } = this.config;
        const r = Math.pow(10, Math.abs(a) / 40);
        const s = Math.sqrt(r);
        const l = 2 * Math.PI * t / o;
        const i = Math.cos(l);
        const d = Math.sin(l) / 2 * Math.sqrt((r + 1 / r) * (1 / n - 1) + 2);
        const f = r * (r + 1 + (r - 1) * i + 2 * s * d);
        const p = -2 * r * (r - 1 + (r + 1) * i);
        const h = r * (r + 1 + (r - 1) * i - 2 * s * d);
        const m = r + 1 - (r - 1) * i + 2 * s * d;
        const v = 2 * (r - 1 - (r + 1) * i);
        const _ = r + 1 - (r - 1) * i - 2 * s * d;
        const g = a >= 0 ? 1 : -1;
        return { b: [g * f / m, g * p / m, g * h / m], a: [1, v / m, _ / m] };
    }
    _generateByteStream(t) {
        const n = new Array(20).fill(0);
        for (let a = 0; a < t.length; a++) {
            const o = a * 4;
            n[o] = t[a] & 255;
            n[o + 1] = t[a] >> 8 & 255;
            n[o + 2] = t[a] >> 16 & 255;
            n[o + 3] = t[a] >> 24 & 255;
        }
        return n;
    }
}

export class HighPassFilter extends BaseFilter {
    computeIIRFilter(freq, q, gain) {
        const o = new Array(20).fill(0);
        const s = 2 * Math.PI * freq / 96000;
        const l = Math.sin(s) / (2 * q);
        const i = (1 + Math.cos(s)) / 2;
        const u = -(1 + Math.cos(s));
        const d = (1 + Math.cos(s)) / 2;
        const f = 1 + l;
        const p = -2 * Math.cos(s);
        const h = 1 - l;
        const m = [i / f, u / f, d / f];
        const v = [1, p / f, h / f];
        const _ = this.quantizer(v, m);
        let g = 0;
        for (let x = 0; x < _.length; x++) {
            o[g++] = _[x] >> 0 & 255;
            o[g++] = _[x] >> 8 & 255;
            o[g++] = _[x] >> 16 & 255;
            o[g++] = _[x] >> 24 & 255;
        }
        return o;
    }
    quantizer(t, n) {
        const o = new Array(5).fill(0);
        const r = new Array(t.length).fill(0);
        const s = new Array(n.length).fill(0);
        for (let l = 0; l < t.length; l++) r[l] = Math.round(t[l] * (1 << 30));
        for (let l = 0; l < n.length; l++) s[l] = Math.round(n[l] * (1 << 30));
        o[0] = s[0];
        o[1] = s[1];
        o[2] = s[2];
        o[3] = -r[1];
        o[4] = -r[2];
        return o;
    }
}
