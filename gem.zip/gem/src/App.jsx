import React, { useState, useEffect, useCallback } from 'react';
import Dashboard from './components/layout/Dashboard';
import useAuth from './hooks/useAuth';
import { useHID } from './hooks/useHID';
import ToastContainer from './components/common/Toast';

// Initial state will be empty until a device connects
const INITIAL_EQ_BANDS = [];

const App = () => {
    const [deviceStatus, setDeviceStatus] = useState('Disconnected');
    const [deviceName, setDeviceName] = useState('N/A');
    const [deviceFirmware, setDeviceFirmware] = useState('N/A');
    const [toasts, setToasts] = useState([]);
    const [eqBands, setEqBands] = useState(INITIAL_EQ_BANDS);
    const auth = useAuth();
    
    // HID Hook
    const { 
        device, 
        isConnected, 
        requestDevice, 
        disconnectDevice, 
        sendReport, 
        getPairedDevices, 
        connectToDevice 
    } = useHID();

    const addToast = useCallback((message, type = 'info') => {
        const id = Date.now() + Math.random();
        setToasts(prev => [...prev, { id, message, type }]);
    }, []);

    const removeToast = useCallback((id) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    }, []);

    const pushCommand = useCallback((newCommand, clear = false) => {
        if (clear) return;
        
        // Filter verbose logs
        if (newCommand.startsWith('[HID IN]') || 
            newCommand.startsWith('[Device Report]') || 
            newCommand.startsWith('[KTEngine]')) {
            return;
        }

        // Filter specific unnecessary info popups per user request
        if (newCommand.startsWith('Fetched product info:') ||
            newCommand.startsWith('Found Scheme') ||
            newCommand.startsWith('No EQ info found') ||
            newCommand.startsWith('Using Scheme band count') ||
            newCommand.startsWith('[Firmware] Probing') ||
            newCommand.startsWith('[Firmware] Raw') ||
            newCommand.startsWith('[Firmware] Version detected') ||
            newCommand.startsWith('[Firmware] KT Version') ||
            (newCommand.startsWith('[API]') && !newCommand.toLowerCase().includes('error'))) {
            return;
        }

        let type = 'info';
        const lowerCmd = newCommand.toLowerCase();
        if (lowerCmd.includes('error') || lowerCmd.includes('failed')) type = 'error';
        else if (lowerCmd.includes('success') || lowerCmd.includes('connected') || lowerCmd.includes('complete') || lowerCmd.includes('saved') || lowerCmd.includes('shared')) type = 'success';
        else if (lowerCmd.includes('warning') || lowerCmd.includes('disconnected')) type = 'warning';

        addToast(newCommand, type);
    }, [addToast]);

    // Sync HID state with App state
    useEffect(() => {
        if (isConnected && device) {
            setDeviceStatus('Connected');
            setDeviceName(device.productName);
            addToast(`HID Connected: ${device.productName}`, 'success');
            
            // Firmware version reading is not yet implemented for WebHID
            // We set it to null so the UI shows "Unknown" or tries to fetch it if possible
            setDeviceFirmware(null); 
        } else if (!isConnected && deviceStatus === 'Connected') {
            setDeviceStatus('Disconnected');
            setDeviceName('N/A');
            setDeviceFirmware('N/A');
            addToast('HID Disconnected', 'warning');
        }
    }, [isConnected, device, deviceStatus, addToast]);

    return (
        <>
            <Dashboard
                auth={auth}
                deviceStatus={deviceStatus}
                setDeviceStatus={setDeviceStatus}
                deviceName={deviceName}
                setDeviceName={setDeviceName}
                deviceFirmware={deviceFirmware}
                setDeviceFirmware={setDeviceFirmware}
                pushCommand={pushCommand}
                notify={addToast}
                eqBands={eqBands}
                setEqBands={setEqBands}
                // HID Props
                device={device}
                requestDevice={requestDevice}
                disconnectDevice={disconnectDevice}
                getPairedDevices={getPairedDevices}
                connectToDevice={connectToDevice}
                sendReport={sendReport}
            />
            <ToastContainer toasts={toasts} removeToast={removeToast} />
        </>
    );
};

export default App;
