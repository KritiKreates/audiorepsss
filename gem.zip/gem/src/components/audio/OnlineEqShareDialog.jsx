import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Share2, AlertCircle, Save } from 'lucide-react';

const OnlineEqShareDialog = ({ isOpen, onClose, auth, eqData, onShareSuccess, mode = 'SHARE' }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [imagePreview, setImagePreview] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    const isSaveMode = mode === 'SAVE';

    useEffect(() => {
        if (eqData?.imgBlob) {
            const url = URL.createObjectURL(eqData.imgBlob);
            setImagePreview(url);
            return () => URL.revokeObjectURL(url);
        }
    }, [eqData]);

    if (!isOpen) return null;

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title.trim()) {
            setError('Please enter a title');
            return;
        }
        if (!isSaveMode && !description.trim()) {
            setError('Please enter a description');
            return;
        }

        setIsSubmitting(true);
        setError('');

        try {
            if (isSaveMode) {
                // Save Mode (Private)
                const saveData = {
                    productId: eqData.productId,
                    pid: eqData.pid,
                    vid: eqData.vid,
                    eqName: title,
                    eqNameCn: title,
                    eqNameEn: title,
                    name: title,
                    gain: 0,
                    del: 0,
                    freqs: eqData.frequencies,
                    qs: eqData.qs,
                    gains: eqData.gains,
                    filterTypes: eqData.filterTypes || new Array(eqData.frequencies.length).fill(2)
                };

                const res = await auth.saveUserEQ(saveData);
                if (res && (res.code === 200 || res.code === 0)) {
                    if (onShareSuccess) onShareSuccess();
                    onClose();
                } else {
                    setError(res?.msg || 'Failed to save EQ');
                }

            } else {
                // Share Mode (Community)
                let imageUrl = '';
                if (eqData.imgBlob) {
                    const file = new File([eqData.imgBlob], "eq_graph.png", { type: "image/png" });
                    const uploadRes = await auth.uploadEqShareGraph(file);
                    if (uploadRes && (uploadRes.code === 200 || uploadRes.code === 0)) {
                        if (typeof uploadRes.data === 'string') {
                            imageUrl = uploadRes.data;
                        } else if (uploadRes.data && uploadRes.data.url) {
                            imageUrl = uploadRes.data.url;
                        } else {
                            imageUrl = uploadRes.data.url || uploadRes.data; 
                        }
                    } else {
                        throw new Error(uploadRes?.msg || 'Failed to upload image');
                    }
                }

                const shareData = {
                    productId: eqData.productId,
                    pid: eqData.pid,
                    vid: eqData.vid,
                    eqName: title,
                    title: title,
                    description: description,
                    img: imageUrl,
                    gain: 0,
                    del: 0,
                    freqs: eqData.frequencies,
                    qs: eqData.qs,
                    gains: eqData.gains,
                    filterTypes: eqData.filterTypes || new Array(eqData.frequencies.length).fill(2)
                };

                const res = await auth.createEQShareInfo(shareData);
                
                if (res && (res.code === 200 || res.code === 0)) {
                    if (onShareSuccess) onShareSuccess();
                    onClose();
                } else {
                    setError(res?.msg || 'Failed to share EQ');
                }
            }
        } catch (err) {
            setError(err.message || 'An error occurred');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
                <div className="flex justify-between items-center p-4 border-b bg-indigo-50">
                    <h3 className="text-lg font-semibold text-indigo-900 flex items-center">
                        {isSaveMode ? <Save className="w-5 h-5 mr-2" /> : <Share2 className="w-5 h-5 mr-2" />}
                        {isSaveMode ? 'Save Custom EQ' : 'Share EQ Profile'}
                    </h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    {error && (
                        <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm flex items-center">
                            <AlertCircle className="w-4 h-4 mr-2" /> {error}
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                        <input
                            type="text"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder={isSaveMode ? "e.g., My Custom Preset" : "e.g., Bass Boost for Rock"}
                            maxLength={50}
                        />
                    </div>

                    {!isSaveMode && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                            <textarea
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-24 resize-none"
                                placeholder="Describe your EQ settings..."
                                maxLength={200}
                            />
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Graph Preview</label>
                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center bg-gray-50">
                            {imagePreview ? (
                                <img src={imagePreview} alt="Preview" className="max-h-32 mx-auto rounded" />
                            ) : (
                                <div className="text-gray-500 text-sm">
                                    {eqData?.imgBlob ? 'Generating preview...' : 'No preview available'}
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="pt-2">
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="w-full py-2 px-4 bg-indigo-600 text-white font-semibold rounded-lg shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-400 transition"
                        >
                            {isSubmitting ? 'Processing...' : (isSaveMode ? 'Save Preset' : 'Share EQ')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default OnlineEqShareDialog;
