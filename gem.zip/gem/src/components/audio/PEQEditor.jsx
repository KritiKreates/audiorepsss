import React, { useState, useEffect, useCallback, useRef } from 'react'
import { Sliders, Zap, Save, Globe, Share2, User, Users, List, Download, Trash2, Search, ThumbsUp, Heart, Flag } from 'lucide-react'
import PEQGraph from './PEQGraph'
import OnlineEqShareDialog from './OnlineEqShareDialog';
import { TRANSLATIONS } from '../../constants/translations';

const PEQEditor = ({ 
    bands, 
    setBands, 
    onSyncComplete,
    deviceStatus, 
    pushCommand, 
    engine, 
    auth, 
    device, 
    deviceName,
    volumeMin = -12,
    volumeMax = 12,
    volumeStep = 0.5,
    peqMin = -10,
    peqMax = 10,
    language = 'en',
    masterVolume,
    setMasterVolume,
    productDetails
}) => {
    const t = TRANSLATIONS[language] || TRANSLATIONS.en;
    const [activeTab, setActiveTab] = useState('PRESETS'); // PRESETS, CUSTOM, COMMUNITY, SHARED
    const [presets, setPresets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showShareDialog, setShowShareDialog] = useState(false);
    const [shareData, setShareData] = useState(null);
    const [dialogMode, setDialogMode] = useState('SHARE'); // 'SHARE' or 'SAVE'
    const [searchQuery, setSearchQuery] = useState('');
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const graphRef = useRef(null);
    // const [masterVolume, setMasterVolume] = useState(0); // Lifted to Dashboard

    const handleBandChange = (index, field, value) => {
        const newBands = [...bands]
        if (field === 'enabled') newBands[index][field] = value
        else newBands[index][field] = parseFloat(value) || 0
        setBands(newBands)
    }

    const pushEQToDevice = async () => {
        if (!engine) {
            pushCommand('Engine not ready or device not connected');
            return;
        }
        
        try {
            pushCommand('Applying EQ...');
            await engine.applyEQ(bands);
            pushCommand('EQ applied successfully.');
            if (onSyncComplete) onSyncComplete();
        } catch (err) {
            pushCommand(`Failed to apply EQ: ${err.message}`);
            console.error(err);
        }
    }

    const getDeviceIds = useCallback(() => {
        // Use connected device IDs or fallbacks for testing
        const pid = device?.productId ? `0x${device.productId.toString(16).toUpperCase()}` : "0x12C1";
        const vid = device?.vendorId ? `0x${device.vendorId.toString(16).toUpperCase()}` : "0x3302";
        return { pid, vid };
    }, [device?.productId, device?.vendorId]);

    const fetchPresets = useCallback(async (pageNum = 1, reset = false) => {
        console.log(`[FetchPresets] Starting fetch for ${activeTab} page ${pageNum}`);
        
        if (reset) {
            setPresets([]); // Clear immediately to prevent showing stale data (e.g. previous user's likes)
        }

        if (!auth || !auth.token) {
            if (activeTab !== 'PRESETS') { 
                 // If not logged in, non-public tabs might fail or return empty
                 // But we let the API call handle the 401/error
            }
        }
        
        setLoading(true);
        const { pid, vid } = getDeviceIds();
        const productId = productDetails?.id || productDetails?.Id || 134;
        let result = null;

        try {
            if (activeTab === 'PRESETS') {
                // Default System Presets
                result = await auth.queryEQListByPidAndVid({ pid, vid });
            } else if (activeTab === 'CUSTOM') {
                // User's Private Presets
                // Sending empty object as per API docs, then filtering client-side
                console.log(`[FetchPresets] Fetching CUSTOM (all)`);
                result = await auth.getUserEQList({ _t: Date.now() });
            } else if (activeTab === 'COMMUNITY') {
                // Public Shared Presets
                result = await auth.queryAllEQShareInfoList({ 
                    page: pageNum, 
                    limit: 20, 
                    sortType: 1, // Latest
                    title: searchQuery,
                    pid, vid,
                    _t: Date.now() // Prevent caching
                });
            } else if (activeTab === 'SHARED') {
                // User's Shared Presets
                // Sending empty object as per API docs, then filtering client-side
                console.log(`[FetchPresets] Fetching SHARED (all)`);
                result = await auth.queryUserEQShareInfoList({ _t: Date.now() });
            }

            if (result && (result.code === 200 || result.code === 0)) {
                let list = [];
                console.log(`[FetchPresets] Tab: ${activeTab}, Result:`, result);
                
                list = result.data?.list || result.data || [];

                // Filter by current device PID/VID for CUSTOM and SHARED
                if (activeTab === 'CUSTOM' || activeTab === 'SHARED') {
                    list = list.filter(item => 
                        (item.pid && item.pid.toLowerCase() === pid.toLowerCase()) && 
                        (item.vid && item.vid.toLowerCase() === vid.toLowerCase())
                    );
                }

                // Normalize data structure
                const normalizedList = list.map(item => {
                    // Determine author name
                    let authorName = item.userInfo?.nickName || item.userInfo?.email || item.username;
                    
                    // For CUSTOM tab, the author is always the current user
                    if (activeTab === 'CUSTOM') {
                        authorName = auth.user?.nickName || auth.user?.email || auth.user?.username || 'Me';
                    }

                    // Fix name duplication (e.g. "Bass:Bass") and prioritize English name
                    let displayName = item.eqNameEn || item.eqName || item.title || item.eqNameCn || 'Untitled';
                    if (displayName && typeof displayName === 'string' && displayName.includes(':')) {
                        const parts = displayName.split(':');
                        // If parts are identical (case-insensitive), use one
                        if (parts.length === 2 && parts[0].trim().toLowerCase() === parts[1].trim().toLowerCase()) {
                            displayName = parts[0].trim();
                        }
                    }
                    
                    return {
                        ...item,
                        id: item.id,
                        name: displayName,
                        author: authorName || 'Audiocular Team',
                        isShared: activeTab === 'SHARED' || activeTab === 'COMMUNITY',
                        likeCount: item.likeCount || item.likes || 0, 
                        collectCount: item.collectCount || item.collects || 0,
                        isLiked: item.isLiked || item.isLike || false,
                        isCollected: item.isCollected || item.isCollect || false
                    };
                });

                if (reset) {
                    setPresets(normalizedList);
                } else {
                    setPresets(prev => [...prev, ...normalizedList]);
                }
                
                if (activeTab === 'COMMUNITY' || activeTab === 'SHARED') {
                    setHasMore(normalizedList.length === 20);
                } else {
                    setHasMore(false);
                }
            } else {
                if (reset) setPresets([]);
            }
        } catch (err) {
            console.error("Error fetching presets:", err);
            if (reset) setPresets([]);
        } finally {
            setLoading(false);
        }
    }, [auth, activeTab, getDeviceIds, searchQuery, productDetails]);

    useEffect(() => {
        setPage(1);
        fetchPresets(1, true);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeTab, auth.token, device?.productId, device?.vendorId, productDetails?.id, productDetails?.Id]);

    // Ensure user details (nickname) are fetched if missing
    useEffect(() => {
        if (auth?.token && !auth.user?.nickName) {
            auth.getUserDetail().catch(console.error);
        }
    }, [auth?.token, auth?.user?.nickName]);

    useEffect(() => {
        if (engine && engine.setDacVolume) {
            engine.setDacVolume(masterVolume).catch(err => console.error("Failed to set volume:", err));
        }
    }, [masterVolume, engine]);

    const handleSaveEQ = async () => {
        const showMessage = (msg) => pushCommand(`[UI Message] ${msg}`);

        if (!auth || !auth.token) {
            showMessage("Please log in to save EQ presets.");
            return;
        }
        
        if (bands.length === 0) {
             showMessage("Cannot save: No device connected, EQ band configuration is unknown.");
            return;
        }

        // Prepare data for saving
        const productId = productDetails?.id || productDetails?.Id || 134;
        
        let imgBlob = null;
        if (graphRef.current) {
            try {
                imgBlob = await graphRef.current.getGraphImage();
            } catch (e) {
                console.error("Failed to capture graph image", e);
            }
        }

        setShareData({
            productId: productId,
            vid: getDeviceIds().vid,
            pid: getDeviceIds().pid,
            productName: deviceName,
            frequencies: bands.map(b => b.freq),
            gains: bands.map(b => b.gain),
            qs: bands.map(b => b.q),
            filterTypes: bands.map(b => b.type || 2),
            bands: bands.length,
            imgBlob: imgBlob
        });

        setDialogMode('SAVE');
        setShowShareDialog(true);
    };

    const handleDeleteEQ = async (id) => {
        if (!window.confirm('Delete this preset?')) return;
        let result;
        if (activeTab === 'CUSTOM') {
            result = await auth.deleteUserEQ(id);
        } else if (activeTab === 'SHARED') {
            result = await auth.deleteEQShareInfo({ id });
        }

        if (result && (result.code === 200 || result.code === 0)) {
            pushCommand(`[UI Message] EQ preset deleted.`);
            fetchPresets(1, true);
        } else {
            pushCommand(`[UI Message] Failed to delete EQ: ${result?.message || 'Unknown error'}`);
        }
    };

    const handleApplyEQ = (eq) => {
        let freqs = eq.freqs || eq.frequencies;
        let gains = eq.gains;
        let qs = eq.qs;

        // Handle string format if necessary (API sometimes returns strings)
        if (typeof freqs === 'string') freqs = freqs.split(',').map(Number);
        if (typeof gains === 'string') gains = gains.split(',').map(Number);
        if (typeof qs === 'string') qs = qs.split(',').map(Number);

        if (!freqs || !gains) {
            pushCommand('[Error] Invalid EQ data format.');
            return;
        }

        // If qs is missing, default to 1.414
        if (!qs || qs.length !== freqs.length) qs = new Array(freqs.length).fill(1.414);
        
        const newBands = freqs.map((f, i) => ({
            id: i + 1,
            freq: f,
            q: qs[i],
            gain: gains[i],
            type: 'PEAKING', // Assumption
            enabled: true
        }));
        
        setBands(newBands);
        pushCommand(`[UI Message] Applied EQ Preset: ${eq.name}`);
    };

    const openShareDialog = async (eq) => {
        // Prepare data for sharing
        const productId = productDetails?.id || productDetails?.Id || 134;
        
        let imgBlob = null;
        if (graphRef.current) {
            try {
                imgBlob = await graphRef.current.getGraphImage();
            } catch (e) {
                console.error("Failed to capture graph image", e);
            }
        }

        // If sharing from current bands (Save & Share) or from an existing custom preset
        if (eq) {
             // Share existing custom preset
             setShareData({
                 productId: productId,
                 vid: getDeviceIds().vid,
                 pid: getDeviceIds().pid,
                 productName: deviceName,
                 frequencies: eq.freqs,
                 gains: eq.gains,
                 qs: eq.qs,
                 filterTypes: eq.filterTypes || new Array(eq.freqs.length).fill(2),
                 bands: eq.freqs.length,
                 name: eq.name,
                 id: eq.id, // Original ID if needed
                 imgBlob: imgBlob
             });
        } else {
            // Share current settings
            setShareData({
                productId: productId,
                vid: getDeviceIds().vid,
                pid: getDeviceIds().pid,
                productName: deviceName,
                frequencies: bands.map(b => b.freq),
                gains: bands.map(b => b.gain),
                qs: bands.map(b => b.q),
                filterTypes: bands.map(b => b.type || 2),
                bands: bands.length,
                imgBlob: imgBlob
            });
        }
        setDialogMode('SHARE');
        setShowShareDialog(true);
    };

    const handleLike = async (eq, isLiked) => {
        if (!auth.token) return pushCommand('[UI Message] Please login to like.');
        let res;
        // Send eqId as per API docs
        const payload = { eqId: eq.id };

        if (isLiked) {
            res = await auth.cancelLikeEQ(payload);
        } else {
            res = await auth.likeEQ(payload);
        }
        
        if (res && (res.code === 200 || res.code === 0)) {
            // Update local state
            setPresets(prev => prev.map(p => {
                if (p.id === eq.id) {
                    return { 
                        ...p, 
                        likeCount: isLiked ? (p.likeCount - 1) : (p.likeCount + 1),
                        isLiked: !isLiked 
                    };
                }
                return p;
            }));
        }
    };

    const handleCollect = async (eq, isCollected) => {
        if (!auth.token) return pushCommand('[UI Message] Please login to collect.');
        let res;
        // Send eqId as per API docs
        const payload = { eqId: eq.id };

        if (isCollected) {
            res = await auth.cancelCollectEQ(payload);
        } else {
            res = await auth.collectEQ(payload);
        }

        if (res && (res.code === 200 || res.code === 0)) {
             setPresets(prev => prev.map(p => {
                if (p.id === eq.id) {
                    return { 
                        ...p, 
                        collectCount: isCollected ? (p.collectCount - 1) : (p.collectCount + 1),
                        isCollected: !isCollected 
                    };
                }
                return p;
            }));
            pushCommand(`[UI Message] ${isCollected ? 'Removed from' : 'Added to'} collection.`);
        }
    };

    const handleReadEQ = async () => {
        if (!engine) return;
        try {
            // Clear unsaved flag so we accept the read result
            if (onSyncComplete) onSyncComplete();
            
            pushCommand('Reading EQ from device...');
            await engine.readEQ();
            pushCommand('EQ read successfully.');
        } catch (err) {
            pushCommand(`Failed to read EQ: ${err.message}`);
        }
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="lg:col-span-3 space-y-2">
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider">{t.dacPlaybackEqCurve}</h3>
                    <PEQGraph ref={graphRef} bands={bands} onChange={setBands} minDb={-16} maxDb={6} masterVolume={masterVolume} />
                </div>
                <div className="bg-gray-900 rounded-xl p-6 flex flex-col items-center justify-between shadow-lg border border-gray-700">
                    <h3 className="text-gray-300 font-bold mb-4 text-center text-sm uppercase tracking-wider">{t.dacPlaybackVolume}</h3>
                    <div className="flex-1 flex items-center justify-center w-full py-4">
                         <input 
                            type="range" 
                            min={volumeMin} 
                            max={volumeMax} 
                            step={volumeStep} 
                            value={masterVolume}
                            onChange={(e) => setMasterVolume(parseFloat(e.target.value))}
                            className="w-48 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition-all"
                            style={{ transform: 'rotate(-90deg)' }}
                         />
                    </div>
                    <div className="mt-4 text-center bg-gray-800 rounded-lg px-4 py-2 w-full border border-gray-700">
                        <span className={`text-2xl font-bold ${masterVolume > 0 ? 'text-green-400' : masterVolume < 0 ? 'text-orange-400' : 'text-white'}`}>
                            {masterVolume > 0 ? `+${masterVolume}` : masterVolume}
                        </span>
                        <span className="text-xs text-gray-500 block uppercase font-bold tracking-wider">dB</span>
                    </div>
                </div>
            </div>

            <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                    <Sliders className="w-5 h-5 mr-2 text-indigo-600" /> {t.peqSettings}
                </h2>
                <div className="flex space-x-2">
                    <button onClick={handleReadEQ} disabled={deviceStatus !== 'Connected'} className="flex items-center px-4 py-2 bg-blue-500 text-white font-semibold rounded-full shadow-lg hover:bg-blue-600 transition disabled:bg-gray-400 disabled:cursor-not-allowed">
                        <Zap className="w-4 h-4 mr-2" /> {t.readDevice}
                    </button>
                    <button onClick={pushEQToDevice} disabled={deviceStatus !== 'Connected'} className="flex items-center px-4 py-2 bg-green-500 text-white font-semibold rounded-full shadow-lg hover:bg-green-600 transition disabled:bg-gray-400 disabled:cursor-not-allowed">
                        <Zap className="w-4 h-4 mr-2" /> {t.pushEqToDevice}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 overflow-x-auto">
                {bands.map((band, index) => (
                    <div key={index} className="p-4 bg-gray-50 border border-gray-200 rounded-lg shadow-sm space-y-2">
                        <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-indigo-700">{t.band} {index + 1}</h3>
                            <input type="checkbox" checked={band.enabled} onChange={(e) => handleBandChange(index, 'enabled', e.target.checked)} className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" />
                        </div>
                        
                        <label className="block text-xs font-medium text-gray-700">{t.filterType}</label>
                        <select 
                            value={band.type || 2} 
                            onChange={(e) => handleBandChange(index, 'type', e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded-md text-sm bg-white"
                        >
                            <option value={2}>Peak</option>
                            <option value={1}>Low Shelf</option>
                            <option value={3}>High Shelf</option>
                            <option value={4}>Low Pass</option>
                            <option value={5}>High Pass</option>
                        </select>

                        <label className="block text-xs font-medium text-gray-700">{t.freqHz}</label>
                        <input type="number" value={band.freq} onChange={(e) => handleBandChange(index, 'freq', e.target.value)} className="w-full text-center px-2 py-1 border border-gray-300 rounded-md text-sm" min="20" max="20000" step="1" />
                        <label className="block text-xs font-medium text-gray-700">{t.qValue}</label>
                        <input type="number" value={band.q} onChange={(e) => handleBandChange(index, 'q', e.target.value)} className="w-full text-center px-2 py-1 border border-gray-300 rounded-md text-sm" min="0.1" max="10.0" step="0.05" />
                        <label className="block text-xs font-medium text-gray-700">{t.gainDb}</label>
                        <input type="number" value={band.gain} onChange={(e) => handleBandChange(index, 'gain', e.target.value)} className="w-full text-center px-2 py-1 border border-gray-300 rounded-md text-sm" min={peqMin} max={peqMax} step={0.5} />
                    </div>
                ))}
            </div>

            {/* Cloud EQ Presets Section */}
            <div className="bg-white rounded-xl shadow-lg border border-indigo-200 flex flex-col overflow-hidden">
                {/* Tab Header */}
                <div className="flex border-b bg-gray-50">
                    {[
                        { id: 'PRESETS', label: t.tabPresets, icon: List },
                        { id: 'CUSTOM', label: t.tabCustom, icon: User },
                        { id: 'COMMUNITY', label: t.tabCommunity, icon: Globe },
                        { id: 'SHARED', label: t.tabShared, icon: Share2 }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex-1 py-4 text-sm font-bold flex items-center justify-center transition ${
                                activeTab === tab.id 
                                ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' 
                                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                            }`}
                        >
                            <tab.icon className="w-4 h-4 mr-2" />
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Toolbar (Search / Actions) */}
                <div className="p-4 border-b flex justify-between items-center bg-white">
                    <div className="flex items-center space-x-2 w-full max-w-md">
                        {(activeTab === 'COMMUNITY' || activeTab === 'SHARED') && (
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                                <input 
                                    type="text" 
                                    placeholder={t.searchPresetsPlaceholder}
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && fetchPresets(1, true)}
                                    className="w-full pl-9 pr-4 py-2 border rounded-full text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                />
                            </div>
                        )}
                        {activeTab === 'CUSTOM' && (
                            <button
                                onClick={() => openShareDialog(null)} // Share current
                                className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full text-sm font-semibold hover:bg-indigo-200 transition flex items-center"
                            >
                                <Share2 className="w-4 h-4 mr-2" /> {t.shareCurrent}
                            </button>
                        )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                        {activeTab === 'CUSTOM' && (
                            <button
                                onClick={handleSaveEQ}
                                className="px-4 py-2 bg-indigo-600 text-white rounded-full text-sm font-semibold hover:bg-indigo-700 transition flex items-center"
                            >
                                <Save className="w-4 h-4 mr-2" /> {t.saveCurrent}
                            </button>
                        )}
                        <button 
                            onClick={() => fetchPresets(1, true)}
                            className="p-2 text-gray-500 hover:bg-gray-100 rounded-full"
                            title="Refresh"
                        >
                            <Globe className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {/* Content List */}
                <div className="p-4 bg-gray-50 min-h-[300px] max-h-[500px] overflow-y-auto">
                    {loading && presets.length === 0 ? (
                        <div className="flex justify-center items-center h-40 text-gray-500">{t.loading}</div>
                    ) : presets.length === 0 ? (
                        <div className="flex flex-col justify-center items-center h-40 text-gray-500">
                            <List className="w-10 h-10 mb-2 opacity-20" />
                            <p>{t.noPresetsFound}</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {presets.map(eq => (
                                <div key={eq.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition flex flex-col">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h4 className="font-bold text-gray-800 truncate pr-2" title={eq.name}>{eq.name}</h4>
                                            <p className="text-xs text-gray-500">
                                                {t.byAuthor} {activeTab === 'CUSTOM' ? (auth.user?.nickName || auth.user?.email || eq.author) : eq.author}
                                            </p>
                                        </div>
                                        {(activeTab === 'COMMUNITY' || activeTab === 'SHARED') && (
                                            <div className="flex space-x-3 text-xs text-gray-400">
                                                <button 
                                                    onClick={() => handleLike(eq, eq.isLiked)}
                                                    className={`flex items-center hover:text-indigo-500 ${eq.isLiked ? 'text-indigo-500' : ''}`}
                                                >
                                                    <ThumbsUp className="w-3 h-3 mr-1" /> {eq.likeCount || 0}
                                                </button>
                                                <button 
                                                    onClick={() => handleCollect(eq, eq.isCollected)}
                                                    className={`flex items-center hover:text-indigo-500 ${eq.isCollected ? 'text-indigo-500' : ''}`}
                                                >
                                                    <Heart className="w-3 h-3 mr-1" /> {eq.collectCount || 0}
                                                </button>
                                                <span className="flex items-center"><Download className="w-3 h-3 mr-1" /> {eq.downloadCount || 0}</span>
                                            </div>
                                        )}
                                    </div>

                                    {/* Visualization Placeholder (Optional) */}
                                    <div className="h-16 bg-gray-50 rounded mb-3 flex items-end justify-center pb-1 space-x-1">
                                        {/* Simple bar viz based on gains if available */}
                                        {(eq.gains || []).slice(0, 10).map((g, i) => (
                                            <div key={i} className="w-2 bg-indigo-200 rounded-t" style={{ height: `${Math.max(10, 50 + (g * 3))}%` }}></div>
                                        ))}
                                    </div>

                                    <div className="mt-auto flex justify-between items-center pt-2 border-t border-gray-50">
                                        <div className="flex space-x-1">
                                            {(activeTab === 'CUSTOM' || activeTab === 'SHARED') && (
                                                <button 
                                                    onClick={() => handleDeleteEQ(eq.id)}
                                                    className="p-1.5 text-red-500 hover:bg-red-50 rounded transition"
                                                    title={t.delete}
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            )}
                                            {activeTab === 'CUSTOM' && (
                                                <button 
                                                    onClick={() => openShareDialog(eq)}
                                                    className="p-1.5 text-indigo-500 hover:bg-indigo-50 rounded transition"
                                                    title={t.share}
                                                >
                                                    <Share2 className="w-4 h-4" />
                                                </button>
                                            )}
                                        </div>
                                        <button 
                                            onClick={() => handleApplyEQ(eq)}
                                            className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 transition flex items-center"
                                        >
                                            {t.apply}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    
                    {hasMore && (
                        <div className="text-center mt-4">
                            <button 
                                onClick={() => {
                                    const nextPage = page + 1;
                                    setPage(nextPage);
                                    fetchPresets(nextPage, false);
                                }}
                                disabled={loading}
                                className="px-4 py-2 bg-white border border-gray-300 rounded-full text-sm text-gray-600 hover:bg-gray-50"
                            >
                                {loading ? t.loading : t.loadMore}
                            </button>
                        </div>
                    )}
                </div>
            </div>

            <OnlineEqShareDialog 
                isOpen={showShareDialog} 
                onClose={() => setShowShareDialog(false)} 
                auth={auth}
                eqData={shareData}
                mode={dialogMode}
                onShareSuccess={() => {
                    pushCommand(`[UI Message] EQ ${dialogMode === 'SAVE' ? 'Saved' : 'Shared'} successfully!`);
                    // Add delay to allow DB propagation
                    setTimeout(() => {
                        if (dialogMode === 'SAVE') {
                            setActiveTab('CUSTOM');
                            fetchPresets(1, true);
                        } else if (activeTab === 'SHARED') {
                            fetchPresets(1, true);
                        }
                    }, 1000);
                }}
            />
        </div>
    )
}

export default PEQEditor
