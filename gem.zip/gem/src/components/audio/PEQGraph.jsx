import React, { useRef, useEffect, useState, useCallback, useImperativeHandle, forwardRef } from 'react';

// --- Math Helpers (Ported from Driver Logic) ---

const complex = (real, imag) => ({ real, imag });
const cAdd = (a, b) => complex(a.real + b.real, a.imag + b.imag);
const cMul = (a, b) => complex(a.real * b.real - a.imag * b.imag, a.real * b.imag + a.imag * b.real);
const cDiv = (a, b) => {
    const denom = b.real * b.real + b.imag * b.imag;
    return complex((a.real * b.real + a.imag * b.imag) / denom, (a.imag * b.real - a.real * b.imag) / denom);
};
const cAbs = (a) => Math.sqrt(a.real * a.real + a.imag * a.imag);

// Calculate Biquad Coefficients (b0, b1, b2, a0, a1, a2)
// Type mapping assumption: 1=LS, 2=PK, 3=HS, 4=LP, 5=HP (CB Standard)
// If using KT, we might need to remap, but for visualization we assume standard types.
const calculateCoefficients = (type, freq, q, gain, sampleRate = 48000) => {
    const w0 = 2 * Math.PI * freq / sampleRate;
    const alpha = Math.sin(w0) / (2 * q);
    const A = Math.pow(10, gain / 40);
    const cosW0 = Math.cos(w0);
    const sqrtA = Math.sqrt(A);

    let b0, b1, b2, a0, a1, a2;

    switch (type) {
        case 1: // Low Shelf
            b0 = A * ((A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha);
            b1 = 2 * A * ((A - 1) - (A + 1) * cosW0);
            b2 = A * ((A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha);
            a0 = (A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha;
            a1 = -2 * ((A - 1) + (A + 1) * cosW0);
            a2 = (A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha;
            break;
        case 2: // Peaking
            b0 = 1 + alpha * A;
            b1 = -2 * cosW0;
            b2 = 1 - alpha * A;
            a0 = 1 + alpha / A;
            a1 = -2 * cosW0;
            a2 = 1 - alpha / A;
            break;
        case 3: // High Shelf
            b0 = A * ((A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha);
            b1 = -2 * A * ((A - 1) + (A + 1) * cosW0);
            b2 = A * ((A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha);
            a0 = (A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha;
            a1 = 2 * ((A - 1) - (A + 1) * cosW0);
            a2 = (A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha;
            break;
        case 4: // Low Pass
            b0 = (1 - cosW0) / 2;
            b1 = 1 - cosW0;
            b2 = (1 - cosW0) / 2;
            a0 = 1 + alpha;
            a1 = -2 * cosW0;
            a2 = 1 - alpha;
            break;
        case 5: // High Pass
            b0 = (1 + cosW0) / 2;
            b1 = -(1 + cosW0);
            b2 = (1 + cosW0) / 2;
            a0 = 1 + alpha;
            a1 = -2 * cosW0;
            a2 = 1 - alpha;
            break;
        default: // Default to Peaking
            b0 = 1 + alpha * A;
            b1 = -2 * cosW0;
            b2 = 1 - alpha * A;
            a0 = 1 + alpha / A;
            a1 = -2 * cosW0;
            a2 = 1 - alpha / A;
            break;
    }

    // Normalize by a0
    return {
        b0: b0 / a0,
        b1: b1 / a0,
        b2: b2 / a0,
        a1: a1 / a0,
        a2: a2 / a0
    };
};

// Calculate H(z) for a single biquad at frequency f
const biquadResponse = (coeffs, freq, sampleRate) => {
    const w = 2 * Math.PI * freq / sampleRate;
    const z = complex(Math.cos(w), Math.sin(w)); // z = e^(jw)
    
    // H(z) = (b0 + b1*z^-1 + b2*z^-2) / (1 + a1*z^-1 + a2*z^-2)
    // Using z^-1 = e^(-jw) = cos(w) - j*sin(w)
    const zInv = complex(Math.cos(w), -Math.sin(w));
    const zInv2 = cMul(zInv, zInv);

    const num = cAdd(cAdd(complex(coeffs.b0, 0), cMul(complex(coeffs.b1, 0), zInv)), cMul(complex(coeffs.b2, 0), zInv2));
    const den = cAdd(cAdd(complex(1, 0), cMul(complex(coeffs.a1, 0), zInv)), cMul(complex(coeffs.a2, 0), zInv2));

    return cDiv(num, den);
};

const generateLogFreqs = (min, max, steps) => {
    const freqs = [];
    const logMin = Math.log10(min);
    const logMax = Math.log10(max);
    const step = (logMax - logMin) / (steps - 1);
    for (let i = 0; i < steps; i++) {
        freqs.push(Math.pow(10, logMin + i * step));
    }
    return freqs;
};

const PEQGraph = forwardRef(({ bands, onChange, minDb = -20, maxDb = 20, masterVolume = 0 }, ref) => {
    const canvasRef = useRef(null);
    const containerRef = useRef(null);
    const [width, setWidth] = useState(1100);
    const [draggingBand, setDraggingBand] = useState(null);

    useImperativeHandle(ref, () => ({
        getGraphImage: async () => {
            if (canvasRef.current) {
                return new Promise(resolve => {
                    canvasRef.current.toBlob(blob => {
                        resolve(blob);
                    }, 'image/png');
                });
            }
            return null;
        }
    }));

    const height = 300;
    const padding = { top: 20, bottom: 30, left: 40, right: 20 };
    const minF = 20, maxF = 20000;

    // Coordinate Transforms
    const freqToX = (f) => {
        const logMin = Math.log10(minF);
        const logMax = Math.log10(maxF);
        const logF = Math.log10(Math.max(minF, Math.min(f, maxF)));
        return padding.left + ((logF - logMin) / (logMax - logMin)) * (width - padding.left - padding.right);
    };

    const xToFreq = (x) => {
        const logMin = Math.log10(minF);
        const logMax = Math.log10(maxF);
        // Clamp X to valid area
        const validX = Math.max(padding.left, Math.min(x, width - padding.right));
        const t = (validX - padding.left) / (width - padding.left - padding.right);
        return Math.pow(10, logMin + t * (logMax - logMin));
    };

    const dbToY = (db) => {
        const range = maxDb - minDb;
        const clampedDb = Math.max(minDb, Math.min(db, maxDb));
        return padding.top + ((maxDb - clampedDb) / range) * (height - padding.top - padding.bottom);
    };

    const yToDb = (y) => {
        const range = maxDb - minDb;
        // Clamp Y to valid area
        const validY = Math.max(padding.top, Math.min(y, height - padding.bottom));
        const t = (validY - padding.top) / (height - padding.top - padding.bottom);
        return maxDb - t * range;
    };

    // Interaction Handlers
    const getMousePos = (e) => {
        const rect = canvasRef.current.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    };

    const handleMouseDown = (e) => {
        const { x, y } = getMousePos(e);
        
        // Find clicked band
        let clickedIndex = -1;
        // Check in reverse order so top-most handles (if overlapping) get picked first
        for (let i = bands.length - 1; i >= 0; i--) {
            const b = bands[i];
            if (b.enabled === false) continue;
            
            const bx = freqToX(b.freq);
            const by = dbToY(b.gain + masterVolume);
            
            // Hit detection radius (15px for easier touch)
            if (Math.sqrt(Math.pow(x - bx, 2) + Math.pow(y - by, 2)) < 15) {
                clickedIndex = i;
                break;
            }
        }

        if (clickedIndex !== -1) {
            setDraggingBand(clickedIndex);
            // Prevent text selection while dragging
            e.preventDefault(); 
        }
    };

    const handleMouseMove = (e) => {
        if (draggingBand === null) return;
        
        const { x, y } = getMousePos(e);
        const newFreq = Math.round(xToFreq(x));
        const visualDb = parseFloat(yToDb(y).toFixed(1));
        const newGain = parseFloat((visualDb - masterVolume).toFixed(1));

        const newBands = [...bands];
        newBands[draggingBand] = {
            ...newBands[draggingBand],
            freq: newFreq,
            gain: newGain
        };
        
        onChange(newBands);
    };

    const handleMouseUp = () => {
        setDraggingBand(null);
    };

    // Responsive Width
    useEffect(() => {
        if (!containerRef.current) return;
        const resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                if (entry.contentRect.width > 0) {
                    setWidth(Math.floor(entry.contentRect.width));
                }
            }
        });
        resizeObserver.observe(containerRef.current);
        return () => resizeObserver.disconnect();
    }, []);

    // Draw Function
    const draw = () => {
        const canvas = canvasRef.current;
        if (!canvas || width <= 0) return;
        const ctx = canvas.getContext('2d');
        
        // Clear
        ctx.clearRect(0, 0, width, height);
        
        // Background
        ctx.fillStyle = '#1f2937'; // Gray-800
        ctx.fillRect(0, 0, width, height);

        // Grid
        ctx.lineWidth = 1;
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.setLineDash([3, 3]); // Dashed grid

        // Freq Grid
        const freqs = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000];
        freqs.forEach(f => {
            const x = freqToX(f);
            ctx.strokeStyle = '#374151'; // Gray-700
            ctx.beginPath();
            ctx.moveTo(x, padding.top);
            ctx.lineTo(x, height - padding.bottom);
            ctx.stroke();
            
            ctx.fillStyle = '#9ca3af'; // Gray-400
            ctx.fillText(f >= 1000 ? `${f/1000}k` : f, x, height - padding.bottom + 5);
        });

        // dB Grid
        const dbs = [];
        const range = maxDb - minDb;
        let step = 5;
        if (range <= 12) step = 3;
        if (range <= 6) step = 1;
        
        // Generate standard steps
        if (minDb <= 0 && maxDb >= 0) {
            dbs.push(0);
            for (let db = step; db < maxDb; db += step) dbs.push(db);
            for (let db = -step; db > minDb; db -= step) dbs.push(db);
        } else {
            for (let db = Math.ceil(minDb/step)*step; db < maxDb; db += step) dbs.push(db);
        }
        
        // Always add min and max for clarity
        dbs.push(minDb);
        dbs.push(maxDb);
        
        // Remove duplicates and sort
        let uniqueDbs = [...new Set(dbs)].sort((a, b) => a - b);

        // Filter out labels that are too close to min/max (avoid overlap)
        uniqueDbs = uniqueDbs.filter(db => {
            if (db === minDb || db === maxDb || db === 0) return true;
            if (Math.abs(db - minDb) < step * 0.25) return false;
            if (Math.abs(db - maxDb) < step * 0.25) return false;
            return true;
        });

        uniqueDbs.forEach(db => {
            const y = dbToY(db);
            ctx.strokeStyle = db === 0 ? '#4b5563' : '#374151';
            ctx.beginPath();
            ctx.moveTo(padding.left, y);
            ctx.lineTo(width - padding.right, y);
            ctx.stroke();

            ctx.fillStyle = '#9ca3af';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText(db, padding.left - 5, y);
        });

        // Draw Safe Lines (0dB and +4dB)
        ctx.setLineDash([]); // Reset to solid
        [0, 4].forEach(db => {
            const y = dbToY(db);
            if (y >= padding.top && y <= height - padding.bottom) {
                ctx.strokeStyle = '#ef4444'; // Red-500
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(padding.left, y);
                ctx.lineTo(width - padding.right, y);
                ctx.stroke();
            }
        });

        // Calculate Response Curve
        const plotFreqs = generateLogFreqs(minF, maxF, 300);
        const responsePoints = plotFreqs.map(f => {
            let totalResponse = complex(1, 0);
            
            bands.forEach(b => {
                // Treat undefined enabled as true
                if (b.enabled === false) return;
                const coeffs = calculateCoefficients(b.type || 2, b.freq, b.q, b.gain);
                const resp = biquadResponse(coeffs, f, 48000); // Assuming 48k sample rate
                totalResponse = cMul(totalResponse, resp);
            });
            
            const mag = cAbs(totalResponse);
            const db = 20 * Math.log10(mag) + masterVolume;
            return { x: freqToX(f), y: dbToY(db) };
        });

        // Draw Curve
        ctx.strokeStyle = '#10b981'; // Emerald-500
        ctx.lineWidth = 2;
        ctx.beginPath();
        if (responsePoints.length > 0) {
            ctx.moveTo(responsePoints[0].x, responsePoints[0].y);
            for (let i = 1; i < responsePoints.length; i++) {
                ctx.lineTo(responsePoints[i].x, responsePoints[i].y);
            }
        }
        ctx.stroke();

        // Draw Handles
        bands.forEach((b, i) => {
            const x = freqToX(b.freq);
            const y = dbToY(b.gain + masterVolume);
            
            ctx.beginPath();
            ctx.arc(x, y, 6, 0, 2 * Math.PI);
            // Treat undefined enabled as true
            ctx.fillStyle = (b.enabled !== false) ? '#6366f1' : '#4b5563'; // Indigo-500 or Gray-600
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();
        });
    };

    // Main Draw Effect
    useEffect(() => {
        const renderId = requestAnimationFrame(draw);
        return () => cancelAnimationFrame(renderId);
    }, [bands, width, minDb, maxDb, masterVolume]);

    // Force redraw on mount/resize with delay to catch layout shifts
    useEffect(() => {
        const timer = setTimeout(draw, 100);
        return () => clearTimeout(timer);
    }, [width, minDb, maxDb, masterVolume]);

    return (
        <div ref={containerRef} className="w-full overflow-hidden rounded-lg shadow-lg bg-gray-900 touch-none">
            <canvas
                ref={canvasRef}
                width={width}
                height={height}
                className="w-full h-full cursor-crosshair"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                onTouchStart={handleMouseDown}
                onTouchMove={handleMouseMove}
                onTouchEnd={handleMouseUp}
            />
        </div>
    );
});

export default PEQGraph;
