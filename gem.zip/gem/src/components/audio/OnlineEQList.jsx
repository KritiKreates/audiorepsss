import React, { useState, useEffect, useCallback } from 'react';
import { Search, ThumbsUp, Heart, Download, Flag, Share2, X, Filter } from 'lucide-react';
import ReportEQDialog from './ReportEQDialog';

const OnlineEQList = ({ auth, onClose, onApplyEQ, deviceVid, devicePid }) => {
    const [activeTab, setActiveTab] = useState('latest'); // latest, hottest, my_share, my_collect
    const [eqList, setEqList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const [reportDialog, setReportDialog] = useState({ isOpen: false, eqId: null });
    const [searchQuery, setSearchQuery] = useState('');

    const fetchEQs = useCallback(async (pageNum = 1, reset = false) => {
        if (!auth) return;
        setLoading(true);
        try {
            let res;
            const pageSize = 20;
            
            if (activeTab === 'my_share' || activeTab === 'my_collect') {
                // 1: My Share, 2: My Collect
                const type = activeTab === 'my_share' ? 1 : 2;
                res = await auth.queryUserEQShareInfoList({
                    page: pageNum,
                    limit: pageSize,
                    type: type
                });
            } else {
                // 1: Latest, 2: Hottest
                const sortType = activeTab === 'hottest' ? 2 : 1;
                res = await auth.queryAllEQShareInfoList({
                    page: pageNum,
                    limit: pageSize,
                    sortType: sortType,
                    title: searchQuery,
                    vid: deviceVid, // Optional: filter by current device
                    pid: devicePid
                });
            }

            if (res && res.code === 200) {
                const list = res.data || []; // Adjust based on actual API response structure (might be res.data.list)
                const actualList = Array.isArray(list) ? list : (list.list || []);
                
                if (reset) {
                    setEqList(actualList);
                } else {
                    setEqList(prev => [...prev, ...actualList]);
                }
                setHasMore(actualList.length === pageSize);
            }
        } catch (e) {
            console.error("Failed to fetch EQs", e);
        } finally {
            setLoading(false);
        }
    }, [auth, activeTab, searchQuery, deviceVid, devicePid]);

    useEffect(() => {
        setPage(1);
        fetchEQs(1, true);
    }, [activeTab, fetchEQs]);

    const handleLoadMore = () => {
        if (!loading && hasMore) {
            const nextPage = page + 1;
            setPage(nextPage);
            fetchEQs(nextPage, false);
        }
    };

    const handleLike = async (eq) => {
        if (eq.isLike) {
            await auth.cancelLikeEQ({ id: eq.id });
        } else {
            await auth.likeEQ({ id: eq.id });
        }
        // Refresh list or update local state optimistically
        setEqList(prev => prev.map(item => 
            item.id === eq.id ? { ...item, isLike: !item.isLike, likeCount: item.isLike ? item.likeCount - 1 : item.likeCount + 1 } : item
        ));
    };

    const handleCollect = async (eq) => {
        if (eq.isCollect) {
            await auth.cancelCollectEQ({ id: eq.id });
        } else {
            await auth.collectEQ({ id: eq.id });
        }
        setEqList(prev => prev.map(item => 
            item.id === eq.id ? { ...item, isCollect: !item.isCollect, collectCount: item.isCollect ? item.collectCount - 1 : item.collectCount + 1 } : item
        ));
    };

    const handleReport = (eq) => {
        setReportDialog({ isOpen: true, eqId: eq.id });
    };

    const handleApply = (eq) => {
        if (onApplyEQ) {
            // Transform API EQ data to app format if necessary
            // Assuming eq.bands or eq.frequencies/gains exists
            onApplyEQ(eq);
        }
    };

    return (
        <div className="fixed inset-0 bg-gray-100 z-40 flex flex-col">
            {/* Header */}
            <div className="bg-white shadow-sm p-4 flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                    <Share2 className="w-6 h-6 mr-2 text-indigo-600" /> Online EQ Community
                </h2>
                <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
                    <X className="w-6 h-6 text-gray-600" />
                </button>
            </div>

            {/* Tabs & Search */}
            <div className="bg-white border-b px-4 py-2 flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="flex space-x-4 overflow-x-auto w-full md:w-auto">
                    {[
                        { id: 'latest', label: 'Latest' },
                        { id: 'hottest', label: 'Hottest' },
                        { id: 'my_share', label: 'My Shares' },
                        { id: 'my_collect', label: 'My Collection' }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition ${
                                activeTab === tab.id 
                                ? 'bg-indigo-600 text-white' 
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>
                <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <input 
                        type="text" 
                        placeholder="Search EQs..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && fetchEQs(1, true)}
                        className="w-full pl-9 pr-4 py-2 border rounded-full text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-7xl mx-auto">
                    {eqList.map(eq => (
                        <div key={eq.id} className="bg-white rounded-xl shadow hover:shadow-md transition p-4 flex flex-col">
                            <div className="flex gap-4 mb-3">
                                <div className="w-20 h-20 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                                    {eq.eqImg ? (
                                        <img src={eq.eqImg} alt={eq.title} className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-gray-300">
                                            <Share2 className="w-8 h-8" />
                                        </div>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h3 className="font-semibold text-gray-900 truncate">{eq.title}</h3>
                                    <p className="text-xs text-gray-500 mb-1">by {eq.username || 'Unknown'}</p>
                                    <p className="text-sm text-gray-600 line-clamp-2">{eq.content || 'No description'}</p>
                                </div>
                            </div>
                            
                            <div className="mt-auto pt-3 border-t flex items-center justify-between text-sm text-gray-500">
                                <div className="flex gap-3">
                                    <button 
                                        onClick={() => handleLike(eq)}
                                        className={`flex items-center gap-1 hover:text-indigo-600 ${eq.isLike ? 'text-indigo-600' : ''}`}
                                    >
                                        <ThumbsUp className={`w-4 h-4 ${eq.isLike ? 'fill-current' : ''}`} /> {eq.likeCount || 0}
                                    </button>
                                    <button 
                                        onClick={() => handleCollect(eq)}
                                        className={`flex items-center gap-1 hover:text-red-600 ${eq.isCollect ? 'text-red-600' : ''}`}
                                    >
                                        <Heart className={`w-4 h-4 ${eq.isCollect ? 'fill-current' : ''}`} /> {eq.collectCount || 0}
                                    </button>
                                </div>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={() => handleReport(eq)}
                                        className="p-1.5 hover:bg-red-50 text-gray-400 hover:text-red-600 rounded transition"
                                        title="Report"
                                    >
                                        <Flag className="w-4 h-4" />
                                    </button>
                                    <button 
                                        onClick={() => handleApply(eq)}
                                        className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition flex items-center gap-1 text-xs font-medium"
                                    >
                                        <Download className="w-3 h-3" /> Apply
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                
                {eqList.length === 0 && !loading && (
                    <div className="text-center py-12 text-gray-500">
                        <Share2 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p>No EQs found. Be the first to share!</p>
                    </div>
                )}

                {hasMore && (
                    <div className="text-center py-6">
                        <button 
                            onClick={handleLoadMore}
                            disabled={loading}
                            className="px-6 py-2 bg-white border border-gray-300 rounded-full text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                        >
                            {loading ? 'Loading...' : 'Load More'}
                        </button>
                    </div>
                )}
            </div>

            <ReportEQDialog 
                isOpen={reportDialog.isOpen} 
                onClose={() => setReportDialog({ isOpen: false, eqId: null })}
                auth={auth}
                eqId={reportDialog.eqId}
                onReportSuccess={() => {
                    // Maybe show a toast
                    alert('Report submitted successfully');
                }}
            />
        </div>
    );
};

export default OnlineEQList;
