import React, { useState, useEffect, useRef } from 'react';
import { User, Upload, Mail, Phone, LogOut, Save, Edit2, X, Check, ChevronRight, ChevronLeft, Share2, ThumbsUp, Star, Settings, MessageSquare, FileText, Shield, Lock, Globe } from 'lucide-react';
import { TRANSLATIONS } from '../../constants/translations';

const UserInfoPanel = ({ auth, language = 'en', setLanguage }) => {
    const [profile, setProfile] = useState(null);
    const [nickname, setNickname] = useState('');
    const [loading, setLoading] = useState(false);
    const fileInputRef = useRef(null);

    const t = TRANSLATIONS[language] || TRANSLATIONS.en;

    // Bind States
    const [emailBind, setEmailBind] = useState({ email: '', vcode: '', count: 0, timer: null });
    
    const [gender, setGender] = useState('0'); // 0: Secrecy, 1: Male, 2: Female
    const [birthday, setBirthday] = useState('');

    useEffect(() => {
        loadProfile();
        return () => {
            if (emailBind.timer) clearInterval(emailBind.timer);
        };
    }, []);

    const loadProfile = async () => {
        const data = await auth.getUserDetail();
        if (data) {
            setProfile(data);
            setNickname(data.nickName || data.nickname || '');
            
            // Handle Sex mapping (API might return "男"/"Male" or "1")
            let sexVal = '0';
            if (data.sex) {
                const s = String(data.sex).toLowerCase();
                if (s === '1' || s === 'male' || s === '男') sexVal = '1';
                else if (s === '2' || s === 'female' || s === '女') sexVal = '2';
                else sexVal = s; // Fallback or '0'
            }
            setGender(sexVal);
            
            setBirthday(data.birthday || '');
        }
    };

    const handleAvatarClick = () => {
        fileInputRef.current.click();
    };

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (file) {
            setLoading(true);
            await auth.uploadAvatar(file);
            await loadProfile();
            setLoading(false);
        }
    };

    const handleSaveProfile = async (updates) => {
        setLoading(true);
        const payload = {
            nickName: nickname,
            sex: gender,
            birthday: birthday,
            ...updates
        };
        await auth.saveUserDetail(payload);
        await loadProfile();
        setLoading(false);
    };

    const handleSaveNickname = () => handleSaveProfile({ nickName: nickname });
    const handleSaveGender = (val) => {
        setGender(val);
        handleSaveProfile({ sex: val });
    };
    const handleSaveBirthday = (val) => {
        setBirthday(val);
        handleSaveProfile({ birthday: val });
    };

    // --- Email Binding Logic ---
    const startEmailTimer = () => {
        if (emailBind.timer) return;
        setEmailBind(prev => ({ ...prev, count: 60 }));
        const timer = setInterval(() => {
            setEmailBind(prev => {
                if (prev.count <= 1) {
                    clearInterval(timer);
                    return { ...prev, count: 0, timer: null };
                }
                return { ...prev, count: prev.count - 1 };
            });
        }, 1000);
        setEmailBind(prev => ({ ...prev, timer }));
    };

    const sendEmailCode = async () => {
        if (!emailBind.email) {
            alert('Please enter email');
            return;
        }
        if (!/^\S+@\S+\.\S+$/.test(emailBind.email)) {
            alert('Invalid email format');
            return;
        }
        
        const success = await auth.sendCode(emailBind.email, 'bind');
        if (success) startEmailTimer();
    };

    const submitBindEmail = async () => {
        if (!emailBind.email || !emailBind.vcode) return;
        
        const res = await auth.changeEmail({
            lang: 'en',
            userName: emailBind.email,
            vcode: emailBind.vcode
        });

        if (res && (res.code === 0 || res.code === 200)) {
            alert('Email bound successfully');
            setEmailBind({ email: '', vcode: '', count: 0, timer: null });
            loadProfile();
        } else {
            alert(res?.msg || 'Failed to bind email');
        }
    };

    if (!profile) return <div className="p-8 text-center text-gray-500">Loading profile...</div>;

    return (
        <div className="p-6 space-y-6 bg-gray-50 min-h-full">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">{t.profileTitle}</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column: Profile Card */}
                <div className="bg-white rounded-xl shadow-sm p-6 flex flex-col items-center">
                    <div className="relative group cursor-pointer mb-4" onClick={handleAvatarClick}>
                        <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-gray-100 shadow-inner">
                            {profile.avatar ? (
                                <img src={profile.avatar} alt="Avatar" className="w-full h-full object-cover" />
                            ) : (
                                <User className="w-full h-full p-6 text-gray-300" />
                            )}
                        </div>
                        <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                            <Upload className="w-8 h-8 text-white" />
                        </div>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                    </div>
                    
                    <div className="flex items-center gap-2 mb-1">
                        <input 
                            type="text" 
                            value={nickname} 
                            onChange={(e) => setNickname(e.target.value)}
                            onBlur={handleSaveNickname}
                            className="text-xl font-bold text-center text-gray-800 border-b border-transparent hover:border-gray-300 focus:border-indigo-500 focus:outline-none bg-transparent"
                        />
                        <Edit2 className="w-4 h-4 text-gray-400" />
                    </div>
                    <div className="text-sm text-gray-500 mb-6">ID: {profile.userId || profile.id || 'N/A'}</div>

                    <div className="grid grid-cols-3 gap-4 w-full border-t border-gray-100 pt-6">
                        <div className="text-center">
                            <div className="font-bold text-gray-800">0</div>
                            <div className="text-xs text-gray-500">{t.shared}</div>
                        </div>
                        <div className="text-center border-l border-r border-gray-100">
                            <div className="font-bold text-gray-800">0</div>
                            <div className="text-xs text-gray-500">{t.liked}</div>
                        </div>
                        <div className="text-center">
                            <div className="font-bold text-gray-800">0</div>
                            <div className="text-xs text-gray-500">{t.collection}</div>
                        </div>
                    </div>
                </div>

                {/* Right Column: Personal Info & Settings */}
                <div className="space-y-6">
                    {/* Personal Info Card */}
                    <div className="bg-white rounded-xl shadow-sm p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                            <User className="w-5 h-5 mr-2 text-indigo-600" />
                            {t.personalInfoTitle}
                        </h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center py-2 border-b border-gray-50">
                                <span className="text-gray-500">{t.account}</span>
                                <span className="font-medium text-gray-800">{profile.email || profile.phoneNo || t.notBound}</span>
                            </div>
                            <div className="flex justify-between items-center py-2 border-b border-gray-50">
                                <span className="text-gray-500">{t.gender}</span>
                                <select 
                                    value={gender} 
                                    onChange={(e) => handleSaveGender(e.target.value)}
                                    className="font-medium text-gray-800 bg-transparent border-none focus:ring-0 text-right cursor-pointer outline-none"
                                >
                                    <option value="0">{t.preferNotToSay}</option>
                                    <option value="1">{t.male}</option>
                                    <option value="2">{t.female}</option>
                                </select>
                            </div>
                            <div className="flex justify-between items-center py-2 border-b border-gray-50">
                                <span className="text-gray-500">{t.birthday}</span>
                                <input 
                                    type="date" 
                                    value={birthday} 
                                    onChange={(e) => handleSaveBirthday(e.target.value)}
                                    className="font-medium text-gray-800 bg-transparent border-none focus:ring-0 text-right outline-none"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Settings Card */}
                    <div className="bg-white rounded-xl shadow-sm p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                            <Settings className="w-5 h-5 mr-2 text-indigo-600" />
                            {t.settings}
                        </h3>
                        
                        <div className="space-y-6">
                            {/* Language Selector */}
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">{t.languageSettings}</label>
                                <div className="flex flex-wrap gap-2">
                                    {['en', 'hi', 'ta', 'te'].map((langCode) => (
                                        <button
                                            key={langCode}
                                            onClick={() => setLanguage(langCode)}
                                            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                                                language === langCode 
                                                ? 'bg-indigo-100 text-indigo-700 border border-indigo-200' 
                                                : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border border-transparent'
                                            }`}
                                        >
                                            {t[langCode === 'en' ? 'english' : langCode === 'hi' ? 'hindi' : langCode === 'ta' ? 'tamil' : 'telugu']}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Email Binding Section */}
                            <div className="pt-4 border-t border-gray-100">
                                <label className="block text-sm font-medium text-gray-700 mb-2">{t.emailSettings}</label>
                                <div className="flex gap-2 mb-2">
                                    <input 
                                        type="email" 
                                        value={emailBind.email}
                                        onChange={(e) => setEmailBind({ ...emailBind, email: e.target.value })}
                                        placeholder={t.emailPlaceholder}
                                        className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-indigo-500"
                                    />
                                    <button 
                                        onClick={sendEmailCode}
                                        disabled={emailBind.count > 0}
                                        className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-lg text-sm font-medium hover:bg-indigo-100 disabled:opacity-50 whitespace-nowrap"
                                    >
                                        {emailBind.count > 0 ? `${emailBind.count}s` : t.getCode}
                                    </button>
                                </div>
                                <div className="flex gap-2">
                                    <input 
                                        type="text" 
                                        value={emailBind.vcode}
                                        onChange={(e) => setEmailBind({ ...emailBind, vcode: e.target.value })}
                                        placeholder={t.codePlaceholder}
                                        className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-indigo-500"
                                    />
                                    <button 
                                        onClick={submitBindEmail}
                                        className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm"
                                    >
                                        {t.confirmChange}
                                    </button>
                                </div>
                            </div>

                            {/* Password Note */}
                            <div className="pt-4 border-t border-gray-100">
                                <label className="block text-sm font-medium text-gray-700 mb-1">{t.passwordSettings}</label>
                                <p className="text-xs text-gray-500">{t.passwordMgmtNote}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer Actions */}
            <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
                <button 
                    onClick={auth.deleteAccount}
                    className="px-6 py-2 text-red-500 hover:text-red-700 font-medium transition"
                >
                    {t.deactivate}
                </button>
                <button 
                    onClick={auth.logout}
                    className="px-6 py-2 bg-gray-800 text-white rounded-lg font-medium hover:bg-gray-900 shadow-lg transition flex items-center"
                >
                    <LogOut className="w-4 h-4 mr-2" />
                    {t.logout}
                </button>
            </div>
        </div>
    );
};

export default UserInfoPanel;
