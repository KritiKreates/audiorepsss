import React, { useState, useEffect } from 'react'
import { LogIn, UserPlus, KeyRound, Mail, User, Upload, Save, Trash2, ChevronLeft } from 'lucide-react'
import UserInfoPanel from './UserInfoPanel'
import { TRANSLATIONS } from '../../constants/translations'

const AuthPanel = ({ auth, language = 'en', setLanguage, notify }) => {
    const [mode, setMode] = useState('login') // 'login', 'login_code', 'register', 'reset'
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [verificationCode, setVerificationCode] = useState('')
    const [loading, setLoading] = useState(false)
    const [count, setCount] = useState(0)

    const t = TRANSLATIONS[language] || TRANSLATIONS.en;

    useEffect(() => {
        let timer;
        if (count > 0) {
            timer = setInterval(() => setCount(c => c - 1), 1000);
        }
        return () => clearInterval(timer);
    }, [count]);

    const handleLogin = async (e) => { 
        e.preventDefault(); 
        setLoading(true);
        await auth.login(username.trim(), password);
        setLoading(false);
    }

    const handleLoginWithCode = async (e) => {
        e.preventDefault();
        setLoading(true);
        await auth.loginWithCode(username.trim(), verificationCode.trim());
        setLoading(false);
    }

    const handleRegister = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            if (notify) notify("Passwords do not match", 'error');
            else alert("Passwords do not match");
            return;
        }
        setLoading(true);
        const success = await auth.register(username.trim(), password, verificationCode.trim());
        if (success) setMode('login');
        setLoading(false);
    }

    const handleReset = async (e) => {
        e.preventDefault();
        setLoading(true);
        const success = await auth.resetPassword(username, password, verificationCode);
        if (success) setMode('login');
        setLoading(false);
    }

    const handleSendCode = async () => {
        if (!username) {
            if (notify) notify('Please enter an email address first.', 'warning');
            else alert('Please enter an email address first.');
            return;
        }
        setLoading(true);
        // Type 3 is for Login with Code (inferred from snippet), 'register' is 1, 'reset' is 2
        let type = 'register';
        if (mode === 'reset') type = 'reset';
        if (mode === 'login_code') type = 'login'; 
        
        const success = await auth.sendCode(username, type);
        if (success) setCount(60);
        setLoading(false);
    }

    // If logged in, show the Profile UI (UserInfoPanel) without extra padding/borders
    if (auth.token) {
        return (
            <div className="h-full bg-gray-100 overflow-hidden rounded-xl shadow-lg border border-gray-200">
                <UserInfoPanel auth={auth} language={language} setLanguage={setLanguage} />
            </div>
        );
    }

    // Login/Register UI matching "My Audiocular" style
    return (
        <div className="h-full bg-white rounded-xl shadow-lg overflow-hidden text-gray-800 flex flex-col">
            {/* Header */}
            <div className="p-6 flex items-center border-b border-gray-100">
                {mode !== 'login' && (
                    <button onClick={() => setMode('login')} className="mr-4 text-gray-600 hover:text-indigo-600 transition">
                        <ChevronLeft className="w-6 h-6" />
                    </button>
                )}
                <h2 className="text-xl font-bold flex-1 text-center mr-10 text-gray-800">
                    {mode === 'login' ? t.loginTitle : mode === 'register' ? t.registerTitle : t.resetTitle}
                </h2>
            </div>

            <div className="flex-1 p-8 flex flex-col justify-center max-w-md mx-auto w-full">
                {mode === 'login' && (
                    <div className="space-y-6">
                        <div className="space-y-4">
                            <input 
                                type="text" 
                                value={username} 
                                onChange={(e) => setUsername(e.target.value)} 
                                placeholder={t.emailPlaceholder} 
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                            />
                            <input 
                                type="password" 
                                value={password} 
                                onChange={(e) => setPassword(e.target.value)} 
                                placeholder={t.passwordPlaceholder} 
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                            />
                        </div>

                        <button 
                            onClick={handleLogin} 
                            disabled={loading} 
                            className="w-full py-3 bg-indigo-600 text-white font-bold rounded-full shadow-lg hover:bg-indigo-700 transition disabled:opacity-50 mt-8"
                        >
                            {loading ? t.loggingIn : t.loginButton}
                        </button>

                        <div className="flex justify-between text-sm text-gray-500 pt-4">
                            <button onClick={() => setMode('register')} className="hover:text-indigo-600 transition">{t.registerLink}</button>
                            <button onClick={() => setMode('reset')} className="hover:text-indigo-600 transition">{t.forgotPasswordLink}</button>
                        </div>
                        <div className="text-center pt-2">
                             <button onClick={() => setMode('login_code')} className="text-sm text-gray-500 hover:text-indigo-600 transition">{t.loginCodeLink}</button>
                        </div>
                    </div>
                )}

                {(mode === 'register' || mode === 'reset' || mode === 'login_code') && (
                    <div className="space-y-6">
                        <div className="space-y-4">
                            <input 
                                type="text" 
                                value={username} 
                                onChange={(e) => setUsername(e.target.value)} 
                                placeholder={t.emailPlaceholder} 
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                            />
                            
                            <div className="flex items-center gap-4">
                                <input 
                                    type="text" 
                                    value={verificationCode} 
                                    onChange={(e) => setVerificationCode(e.target.value)} 
                                    placeholder={t.codePlaceholder} 
                                    className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                                />
                                <button 
                                    onClick={handleSendCode} 
                                    disabled={count > 0 || loading}
                                    className="px-4 py-3 rounded-lg border border-indigo-200 text-indigo-600 text-sm font-medium hover:bg-indigo-50 disabled:opacity-50 whitespace-nowrap transition"
                                >
                                    {count > 0 ? `${count}s` : t.getCode}
                                </button>
                            </div>

                            {mode !== 'login_code' && (
                                <>
                                    <input 
                                        type="password" 
                                        value={password} 
                                        onChange={(e) => setPassword(e.target.value)} 
                                        placeholder={t.newPasswordPlaceholder} 
                                        className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                                    />
                                    {mode === 'register' && (
                                        <input 
                                            type="password" 
                                            value={confirmPassword} 
                                            onChange={(e) => setConfirmPassword(e.target.value)} 
                                            placeholder={t.confirmPasswordPlaceholder} 
                                            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-gray-800 placeholder-gray-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition" 
                                        />
                                    )}
                                </>
                            )}
                        </div>

                        <button 
                            onClick={mode === 'register' ? handleRegister : mode === 'reset' ? handleReset : handleLoginWithCode} 
                            disabled={loading} 
                            className="w-full py-3 bg-indigo-600 text-white font-bold rounded-full shadow-lg hover:bg-indigo-700 transition disabled:opacity-50 mt-8"
                        >
                            {loading ? t.processing : t.saveButton}
                        </button>
                    </div>
                )}
            </div>
        </div>
    )
}

export default AuthPanel
