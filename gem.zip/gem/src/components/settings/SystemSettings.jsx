import React, { useState, useEffect, useRef } from 'react'
import { Settings, RefreshCw, Zap } from 'lucide-react'
import { DAC_FILTER_OPTIONS, DAC_GAIN_LEVELS } from '../../constants/ui'
import { createHIDPacket, createVolumeOffsetPacket, floatToFixed8_8 } from '../../utils/hidUtils'
import { CMD, REQUEST_TYPE_READ } from '../../constants/hid'
import { TRANSLATIONS } from '../../constants/translations';

const SystemSettings = ({ deviceStatus, pushCommand, engine, deviceSettings, language = 'en' }) => {
    const t = TRANSLATIONS[language] || TRANSLATIONS.en;
    // Advanced Settings State (Ported from MyDevicePanel)
    const [micVolume, setMicVolume] = useState(0);
    const [encEnabled, setEncEnabled] = useState(false);
    const [dacBalanceL, setDacBalanceL] = useState(0);
    const [dacBalanceR, setDacBalanceR] = useState(0); // Not used in UI but kept for logic
    const [dacWorkMode, setDacWorkMode] = useState("1");
    const [dacGainMode, setDacGainMode] = useState(1);
    const [filterType, setFilterType] = useState("FAST-LL");
    
    // Mic Visualizer State
    const [isMicMonitoring, setIsMicMonitoring] = useState(false);
    const [isMicLoading, setIsMicLoading] = useState(false);
    const leftBarRef = useRef(null);
    const rightBarRef = useRef(null);
    const audioContextRef = useRef(null);
    const animationFrameRef = useRef(null);
    const streamRef = useRef(null);

    // Sync state with device reports
    useEffect(() => {
        if (!deviceSettings) return;
        if (deviceSettings.filterIndex !== undefined) setFilterType(DAC_FILTER_OPTIONS[deviceSettings.filterIndex]?.value || "FAST-LL");
        if (deviceSettings.dacWorkMode !== undefined) setDacWorkMode(String(deviceSettings.dacWorkMode));
        if (deviceSettings.outputGainMode !== undefined) setDacGainMode(deviceSettings.outputGainMode);
        if (deviceSettings.micOffset !== undefined) setMicVolume(deviceSettings.micOffset);
        if (deviceSettings.encSwitch !== undefined) setEncEnabled(deviceSettings.encSwitch);
    }, [deviceSettings]);

    const handleCommand = async (cmd, payload = [], logMsg, requestType) => {
        const packet = createHIDPacket(cmd, payload, requestType)
        pushCommand(`${logMsg} -> ${packet.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}`)
        
        if (engine && deviceStatus === 'Connected') {
            try {
                await engine.sendReport(packet)
            } catch (e) {
                console.error("Command failed:", e)
                pushCommand(`Command failed: ${e.message}`)
            }
        }
    }



    const handleFullFactoryReset = async () => {
        await handleCommand(CMD.FACTORY_RESET, [0x00], 'Full Factory Reset (0x17)');
        if (engine) {
            pushCommand('[System] Overwriting EQ with Flat Defaults...');
            try {
                // Wait a bit longer for full reset before writing EQ
                await new Promise(r => setTimeout(r, 1000));
                await engine.resetEQ();
                pushCommand('[System] Full Reset & EQ Reset Complete.');
            } catch (e) {
                pushCommand(`EQ Reset failed: ${e.message}`);
            }
        }
    }

    // --- Handlers from MyDevicePanel ---
    const handleMicVolume = async (e) => {
        const val = parseInt(e.target.value, 10);
        setMicVolume(val);
        // Debounce or just send directly? 
        // Since we disabled flash write, direct send is safer, but debounce is still good practice.
        // For now, let's just send it. If it causes issues, we can add debounce.
        if(engine) await engine.setMicVolume(val);
    };
    const handleEncSwitch = async (e) => {
        const val = e.target.checked;
        setEncEnabled(val);
        if(engine) await engine.setDenoise(val);
    };
    const handleDacBalanceL = async (e) => {
        const val = parseInt(e.target.value, 10);
        setDacBalanceL(val);
        // Logic: if val < 0 (Left), attenuate Right? No, usually balance is L/R attenuation
        // MyDevicePanel logic: 
        // const l = val <= 0 ? Math.abs(val) : 0;
        // const r = val > 0 ? val : 0;
        // engine.setDacBalance(l, r);
        const l = val <= 0 ? Math.abs(val) : 0;
        const r = val > 0 ? val : 0;
        if(engine) await engine.setDacBalance(l, r);
    };
    const handleFilterType = async (e) => {
        const val = e.target.value;
        setFilterType(val);
        if(engine) await engine.setFilter(val);
    };
    const handleDacWorkMode = async (e) => {
        const val = e.target.value;
        setDacWorkMode(val);
        if(engine) await engine.setDacWorkMode(val);
    };
    const handleDacGainMode = async (e) => {
        const val = parseInt(e.target.value, 10);
        setDacGainMode(val);
        if(engine) await engine.setDacOutputGain(val);
    };

    // --- Mic Visualizer Logic ---
    const toggleMicMonitoring = async () => {
        if (isMicLoading) return;
        if (isMicMonitoring) {
            await stopMicMonitoring();
        } else {
            await startMicMonitoring();
        }
    };

    const startMicMonitoring = async () => {
        try {
            setIsMicLoading(true);
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            audioContextRef.current = audioCtx;
            
            const source = audioCtx.createMediaStreamSource(stream);
            const splitter = audioCtx.createChannelSplitter(2);
            const analyserL = audioCtx.createAnalyser();
            const analyserR = audioCtx.createAnalyser();
            
            analyserL.fftSize = 256;
            analyserR.fftSize = 256;
            
            source.connect(splitter);
            splitter.connect(analyserL, 0);
            splitter.connect(analyserR, 1);
            
            const dataL = new Uint8Array(analyserL.frequencyBinCount);
            const dataR = new Uint8Array(analyserR.frequencyBinCount);
            
            const draw = () => {
                analyserL.getByteFrequencyData(dataL);
                analyserR.getByteFrequencyData(dataR);
                
                const avgL = dataL.reduce((a, b) => a + b, 0) / dataL.length;
                const avgR = dataR.reduce((a, b) => a + b, 0) / dataR.length;
                
                const pctL = (avgL / 255) * 100;
                const pctR = (avgR / 255) * 100;

                if (leftBarRef.current) {
                    leftBarRef.current.style.height = `${pctL}%`;
                    leftBarRef.current.style.backgroundColor = `hsl(${120 + pctL}, 100%, 50%)`;
                }
                if (rightBarRef.current) {
                    rightBarRef.current.style.height = `${pctR}%`;
                    rightBarRef.current.style.backgroundColor = `hsl(${120 + pctR}, 100%, 50%)`;
                }

                animationFrameRef.current = requestAnimationFrame(draw);
            };
            draw();
            setIsMicMonitoring(true);
        } catch (err) {
            console.error("Error accessing microphone", err);
            alert("Could not access microphone: " + err.message);
        } finally {
            setIsMicLoading(false);
        }
    };

    const stopMicMonitoring = async () => {
        setIsMicLoading(true);
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        
        if (streamRef.current) {
            try {
                streamRef.current.getTracks().forEach(track => track.stop());
            } catch (e) { console.error(e); }
        }
        
        if (audioContextRef.current) {
            try {
                await audioContextRef.current.close();
            } catch (e) { console.error(e); }
        }
        
        setIsMicMonitoring(false);
        if (leftBarRef.current) leftBarRef.current.style.height = '0%';
        if (rightBarRef.current) rightBarRef.current.style.height = '0%';
        setIsMicLoading(false);
    };

    useEffect(() => {
        return () => stopMicMonitoring();
    }, []);

    const isKTDevice = engine && engine.isKT && engine.isKT();

    return (
        <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-800 flex items-center border-b pb-2">
                <Settings className="w-5 h-5 mr-2 text-indigo-600" /> {t.deviceUtilityControls}
            </h2>

            {/* Advanced Settings Section (Ported) */}
            <div className="grid md:grid-cols-2 gap-8">
                {/* DAC Settings (Moved to Left) */}
                <div className="space-y-6 p-8 bg-white rounded-xl shadow-lg border">
                    <h4 className="text-lg font-bold text-gray-800">{t.dacConfiguration}</h4>
                    
                    {isKTDevice ? (
                        <div className="text-gray-500 italic p-4 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                            Advanced DAC configuration (Filter, Amp Mode) is not supported by this device model.
                        </div>
                    ) : (
                        <>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">{t.filterType}</label>
                                <select value={filterType} onChange={handleFilterType} className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="FAST-LL">FAST-LL (Low Latency)</option>
                                    <option value="FAST-PC">FAST-PC (Phase Comp)</option>
                                    <option value="SLOW-LL">SLOW-LL (Low Latency)</option>
                                    <option value="SLOW-PC">SLOW-PC (Phase Comp)</option>
                                    <option value="NON-OS">NON-OS (Non-Oversampling)</option>
                                </select>
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-3">{t.ampMode}</label>
                                    <div className="flex bg-gray-100 rounded-lg p-1.5 border border-gray-200">
                                        <button 
                                            onClick={() => handleDacWorkMode({ target: { value: "0" } })}
                                            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${dacWorkMode === "0" ? 'bg-white shadow-sm text-indigo-600 ring-1 ring-black/5' : 'text-gray-500 hover:text-gray-700'}`}
                                        >
                                            {t.classH}
                                        </button>
                                        <button 
                                            onClick={() => handleDacWorkMode({ target: { value: "1" } })}
                                            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${dacWorkMode === "1" ? 'bg-white shadow-sm text-indigo-600 ring-1 ring-black/5' : 'text-gray-500 hover:text-gray-700'}`}
                                        >
                                            {t.classAB}
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-3">{t.outputGain}</label>
                                    <div className="flex bg-gray-100 rounded-lg p-1.5 border border-gray-200">
                                        <button 
                                            onClick={() => handleDacGainMode({ target: { value: "1" } })}
                                            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${dacGainMode === 1 ? 'bg-white shadow-sm text-indigo-600 ring-1 ring-black/5' : 'text-gray-500 hover:text-gray-700'}`}
                                        >
                                            {t.low}
                                        </button>
                                        <button 
                                            onClick={() => handleDacGainMode({ target: { value: "2" } })}
                                            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${dacGainMode === 2 ? 'bg-white shadow-sm text-indigo-600 ring-1 ring-black/5' : 'text-gray-500 hover:text-gray-700'}`}
                                        >
                                            {t.high}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="pt-4">
                                <label className="block text-sm font-medium text-gray-700 mb-2">{t.channelBalance}</label>
                                <input 
                                    type="range" 
                                    min="-15" 
                                    max="15" 
                                    step="1"
                                    value={dacBalanceL} 
                                    onChange={handleDacBalanceL} 
                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" 
                                />
                                <div className="flex justify-between text-xs text-gray-500 mt-2">
                                    <span>{t.left} (-15)</span>
                                    <span className="font-medium text-gray-700">{dacBalanceL}</span>
                                    <span>{t.right} (+15)</span>
                                </div>
                            </div>
                        </>
                    )}
                </div>

                {/* Microphone Settings (Moved to Right) */}
                <div className="space-y-6 p-8 bg-white rounded-xl shadow-lg border flex flex-col">
                    <div className="flex justify-between items-center">
                        <h4 className="text-lg font-bold text-gray-800">{t.microphoneControl}</h4>
                        <button 
                            onClick={toggleMicMonitoring}
                            disabled={isMicLoading}
                            className={`px-4 py-1.5 text-sm rounded-full font-medium transition shadow-sm ${isMicMonitoring ? 'bg-green-500 text-white hover:bg-green-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'} ${isMicLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                            {isMicLoading ? t.pleaseWait : (isMicMonitoring ? t.monitoringOn : t.monitorMic)}
                        </button>
                    </div>

                    <div className="flex gap-6 flex-1 min-h-[250px]">
                        {/* Visualizer */}
                        <div className="flex-1 bg-gray-900 rounded-xl p-6 flex items-end justify-center gap-8 shadow-inner">
                            <div className="flex flex-col items-center gap-2 h-full w-12">
                                <div className="w-6 bg-gray-800 rounded-full flex-1 relative overflow-hidden border border-gray-700">
                                    <div ref={leftBarRef} className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-green-500 to-green-400 transition-all duration-75" style={{height: '0%'}}></div>
                                </div>
                                <span className="text-xs font-bold text-gray-500">L</span>
                            </div>
                            <div className="flex flex-col items-center gap-2 h-full w-12">
                                <div className="w-6 bg-gray-800 rounded-full flex-1 relative overflow-hidden border border-gray-700">
                                    <div ref={rightBarRef} className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-green-500 to-green-400 transition-all duration-75" style={{height: '0%'}}></div>
                                </div>
                                <span className="text-xs font-bold text-gray-500">R</span>
                            </div>
                        </div>

                        {/* Vertical Mic Gain Slider */}
                        <div className="flex flex-col items-center justify-between bg-gray-50 rounded-xl p-4 border border-gray-200 w-28 shadow-sm">
                            <span className="text-xs font-bold text-gray-500">+15 dB</span>
                            <div className="h-48 flex items-center justify-center w-full">
                                <input 
                                    type="range" 
                                    min="-15" 
                                    max="15" 
                                    step="1" 
                                    value={micVolume} 
                                    onChange={handleMicVolume} 
                                    className="w-40 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                                    style={{ transform: 'rotate(-90deg)' }}
                                />
                            </div>
                            <span className="text-xs font-bold text-gray-500">-15 dB</span>
                            <div className="mt-2 text-center">
                                <span className="text-xs text-gray-500 block">{t.gain}</span>
                                <span className="text-sm font-bold text-indigo-600">{micVolume}dB</span>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>


            <div className="grid md:grid-cols-2 gap-4 p-4 bg-white rounded-lg shadow-md border">
                <button onClick={handleFullFactoryReset} disabled={deviceStatus !== 'Connected'} className="flex items-center justify-center px-4 py-2 bg-yellow-500 text-white font-semibold rounded-full shadow-md hover:bg-yellow-600 transition disabled:bg-gray-400"><RefreshCw className="w-4 h-4 mr-2"/> {t.fullFactoryReset}</button>
                <button onClick={() => handleCommand(CMD.GET_VERSION, [], 'Read Firmware Version (0x0C)')} disabled={deviceStatus !== 'Connected'} className="flex items-center justify-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-full shadow-md hover:bg-indigo-700 transition disabled:bg-gray-400"><Zap className="w-4 h-4 mr-2"/> {t.getFwVersion}</button>
            </div>
        </div>
    )
}

export default SystemSettings
