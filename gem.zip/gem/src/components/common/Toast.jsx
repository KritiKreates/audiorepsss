import React, { useEffect } from 'react';
import { X, CheckCircle, AlertCircle, Info } from 'lucide-react';

const Toast = ({ id, message, type = 'info', onClose, duration = 3000 }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose(id);
        }, duration);
        return () => clearTimeout(timer);
    }, [id, onClose, duration]);

    const icons = {
        success: <CheckCircle className="w-5 h-5 text-green-500" />,
        error: <AlertCircle className="w-5 h-5 text-red-500" />,
        info: <Info className="w-5 h-5 text-blue-500" />,
        warning: <AlertCircle className="w-5 h-5 text-yellow-500" />
    };

    const bgColors = {
        success: 'bg-white border-l-4 border-green-500',
        error: 'bg-white border-l-4 border-red-500',
        info: 'bg-white border-l-4 border-blue-500',
        warning: 'bg-white border-l-4 border-yellow-500'
    };

    return (
        <div className={`flex items-center p-4 mb-3 shadow-lg rounded-lg min-w-[300px] animate-slide-in ${bgColors[type] || bgColors.info}`}>
            <div className="mr-3">
                {icons[type] || icons.info}
            </div>
            <div className="flex-1 text-sm font-medium text-gray-800">
                {message}
            </div>
            <button onClick={() => onClose(id)} className="ml-3 text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
            </button>
        </div>
    );
};

const ToastContainer = ({ toasts, removeToast }) => {
    return (
        <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end pointer-events-none">
            <div className="pointer-events-auto">
                {toasts.map(toast => (
                    <Toast 
                        key={toast.id} 
                        {...toast} 
                        onClose={removeToast} 
                    />
                ))}
            </div>
        </div>
    );
};

export default ToastContainer;
