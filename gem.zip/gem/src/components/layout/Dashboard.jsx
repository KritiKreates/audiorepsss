import React, { useState, useEffect, useRef } from 'react';
import { Sliders, Settings, LogIn, HardDrive } from 'lucide-react';
import NavItem from './NavItem';
import PEQEditor from '../audio/PEQEditor';
import SystemSettings from '../settings/SystemSettings';
import AuthPanel from '../auth/AuthPanel';
import MyDevicePanel from '../device/MyDevicePanel';
import KTEngine from '../../engine/KTEngine';
import { createInitialBands } from '../../utils/helpers';
import { DEVICE_PROFILES } from '../../constants/device';
import { CMD } from '../../constants/hid';
import { TRANSLATIONS } from '../../constants/translations';

const Dashboard = ({ 
    auth, 
    deviceStatus, 
    setDeviceStatus, 
    pushCommand, 
    notify,
    deviceName, 
    setDeviceName, 
    deviceFirmware, 
    setDeviceFirmware, 
    eqBands, 
    setEqBands,
    device,
    requestDevice,
    disconnectDevice,
    getPairedDevices,
    connectToDevice,
    sendReport
}) => {
    const [activeTab, setActiveTab] = useState('DEVICE');
    const [language, setLanguage] = useState('en');
    const [engine, setEngine] = useState(null);
    const userHasUnsavedChanges = useRef(false);

    const t = TRANSLATIONS[language] || TRANSLATIONS.en;
    
    // Device Capability State (Lifted from MyDevicePanel)
    const [volumeMin, setVolumeMin] = useState(-12);
    const [volumeMax, setVolumeMax] = useState(12);
    const [volumeStep, setVolumeStep] = useState(0.5);
    const [masterVolume, setMasterVolume] = useState(0); // Lifted state
    const [productDetails, setProductDetails] = useState(null);
    const [deviceSettings, setDeviceSettings] = useState({}); // Store device settings from reports

    // Wrapper for setEqBands to track user interaction
    const handleUserSetBands = (newBands) => {
        userHasUnsavedChanges.current = true;
        setEqBands(newBands);
    };

    // Callback when push is successful or manual read is requested
    const handleSyncComplete = () => {
        userHasUnsavedChanges.current = false;
    };

    // Reset product details when device disconnects
    useEffect(() => {
        if (deviceStatus === 'Disconnected') {
            setProductDetails(null);
            setDeviceSettings({}); // Reset settings
            setVolumeMin(-12);
            setVolumeMax(12);
            setVolumeStep(0.5);
            userHasUnsavedChanges.current = false;
            
            // Reset EQ Bands to a default state (e.g., 10 bands flat)
            const defaultProfile = DEVICE_PROFILES['0xABCD:0xEF01']; // Use generic 8-band or create a 10-band default
            // Or better, create a standard 10-band flat profile for "No Device"
            const noDeviceProfile = {
                bandCount: 10,
                defaultFrequencies: [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000],
                initialGains: new Array(10).fill(0)
            };
            setEqBands(createInitialBands(noDeviceProfile));
        }
    }, [deviceStatus, setEqBands]);

    // Instantiate Engine when device connects
    useEffect(() => {
        if (device && device.opened) {
            // Only create engine if it doesn't exist or device changed
            setEngine(prev => {
                if (prev && prev.device === device) return prev;
                const eng = new KTEngine({ 
                    onLog: (msg, ...args) => pushCommand(`[KTEngine] ${msg} ${args.join(' ')}`),
                    onEQData: (bands) => {
                        if (userHasUnsavedChanges.current) {
                            console.log('[EQ Sync] Ignoring device update due to unsaved user changes.');
                            return;
                        }
                        pushCommand(`[EQ Sync] Received ${bands.length} bands from device.`);
                        setEqBands(bands);
                    },
                    onFeatureReport: (key, val) => {
                        if (key === '__RAW__') {
                            // Log all raw inputs to help debug version
                            pushCommand(`[HID IN] ${val}`);
                            return;
                        }
                        pushCommand(`[Device Report] ${key}: ${JSON.stringify(val)}`);
                        setDeviceSettings(prev => ({ ...prev, [key]: val }));
                        
                        if (key === 'firmwareVersionRaw') {
                            // val is array of bytes. Pattern usually: [..., CMD(12), LEN, V1, V2, V3, ...]
                            pushCommand(`[Firmware] Raw version data: ${val.join(' ')}`);
                            
                            // 1. Check for KT Protocol Response (Address 4, 'R' 0x52)
                            // Log: 04 00 00 00 52 00 31 2e 30 2e
                            // 04: Address
                            // 52: 'R' (Read Success)
                            // 31 2e 30 2e -> "1.0."
                            if (val[0] === 4 && val[4] === 0x52) {
                                // Version starts at index 6
                                let strBytes = [];
                                for (let i = 6; i < val.length; i++) {
                                    if (val[i] !== 0) strBytes.push(val[i]);
                                }
                                const verStr = String.fromCharCode(...strBytes);
                                // Store partial version if needed, or just set it
                                // If we get "1.0.", we might want to wait for Address 5
                                setDeviceFirmware(prev => {
                                    // If prev is "0.0.1" or null, just take this
                                    if (!prev || prev === "0.0.1") return verStr;
                                    // If we already have part of it, maybe append? 
                                    // But for now, let's just display what we get from Addr 4
                                    return verStr;
                                });
                                pushCommand(`[Firmware] KT Version Part 1 detected: ${verStr}`);
                                return;
                            }
                            
                            if (val[0] === 5 && val[4] === 0x52) {
                                // Part 2 of version?
                                let strBytes = [];
                                for (let i = 6; i < val.length; i++) {
                                    if (val[i] !== 0) strBytes.push(val[i]);
                                }
                                const verPart2 = String.fromCharCode(...strBytes);
                                setDeviceFirmware(prev => {
                                    if (prev && prev !== "0.0.1" && prev.endsWith('.')) {
                                        return prev + verPart2;
                                    }
                                    return prev; // Or just verPart2?
                                });
                                pushCommand(`[Firmware] KT Version Part 2 detected: ${verPart2}`);
                                return;
                            }

                            // 2. Check for CB Protocol Response (0x0C)
                            const idx = val.indexOf(12);
                            if (idx !== -1 && idx + 2 < val.length) {
                                // ... existing CB logic ...
                                let strBytes = [];
                                for (let i = idx + 2; i < val.length; i++) {
                                    if (val[i] === 0) {
                                        if (strBytes.length > 0) break;
                                    } else {
                                        strBytes.push(val[i]);
                                    }
                                }
                                
                                if (strBytes.length > 0) {
                                    const verStr = String.fromCharCode(...strBytes);
                                    if (verStr.includes('.') || !isNaN(parseFloat(verStr))) {
                                        setDeviceFirmware(verStr);
                                        pushCommand(`[Firmware] Version detected: ${verStr}`);
                                    }
                                }
                            }
                        }
                    }
                });
                eng.attach(device).then(() => {
                    // Request firmware version on connection
                    // We need to wait a bit for the device to be ready?
                    // Probe for version with multiple packet sizes
                    setTimeout(() => {
                        pushCommand('[Firmware] Probing version...');
                        
                        // 1. Standard Write (36 bytes - CB/Aura)
                        const p1 = new Uint8Array(36);
                        p1[0] = 1; p1[1] = CMD.GET_VERSION;
                        eng.sendReport(p1).catch(e=>{});

                        // 2. KT Style (10 bytes - Note/KT02H20)
                        setTimeout(() => {
                            const p2 = new Uint8Array(10);
                            p2[0] = 1; p2[1] = CMD.GET_VERSION;
                            eng.sendReport(p2).catch(e=>{});
                        }, 100);

                        // 3. Read Request (36 bytes)
                        setTimeout(() => {
                            const p3 = new Uint8Array(36);
                            p3[0] = 0x80; p3[1] = CMD.GET_VERSION;
                            eng.sendReport(p3).catch(e=>{});
                        }, 200);

                        // 4. Read Request (10 bytes)
                        setTimeout(() => {
                            const p4 = new Uint8Array(10);
                            p4[0] = 0x80; p4[1] = CMD.GET_VERSION;
                            eng.sendReport(p4).catch(e=>{});
                        }, 300);
                        
                        // 5. Alternative KT Command placement (10 bytes)
                        setTimeout(() => {
                            const p5 = new Uint8Array(10);
                            p5[0] = CMD.GET_VERSION; // Try command at byte 0
                            eng.sendReport(p5).catch(e=>{});
                        }, 400);

                        // 6. KT Protocol Structure (Command at byte 4)
                        setTimeout(() => {
                            const p6 = new Uint8Array(10);
                            p6[4] = CMD.GET_VERSION; // 0x0C at index 4
                            eng.sendReport(p6).catch(e=>{});
                        }, 500);

                        // 7. KT Read Register (Try 'R' 0x52 and 'G' 0x47 at Address 4)
                        setTimeout(() => {
                            // Try Read Address 4 (Version Index Part 1)
                            const p7 = new Uint8Array(10);
                            p7[0] = 4; // Address Index
                            p7[4] = 0x52; // 'R'
                            eng.sendReport(p7).catch(e=>{});
                            
                            // Try Read Address 5 (Version Index Part 2?)
                            setTimeout(() => {
                                const p8 = new Uint8Array(10);
                                p8[0] = 5; 
                                p8[4] = 0x52; // 'R'
                                eng.sendReport(p8).catch(e=>{});
                            }, 50);
                        }, 600);

                        // 8. Try Report ID 1 (if supported)
                        setTimeout(() => {
                            if (eng.device && eng.device.collections) {
                                // Check if Report ID 1 exists in outputs
                                const hasRep1 = eng.device.collections.some(c => c.outputReports && c.outputReports.some(r => r.reportId === 1));
                                if (hasRep1) {
                                    pushCommand('[Firmware] Probing Report ID 1...');
                                    const pRep1 = new Uint8Array(64); 
                                    pRep1[0] = CMD.GET_VERSION;
                                    eng.device.sendReport(1, pRep1).catch(e=>{});
                                }
                            }
                        }, 700);

                        // 9. Read EQ Settings from Device
                        setTimeout(() => {
                            eng.readEQ().catch(err => pushCommand(`[EQ Sync] Failed to read EQ: ${err.message}`));
                        }, 1000);

                    }, 500);
                }).catch(err => pushCommand(`Failed to attach KTEngine: ${err.message}`));
                return eng;
            });
        } else {
            setEngine(null);
        }
    }, [device, pushCommand]);

    // Polling for Device State Changes (Dynamic Sync) - DISABLED per user request
    /*
    useEffect(() => {
        let interval;
        if (deviceStatus === 'Connected' && engine) {
            interval = setInterval(() => {
                // Only poll if we are not currently dragging sliders (optimization?)
                // For now, just poll every 3 seconds to keep UI in sync with external changes
                engine.readEQ().catch(e => console.log('Polling failed', e));
            }, 3000);
        }
        return () => clearInterval(interval);
    }, [deviceStatus, engine]);
    */

    const renderContent = () => {
        switch (activeTab) {
            case 'DEVICE':
                return <MyDevicePanel 
                    auth={auth}
                    language={language}
                    deviceStatus={deviceStatus} 
                    setDeviceStatus={setDeviceStatus} 
                    pushCommand={pushCommand} 
                    notify={notify}
                    deviceName={deviceName}
                    deviceFirmware={deviceFirmware}
                    setDeviceName={setDeviceName}
                    setDeviceFirmware={setDeviceFirmware}
                    setEqBands={setEqBands} // Pass setter to update bands on connection
                    requestDevice={requestDevice}
                    disconnectDevice={disconnectDevice}
                    getPairedDevices={getPairedDevices}
                    connectToDevice={connectToDevice}
                    engine={engine}
                    setVolumeMin={setVolumeMin}
                    setVolumeMax={setVolumeMax}
                    setVolumeStep={setVolumeStep}
                    productDetails={productDetails}
                    setProductDetails={setProductDetails}
                />;
            case 'PEQ':
                return <PEQEditor 
                    bands={eqBands} 
                    setBands={handleUserSetBands} 
                    onSyncComplete={handleSyncComplete}
                    deviceStatus={deviceStatus} 
                    pushCommand={pushCommand} 
                    notify={notify}
                    sendReport={sendReport} 
                    device={device}
                    engine={engine}
                    auth={auth}
                    language={language}
                    deviceName={deviceName}
                    volumeMin={volumeMin}
                    volumeMax={volumeMax}
                    volumeStep={volumeStep}
                    masterVolume={masterVolume}
                    setMasterVolume={setMasterVolume}
                    productDetails={productDetails}
                />;
            case 'SETTINGS':
                return <SystemSettings 
                    deviceStatus={deviceStatus} 
                    pushCommand={pushCommand} 
                    notify={notify}
                    sendReport={sendReport} 
                    engine={engine} 
                    deviceSettings={deviceSettings} 
                    language={language}
                />;
            case 'AUTH':
                return <AuthPanel auth={auth} language={language} setLanguage={setLanguage} notify={notify} />;
            default:
                return <MyDevicePanel 
                    auth={auth}
                    language={language}
                    deviceStatus={deviceStatus} 
                    setDeviceStatus={setDeviceStatus} 
                    pushCommand={pushCommand} 
                    notify={notify}
                    deviceName={deviceName}
                    deviceFirmware={deviceFirmware}
                    setDeviceName={setDeviceName}
                    setDeviceFirmware={setDeviceFirmware}
                    setEqBands={setEqBands}
                    requestDevice={requestDevice}
                    disconnectDevice={disconnectDevice}
                    getPairedDevices={getPairedDevices}
                    connectToDevice={connectToDevice}
                    engine={engine}
                    setVolumeMin={setVolumeMin}
                    setVolumeMax={setVolumeMax}
                    setVolumeStep={setVolumeStep}
                    productDetails={productDetails}
                    setProductDetails={setProductDetails}
                />;
        }
    };

    return (
        <div className="flex flex-col md:flex-row h-screen bg-gray-100 font-sans">
            {/* Left Sidebar (Navigation & Status) */}
            <div className="w-full md:w-64 bg-white shadow-xl flex flex-col p-4">
                <div className="text-2xl font-extrabold text-indigo-700 mb-6 border-b pb-3">
                    Audiocular Control
                </div>

                <div className="space-y-2">
                    <NavItem icon={HardDrive} label={t.sidebarMyDevice} isActive={activeTab === 'DEVICE'} onClick={() => setActiveTab('DEVICE')} />
                    <NavItem icon={Sliders} label={t.sidebarPEQ} isActive={activeTab === 'PEQ'} onClick={() => setActiveTab('PEQ')} />
                    <NavItem icon={Settings} label={t.sidebarSettings} isActive={activeTab === 'SETTINGS'} onClick={() => setActiveTab('SETTINGS')} />
                    <NavItem icon={LogIn} label={t.sidebarAuth} isActive={activeTab === 'AUTH'} onClick={() => setActiveTab('AUTH')} />
                </div>

                {/* Device Status (Simplified Display) */}
                <div className="mt-auto pt-4 border-t border-gray-200">
                    <h3 className="text-sm font-semibold mb-2 text-gray-600">{t.currentDevice}</h3>
                    <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${deviceStatus === 'Connected' ? 'bg-green-500' : deviceStatus.includes('Ready') ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
                        <span className="text-sm font-medium text-gray-800 truncate">{deviceName}</span>
                    </div>
                    <span className="text-xs text-gray-500">{t.firmware}: {deviceFirmware}</span>
                    {deviceStatus === 'Disconnected' && (
                        <button
                            onClick={() => setActiveTab('DEVICE')}
                            className="w-full mt-2 py-2 text-sm bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition disabled:bg-gray-40s0"
                        >
                            {t.connectDevice}
                        </button>
                    )}
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8">
                {renderContent()}
            </div>
        </div>
    );
};

export default Dashboard;
