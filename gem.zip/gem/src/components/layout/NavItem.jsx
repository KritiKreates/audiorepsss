import React from 'react'

const NavItem = ({ icon: Icon, label, isActive, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center px-4 py-3 rounded-xl transition ${isActive ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-700 hover:bg-gray-100 hover:text-indigo-600'}`}>
    <Icon className="w-5 h-5 mr-3" />
    <span className="font-medium">{label}</span>
  </button>
)

export default NavItem
