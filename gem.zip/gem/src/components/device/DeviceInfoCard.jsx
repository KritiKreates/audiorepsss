import React from 'react';

const DeviceInfoCard = ({ title, value, status }) => {
    const statusColor = status === 'Connected' ? 'text-green-600' : status.includes('Ready') ? 'text-yellow-600' : 'text-red-600';
    return (
        <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-xs font-medium text-gray-500">{title}</p>
            <p className={`mt-1 text-lg font-bold ${statusColor}`}>{value}</p>
        </div>
    );
};

export default DeviceInfoCard;