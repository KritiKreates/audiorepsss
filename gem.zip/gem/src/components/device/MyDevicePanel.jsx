import React, { useState, useEffect, useCallback, useRef } from 'react';
import { HardDrive, Plug, Cpu, Info, Package, UploadCloud, FileCode, Terminal } from 'lucide-react';
import { DEVICE_PROFILES } from '../../constants/device';
import { createInitialBands, generateDefaultFrequencies, getBandCountFromScheme } from '../../utils/helpers';
import { DeviceG, DeviceY, DeviceQ, BaseDevice } from '../../utils/firmware';
import DeviceInfoCard from './DeviceInfoCard';
import { TRANSLATIONS } from '../../constants/translations';

const MyDevicePanel = ({ 
    auth, 
    language = 'en',
    deviceStatus, 
    setDeviceStatus, 
    pushCommand, 
    deviceName, 
    deviceFirmware, 
    setDeviceName, 
    setDeviceFirmware, 
    setEqBands,
    requestDevice,
    disconnectDevice,
    getPairedDevices,
    connectToDevice,
    engine,
    setVolumeMin,
    setVolumeMax,
    setVolumeStep,
    productDetails,
    setProductDetails
}) => {
    const [detectedScheme, setDetectedScheme] = useState(null);
    const [currentDeviceIDs, setCurrentDeviceIDs] = useState({ vid: '', pid: '' });

    const t = TRANSLATIONS[language] || TRANSLATIONS.en;

    const [dacVolumeStep, setDacVolumeStep] = useState(1);
    const [dacVolumeMin, setDacVolumeMin] = useState(-20);
    const [dacVolumeMax, setDacVolumeMax] = useState(20);
    const [deviceGroup, setDeviceGroup] = useState("CB"); // CB, KT02H20, KT0231H

    // Firmware Upgrade State
    const [upgradeFile, setUpgradeFile] = useState(null);
    const [upgradeFileName, setUpgradeFileName] = useState('');
    const [upgradeProgress, setUpgradeProgress] = useState(0);
    const [upgradeStatus, setUpgradeStatus] = useState('Idle'); // Idle, Initializing, Burning, Success, Failed
    const [upgradeLogs, setUpgradeLogs] = useState([]);
    const [showUpgradeUI, setShowUpgradeUI] = useState(false);
    
    // Online Firmware Check State
    const [latestFirmwareInfo, setLatestFirmwareInfo] = useState(null);
    const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
    const [isDownloading, setIsDownloading] = useState(false);

    // Mic Visualizer & Limits
    const [micGainMin, setMicGainMin] = useState(-15);
    const [micGainMax, setMicGainMax] = useState(15);
    
    const logsEndRef = useRef(null);



    // Sync Scheme to Engine when available
    useEffect(() => {
        if (engine && detectedScheme) {
            console.log(`[MyDevicePanel] Syncing scheme ${detectedScheme} to engine`);
            engine.setScheme(detectedScheme);
        }
    }, [engine, detectedScheme]);

    // Check for paired devices on mount
    useEffect(() => {
        const checkPaired = async () => {
            if (deviceStatus === 'Disconnected' && getPairedDevices) {
                const paired = await getPairedDevices();
                if (paired.length > 0) {
                    // setDeviceStatus('Ready to Connect'); // Removed as per request
                    setDeviceName(paired[0].productName);
                }
            }
        };
        checkPaired();
    }, [deviceStatus, getPairedDevices, setDeviceStatus, setDeviceName]);

    const initializeDevice = async (device) => {
        // Ensure 4-digit hex format (e.g. 0x12C1)
        const hexVid = device.vendorId.toString(16).toUpperCase().padStart(4, '0');
        const hexPid = device.productId.toString(16).toUpperCase().padStart(4, '0');
        const vid = `0x${hexVid}`;
        const pid = `0x${hexPid}`;
        const profileKey = `${vid}:${pid}`;
        
        setCurrentDeviceIDs({ vid, pid });
        console.log(`[MyDevicePanel] Initializing device: ${profileKey}`);
        pushCommand(`Initializing device profile for ${profileKey}...`);
        
        // Fetch online product details and EQ info
        const productInfo = await fetchProductDetails(vid, pid);
        const eqInfo = await fetchEQInfo(vid, pid, productInfo);

        let profile = DEVICE_PROFILES[profileKey] || DEVICE_PROFILES['0xABCD:0xEF01']; // Default
        let apiBandCount = 0;
        let apiFrequencies = [];

        // 1. Try to get band count from Product Scheme (Hardware Capability)
        if (productInfo) {
             console.log('Product Info:', productInfo);
             
             // Check for SchemeNo directly or in scheme object
             // The API response usually has keys like 'SchemeNo' or 'schemeNo'
             let schemeNo = productInfo.SchemeNo || productInfo.schemeNo || productInfo.scheme_no;
             
             // If not found directly, check if there's a nested scheme object
             if (!schemeNo && productInfo.scheme) {
                 schemeNo = productInfo.scheme.code || productInfo.scheme.SchemeNo;
             }

             if (schemeNo) {
                 setDetectedScheme(schemeNo);
                 const count = getBandCountFromScheme(schemeNo);
                 apiBandCount = count;
                 
                 // Determine Group and Volume Settings
                 const sNo = String(schemeNo);
                 let group = "CB";
                 let step = 1;
                 let min = -16;
                 let max = 6;

                 if (sNo === '17') {
                     group = "KT02H20";
                     step = 1.5;
                     min = -6;
                     max = 3;
                     setMicGainMin(0);
                     setMicGainMax(5);
                 } else if (sNo === '19') {
                     group = "KT0231H";
                     step = 2;
                     min = -12;
                     max = 0;
                     setMicGainMin(0);
                     setMicGainMax(5);
                 } else {
                     // CB Defaults
                     group = "CB";
                     step = 1; // Or dynamic based on user code
                     min = -16;
                     max = 6;
                     setMicGainMin(-15);
                     setMicGainMax(15);
                 }

                 setDeviceGroup(group);
                 setDacVolumeStep(step);
                 setDacVolumeMin(min);
                 setDacVolumeMax(max);

                 // Update Parent State for PEQ Editor
                 if (setVolumeMin) setVolumeMin(min);
                 if (setVolumeMax) setVolumeMax(max);
                 if (setVolumeStep) setVolumeStep(step);
                 
                 pushCommand(`Found Scheme #${schemeNo} (${group}): Configuring ${apiBandCount} bands. Vol: [${min}, ${max}], Step: ${step}`);
                 
                 // Set the engine protocol based on scheme
                 if (engine) {
                     engine.setScheme(schemeNo);
                 }
             } else {
                 // Fallback to previous logic if SchemeNo is missing but segment info exists
                 const scheme = productInfo.scheme || productInfo;
                 const segment = scheme.dacEqSegment || scheme.dac_eq_segment || scheme.eqSegment || scheme.eq_segment;
                 if (segment) {
                     const count = parseInt(segment, 10);
                     if (!isNaN(count) && count > 0) {
                        apiBandCount = count;
                        pushCommand(`Found DAC-EQ Segment: ${apiBandCount} bands.`);
                     }
                 }
             }
        }

        // 2. Try to get bands/freqs from EQ Info (Presets) - This overrides Scheme count if present and valid
        if (eqInfo && eqInfo.length > 0) {
            console.log('EQ Info from API:', eqInfo);
            const firstPreset = eqInfo[0];
            
            // Log keys to UI to help debugging
            pushCommand(`EQ Data Keys: ${Object.keys(firstPreset).join(', ')}`);

            // Check for 'bands', 'eq_bands', 'data', or 'eq'
            let bandsArray = firstPreset.bands || firstPreset.eq_bands || firstPreset.data || firstPreset.eq;
            
            // Sometimes the bands are inside a 'detail' or 'content' object
            if (!bandsArray && firstPreset.detail && firstPreset.detail.bands) bandsArray = firstPreset.detail.bands;

            // NEW: Check for flat structure based on Admin Panel (Freqs: "20,80,160...")
            // The API might return 'freqs' or 'frequency' as a comma-separated string or array
            let freqList = firstPreset.freqs || firstPreset.freq || firstPreset.frequency || firstPreset.frequencies;
            
            if (freqList) {
                // If it's a string "20,80,160", split it
                if (typeof freqList === 'string') {
                    freqList = freqList.split(',').map(f => parseFloat(f.trim())).filter(n => !isNaN(n));
                }
                
                if (Array.isArray(freqList) && freqList.length > 0) {
                    apiBandCount = freqList.length;
                    apiFrequencies = freqList;
                    pushCommand(`Configuring ${apiBandCount} bands from API 'freqs' list.`);
                    
                    // Try to parse gains as well if available
                    let gainList = firstPreset.gains || firstPreset.gain;
                    if (typeof gainList === 'string') {
                        gainList = gainList.split(',').map(g => parseFloat(g.trim()));
                    }
                    if (!Array.isArray(gainList)) gainList = new Array(apiBandCount).fill(0);

                    profile = {
                        ...profile,
                        bandCount: apiBandCount,
                        defaultFrequencies: apiFrequencies,
                        initialGains: gainList
                    };
                    
                    // Skip the bandsArray check since we found what we needed
                    bandsArray = null; 
                }
            }

            if (bandsArray && Array.isArray(bandsArray)) {
                apiBandCount = bandsArray.length;
                apiFrequencies = bandsArray.map(b => b.freq || b.frequency || 1000); 
                
                pushCommand(`Configuring ${apiBandCount} bands from API info.`);
                
                profile = {
                    ...profile,
                    bandCount: apiBandCount,
                    defaultFrequencies: apiFrequencies,
                    initialGains: new Array(apiBandCount).fill(0)
                };
            } else if (!freqList && apiBandCount === 0) {
                // Only warn if we haven't found bands from Scheme either
                pushCommand('EQ info found but could not identify bands array or freq list.');
                console.warn('Unexpected EQ info structure:', firstPreset);
            }
        } else {
             pushCommand('No EQ info found for this device (VID/PID).');
        }

        // 3. Final Profile Construction (if Scheme found but no specific EQ preset)
        if (apiBandCount > 0 && (!profile.defaultFrequencies || profile.defaultFrequencies.length !== apiBandCount)) {
             pushCommand(`Using Scheme band count (${apiBandCount}) with default frequencies.`);
             apiFrequencies = generateDefaultFrequencies(apiBandCount);
             profile = {
                ...profile,
                bandCount: apiBandCount,
                defaultFrequencies: apiFrequencies,
                initialGains: new Array(apiBandCount).fill(0)
             };
        }

        const bands = createInitialBands(profile);
        setEqBands(bands);
    };

    const handleManualConnect = async () => {
        const device = await requestDevice();
        if (device) {
            await initializeDevice(device);
        }
    };

    const handleAutoSelectConnect = async () => {
        const paired = await getPairedDevices();
        if (paired.length > 0) {
            await connectToDevice(paired[0]);
            await initializeDevice(paired[0]);
        } else {
            pushCommand('No paired devices found. Please use Manual Connect first.');
        }
    };

    const fetchProductDetails = async (vid, pid) => {
        if (!auth) return null;
        console.log(`[MyDevicePanel] Fetching product details for VID:${vid} PID:${pid}`);
        try {
            // POST /api/product/detail
            const result = await auth.callApi('/api/product/detail', 'POST', {
                pid: pid,
                vid: vid
            }, false); 

            console.log("[MyDevicePanel] Product details result:", result);

            // API can return code 200 or 0 for success
            if (result && (result.code === 200 || result.code === 0) && result.data) {
                setProductDetails(result.data);
                pushCommand(`Fetched product info: ${result.data.name || result.data.ProductModelEn || 'Unknown'}`);
                return result.data;
            } else {
                console.warn("[MyDevicePanel] Product details not found or invalid response", result);
                pushCommand(`Product info not found for VID:${vid} PID:${pid}`);
            }
        } catch (error) {
            console.error("Failed to fetch product details", error);
            pushCommand(`Error fetching product info: ${error.message}`);
        }
        return null;
    };

    const fetchEQInfo = async (vid, pid, productInfo = null) => {
        if (!auth) return null;
        try {
            pushCommand(`[API] Fetching Public Presets for ${vid}:${pid}...`);
            
            // 1. Try the "Enterprise/Public" endpoint first (No Auth required usually)
            // This corresponds to "queryEQListByPidAndVid" in Postman
            let result = null;
            if (auth.queryEQListByPidAndVid) {
                const payload = { pid, vid };
                // If we have product info, include productId as it might be required
                if (productInfo && productInfo.id) {
                    payload.productId = productInfo.id;
                }
                result = await auth.queryEQListByPidAndVid(payload);
            }

            // 2. If that fails or returns nothing, try the standard list endpoint with Type 2
            if (!result || (result.code !== 200 && result.code !== 0)) {
                console.log("[MyDevicePanel] Public endpoint failed, trying generic list (Type 2)...");
                if (auth.fetchPreSettingsAndCustomEqs) {
                    result = await auth.fetchPreSettingsAndCustomEqs(pid, vid, "2");
                }
            }
            
            if (result && (result.code === 200 || result.code === 0)) {
                 const dataStr = result.data ? (Array.isArray(result.data) ? `Array(${result.data.length})` : 'Object') : 'null';
                 pushCommand(`[API] Success. Data: ${dataStr}`);
                 
                 if (result.data) {
                    // Handle potential structure { preSettings: [], customEqs: [] }
                    if (result.data.preSettings || result.data.customEqs) {
                        const combined = [
                            ...(result.data.preSettings || []),
                            ...(result.data.customEqs || [])
                        ];
                        return combined;
                    }
                    // Fallback if it's just an array
                    if (Array.isArray(result.data)) {
                        return result.data;
                    }
                    return [result.data]; // Treat as single object
                 }
            } else {
                 pushCommand(`[API] Error: ${result?.msg || result?.message || 'Unknown'} (Code: ${result?.code})`);
            }
        } catch (error) {
            console.error("Failed to fetch EQ info", error);
            pushCommand(`Error fetching EQ info: ${error.message}`);
        }
        return null;
    };



    // Firmware Upgrade Logic
    const addUpgradeLog = (msg) => {
        setUpgradeLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
    };

    useEffect(() => {
        if (logsEndRef.current) {
            logsEndRef.current.scrollIntoView({ behavior: "smooth" });
        }
    }, [upgradeLogs]);

    const startUpgrade = async () => {
        if (!upgradeFile) {
            pushCommand(t.selectFirmwareFirst);
            return;
        }
        if (!engine || !engine.device) {
             pushCommand(t.connectDeviceFirst);
             return;
        }

        if (!window.confirm(t.firmwareWarning)) {
            return;
        }

        setUpgradeStatus('Initializing');
        setUpgradeProgress(0);
        setUpgradeLogs([]);
        addUpgradeLog(t.startingUpdate);

        let UpgraderClass = DeviceG;
        if (deviceGroup === 'KT02H20') UpgraderClass = DeviceY;
        if (deviceGroup === 'KT0231H') UpgraderClass = DeviceQ;

        addUpgradeLog(`Selected Protocol: ${UpgraderClass.name} (Group: ${deviceGroup})`);

        // We need to pass the HID device to the constructor
        const upgrader = new UpgraderClass(engine.device, {});
        
        // Bind events
        upgrader.addEventLister(BaseDevice.eventKeys.INIT_FINISH, () => {
            setUpgradeStatus('Burning');
            addUpgradeLog(t.initFinished);
            upgrader.upgrade(upgradeFile);
        });
        
        upgrader.addEventLister(BaseDevice.eventKeys.UPGRADE_PROGRESS, (progress) => {
            setUpgradeProgress(Math.round(progress));
        });

        upgrader.addEventLister(BaseDevice.eventKeys.UPGRADE_SUCCESS, () => {
            setUpgradeStatus('Success');
            setUpgradeProgress(100);
            addUpgradeLog(t.updateComplete);
            pushCommand(t.updateComplete);
        });

        upgrader.addEventLister(BaseDevice.eventKeys.UPGRADE_FAIL, () => {
            setUpgradeStatus('Failed');
            addUpgradeLog(t.updateFailed);
            pushCommand(t.updateFailed);
        });
        
        upgrader.addEventLister(BaseDevice.eventKeys.INIT_FAIL, () => {
            setUpgradeStatus('Failed');
            addUpgradeLog(t.initFailed);
            pushCommand(t.initFailed);
        });

        // Override log to capture internal logs
        const originalLog = upgrader.log.bind(upgrader);
        upgrader.log = (msg) => {
            originalLog(msg);
            if (typeof msg === 'string') addUpgradeLog(msg);
        };

        try {
            await upgrader.init();
        } catch (e) {
            addUpgradeLog(`Error: ${e.message}`);
            setUpgradeStatus('Failed');
        }
    };

    const handleCheckUpdate = async () => {
        if (!productDetails && (!currentDeviceIDs.pid || !currentDeviceIDs.vid)) {
            pushCommand("[Error] Device info not loaded. Cannot check for updates.");
            return;
        }
        
        setIsCheckingUpdate(true);
        pushCommand("[Firmware] Checking for updates...");
        
        try {
            // Use current device info
            const pid = currentDeviceIDs.pid || productDetails?.pid || productDetails?.productId || 0;
            const vid = currentDeviceIDs.vid || productDetails?.vid || productDetails?.vendorId || 0;
            // If firmware version is unknown, use a low version to force update check
            const version = deviceFirmware || "0.0.1";

            pushCommand(`[Firmware] Querying: PID=${pid} VID=${vid} Ver=${version}`);

            const result = await auth.checkFirmwareVersion(pid, vid, version);
            
            if (result && (result.code === 200 || result.code === 0)) {
                // Update available
                setLatestFirmwareInfo(result.data);
                pushCommand(`[Firmware] Update found: ${result.data.version}`);
            } else if (result && result.code === 404) {
                setLatestFirmwareInfo(null);
                pushCommand(`[Firmware] Update check not supported for this device.`);
            } else {
                setLatestFirmwareInfo(null);
                // Stringify the result if msg is missing to see what we got
                const errorMsg = result?.msg || result?.message || (typeof result === 'object' ? JSON.stringify(result) : String(result));
                pushCommand(`[Firmware] Check failed: ${errorMsg} (Code: ${result?.code})`);
            }
        } catch (e) {
            pushCommand(`[Firmware] Check error: ${e.message}`);
        } finally {
            setIsCheckingUpdate(false);
        }
    };

    const handleOnlineUpgrade = async () => {
        if (!latestFirmwareInfo || !latestFirmwareInfo.url) return;
        
        setIsDownloading(true);
        pushCommand(`[Firmware] Downloading firmware from ${latestFirmwareInfo.url}...`);
        
        try {
            const blob = await auth.downloadFirmware(latestFirmwareInfo.url);
            if (blob) {
                // Convert Blob to Uint8Array
                const arrayBuffer = await blob.arrayBuffer();
                const uint8Array = new Uint8Array(arrayBuffer);
                
                setUpgradeFile(uint8Array);
                setUpgradeFileName(`Online: ${latestFirmwareInfo.version}`);
                pushCommand("[Firmware] Download complete. Ready to flash.");
            } else {
                pushCommand("[Firmware] Download failed.");
            }
        } catch (e) {
            pushCommand(`[Firmware] Download error: ${e.message}`);
        } finally {
            setIsDownloading(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center border-b pb-2">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                    <HardDrive className="w-5 h-5 mr-2 text-indigo-600" /> {t.myDeviceDashboard}
                </h2>
            </div>

            <div className="p-6 bg-white rounded-xl shadow-md border space-y-4">
                {productDetails && (
                    <div className="mb-6 border-b pb-6">
                        <h4 className="font-semibold text-gray-800 flex items-center mb-4">
                            <Info className="w-5 h-5 mr-2 text-indigo-600" /> {t.productInformation}
                        </h4>
                        <div className="flex gap-6 items-start">
                            {(productDetails.images || productDetails.Images) && (
                                <div className="w-64 h-64 flex-shrink-0 bg-white rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center p-2">
                                    <img 
                                        src={(() => {
                                            try {
                                                const rawImages = productDetails.images || productDetails.Images;
                                                let imgPath = '';
                                                // Try parsing as JSON array first
                                                try {
                                                    const imgs = JSON.parse(rawImages);
                                                    imgPath = Array.isArray(imgs) && imgs.length > 0 ? imgs[0] : rawImages;
                                                } catch (e) {
                                                    imgPath = rawImages;
                                                }

                                                // Prepend BaseUrl if it's a relative path
                                                if (imgPath && imgPath.startsWith('/') && productDetails.BaseUrl) {
                                                    return `${productDetails.BaseUrl}${imgPath}`;
                                                }
                                                return imgPath;
                                            } catch (e) { 
                                                return ''; 
                                            }
                                        })()} 
                                        alt="Product" 
                                        className="max-w-full max-h-full object-contain"
                                    />
                                </div>
                            )}
                            <div className="grid grid-cols-2 gap-8 text-base flex-1">
                                <div>
                                    <span className="text-gray-500 block mb-2 font-medium">{t.modelName}</span>
                                    <span className="font-bold text-gray-900 text-2xl">
                                        {productDetails.name || productDetails.ProductModelEn || productDetails.ProductModel || 'N/A'}
                                    </span>
                                </div>
                                <div>
                                    <span className="text-gray-500 block mb-2 font-medium">{t.brand}</span>
                                    <span className="font-bold text-gray-900 text-2xl">
                                        {productDetails.brand || productDetails.ProductBrandEn || productDetails.ProductBrand || productDetails.ManufactureNameEn || 'N/A'}
                                    </span>
                                </div>
                                <div>
                                    <span className="text-gray-500 block mb-2 font-medium">{t.schemeId}</span>
                                    <span className="font-bold text-gray-900 text-2xl">
                                        {productDetails.schemeNo || productDetails.SchemeNo || productDetails.scheme_no || (productDetails.scheme && productDetails.scheme.code) || 'N/A'}
                                    </span>
                                </div>
                                <div>
                                    <span className="text-gray-500 block mb-2 font-medium">{t.description}</span>
                                    <span className="font-bold text-gray-900 text-2xl">
                                        {productDetails.description || productDetails.TitleEn || productDetails.Title || productDetails.DescriptionEn || 'N/A'}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <DeviceInfoCard title={t.connectionStatus} value={deviceStatus} status={deviceStatus} />
                    <DeviceInfoCard title={t.deviceName} value={deviceName} status={deviceStatus} />
                    <DeviceInfoCard title={t.firmwareVersion} value={deviceFirmware} status={deviceStatus} />
                </div>

                <div className="pt-4">
                    {deviceStatus === 'Disconnected' ? (
                        <div className="flex flex-col gap-2">
                            <p className="text-sm text-gray-500">
                               {t.connectDevicePrompt}
                            </p>
                            <button
                                onClick={handleManualConnect}
                                className="w-full px-4 py-3 bg-indigo-600 text-white font-semibold rounded-full shadow-lg hover:bg-indigo-700 transition flex justify-center items-center"
                            >
                                <Cpu className="w-4 h-4 mr-2" /> {t.connectDevice}
                            </button>
                        </div>
                    ) : (
                        <button
                            onClick={disconnectDevice}
                            className="w-full px-4 py-3 bg-red-500 text-white font-semibold rounded-full shadow-lg hover:bg-red-600 transition"
                        >
                            {t.disconnect} {deviceName}
                        </button>
                    )}
                </div>
            </div>
            <div className="p-6 bg-white rounded-xl shadow-md border space-y-4">
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-700 flex items-center">
                        <UploadCloud className="w-5 h-5 mr-2 text-indigo-600" /> {t.firmwareUpgrade}
                    </h3>
                    <button 
                        onClick={() => setShowUpgradeUI(!showUpgradeUI)}
                        className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
                    >
                        {showUpgradeUI ? t.hide : t.show}
                    </button>
                </div>

                {showUpgradeUI && (
                    <div className="space-y-6 bg-gray-50 p-6 rounded-lg border border-gray-200 flex flex-col items-center text-center">
                        
                        {/* Section 1: Check */}
                        <div className="w-full max-w-md space-y-4">
                            <h3 className="text-lg font-medium text-gray-500 border-b border-gray-300 pb-2 mx-auto w-3/4">{t.firmwareCheck}</h3>
                            
                            <button 
                                onClick={handleCheckUpdate}
                                disabled={isCheckingUpdate || upgradeStatus !== 'Idle'}
                                className="w-full py-3 bg-[#1a1a1a] text-white font-bold rounded-full shadow-lg hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed tracking-wide uppercase"
                            >
                                {isCheckingUpdate ? t.checking : t.checkNewFirmware}
                            </button>

                            <div className="min-h-[24px]">
                                {latestFirmwareInfo ? (
                                    <div className="animate-pulse">
                                        <p className="text-red-500 font-bold">{t.newVersionAvailable}: {latestFirmwareInfo.version}</p>
                                        <p className="text-xs text-gray-500">{latestFirmwareInfo.description}</p>
                                    </div>
                                ) : (
                                    <p className={`text-sm font-bold uppercase tracking-widest ${deviceFirmware ? 'text-red-500' : 'text-gray-400'}`}>
                                        {isCheckingUpdate 
                                            ? t.obtainingFirmware 
                                            : `${t.version}: ${deviceFirmware ? (deviceFirmware.startsWith('V') ? deviceFirmware : 'V' + deviceFirmware) : '--'}`}
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Section 2: Update */}
                        <div className="w-full max-w-md space-y-4 pt-4">
                            <div className="relative border-t border-gray-300 w-3/4 mx-auto">
                                <span className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gray-50 px-4 text-gray-500 font-medium uppercase tracking-widest">{t.update}</span>
                            </div>

                            <p className={`font-medium ${deviceStatus === 'Connected' ? 'text-teal-500' : 'text-gray-400'}`}>
                                {deviceStatus === 'Connected' ? t.connected : t.disconnected}
                            </p>

                            <button 
                                onClick={upgradeFile ? startUpgrade : handleOnlineUpgrade}
                                disabled={(!latestFirmwareInfo && !upgradeFile) || isDownloading || upgradeStatus === 'Burning' || upgradeStatus === 'Initializing'}
                                className={`w-full py-3 rounded-full shadow-lg font-bold tracking-wide transition-all text-white
                                    ${(!latestFirmwareInfo && !upgradeFile) 
                                        ? 'bg-gray-400 cursor-not-allowed' 
                                        : 'bg-gradient-to-b from-indigo-500 to-indigo-700 hover:from-indigo-600 hover:to-indigo-800'
                                    }`}
                            >
                                {upgradeStatus === 'Burning' ? t.upgrading : 
                                 upgradeStatus === 'Initializing' ? t.initializing :
                                 isDownloading ? t.downloading :
                                 upgradeFile ? t.startUpgrade : 
                                 t.update}
                            </button>
                        </div>

                        {/* Note */}
                        <p className="text-xs text-gray-500 max-w-md text-left mt-4 leading-relaxed">
                            {t.firmwareWarning}
                        </p>

                        {/* Progress Bar */}
                        {(upgradeStatus === 'Burning' || upgradeStatus === 'Success' || isDownloading) && (
                            <div className="w-full max-w-md bg-gray-200 rounded-full h-2 overflow-hidden mt-4">
                                <div 
                                    className={`h-2 rounded-full transition-all duration-300 ${upgradeStatus === 'Success' ? 'bg-green-500' : 'bg-indigo-500'}`}
                                    style={{ width: `${isDownloading ? 100 : upgradeProgress}%`, opacity: isDownloading ? 0.5 : 1 }}
                                ></div>
                            </div>
                        )}

                        {/* Logs Console (Collapsible or Small) */}
                        {upgradeLogs.length > 0 && (
                            <div className="w-full max-w-md bg-gray-900 rounded-lg p-3 font-mono text-xs h-32 overflow-y-auto border border-gray-700 text-left mt-4">
                                <div className="space-y-1">
                                    {upgradeLogs.map((log, idx) => (
                                        <div key={idx} className="text-green-400 break-all">{log}</div>
                                    ))}
                                    <div ref={logsEndRef} />
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default MyDevicePanel;