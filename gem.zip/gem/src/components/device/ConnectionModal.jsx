import React, { useState } from 'react';
import { Plug } from 'lucide-react';
import { MOCK_DEVICES } from '../constants/device';

const ConnectionModal = ({ isOpen, onClose, connectDevice, deviceStatus }) => {
    const [selectedId, setSelectedId] = useState(MOCK_DEVICES[0].id);

    const handleConnect = () => {
        const device = MOCK_DEVICES.find(d => d.id === selectedId);
        if (device) {
            connectDevice(device);
            onClose();
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg p-6 space-y-4">
                <h3 className="text-xl font-bold text-indigo-700 flex items-center border-b pb-2">
                    <Plug className="w-5 h-5 mr-2" /> Select HID Device
                </h3>
                <p className="text-sm text-gray-600">
                    Simulate HID connection by selecting a device from the list. Devices with VID/PID matching KT/CB are prioritized.
                </p>

                <div className="space-y-3 max-h-60 overflow-y-auto p-2 border rounded-lg bg-gray-50">
                    {MOCK_DEVICES.map(device => (
                        <div key={device.id} 
                             className={`p-3 rounded-lg cursor-pointer transition ${selectedId === device.id ? 'bg-indigo-100 border-indigo-500 border-2' : 'bg-white border hover:bg-gray-100'}`}
                             onClick={() => setSelectedId(device.id)}
                        >
                            <p className="font-semibold">{device.name}</p>
                            <p className="text-xs text-gray-500">VID: {device.vid} / PID: {device.pid}</p>
                            {device.name.includes("KT/CB") && (
                                <span className="text-xs text-green-600 font-medium">Auto-detected KT/CB Device</span>
                            )}
                        </div>
                    ))}
                </div>

                <div className="flex justify-end space-x-3 pt-2">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-full hover:bg-gray-300 transition"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleConnect}
                        disabled={deviceStatus === 'Connecting...'}
                        className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-full hover:bg-indigo-700 transition disabled:bg-gray-400"
                    >
                        {deviceStatus === 'Connecting...' ? 'Connecting...' : 'Connect Selected'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConnectionModal;